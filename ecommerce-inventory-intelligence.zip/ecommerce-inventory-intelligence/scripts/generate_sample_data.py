"""Generate the synthetic DEMONSTRATION dataset.   Usage (from project root):  python scripts/generate_sample_data.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from src.data_loader import ensure_sample_files, generate_synthetic_data  # noqa: E402

if __name__ == "__main__":
    sales, inv = generate_synthetic_data()
    ensure_sample_files(force=True)
    print(config.DEMO_LABEL)
    print(f"sales rows: {len(sales):,} | products: {sales['product_id'].nunique()} | "
          f"{sales['date'].min():%Y-%m-%d} to {sales['date'].max():%Y-%m-%d}")
    print(f"wrote {config.SAMPLE_SALES_PATH} and {config.SAMPLE_INVENTORY_PATH}")
