"""Train + evaluate all models from the command line and save them.

Usage (project root):
    python scripts/train_models.py                       # synthetic sample dataset
    python scripts/train_models.py --sales my.csv [--inventory inv.csv]   # your own CSV (auto column mapping)
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from src import data_validation as dv  # noqa: E402
from src import database as db  # noqa: E402
from src import pipeline as pl  # noqa: E402
from src.data_loader import read_csv_flexible  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sales")
    ap.add_argument("--inventory")
    ap.add_argument("--key", default=None)
    a = ap.parse_args()
    if a.sales:
        rep = dv.validate_sales(read_csv_flexible(a.sales))
        for line in rep.summary_lines():
            print(line)
        if not rep.ok:
            sys.exit(1)
        inv = None
        if a.inventory:
            ir = dv.validate_inventory(read_csv_flexible(a.inventory))
            inv = ir.cleaned if ir.ok else None
        key = a.key or "upload_" + Path(a.sales).stem.lower()
        ctx = pl.build_context(rep.cleaned, inv, key, Path(a.sales).name, False, rep.info)
    else:
        ctx = pl.load_sample_context()
        print("Using SYNTHETIC DEMONSTRATION data (not real business results).")
    t = time.time()
    try:
        b = pl.get_or_train_bundle(ctx, force=True, progress=lambda f, m: print(f"  [{f:4.0%}] {m}"))
    except ValueError as exc:
        print(f"Cannot train: {exc}")
        sys.exit(2)
    pd.set_option("display.width", 200)
    print(b["comparison"][["model", "MAE_val", "RMSE_val", "WAPE_val", "MAE_test", "RMSE_test", "WAPE_test", "selected"]].round(3).to_string(index=False))
    print(f"Selected on validation: {b['selected']}  |  done in {time.time() - t:.0f}s  |  saved to models/{ctx.key}.joblib")


if __name__ == "__main__":
    main()
