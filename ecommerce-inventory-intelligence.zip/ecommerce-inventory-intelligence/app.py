"""Home page. Run with:  streamlit run app.py   (from the project root)."""
import streamlit as st

import config
from src import app_context as ac

ctx, bundle, policy = ac.setup_page("E-Commerce Demand Forecasting & Inventory Intelligence",
                                    "Predict demand, detect inventory risk, recommend what to do next.", need_model=False)

c1, c2, c3 = st.columns(3)
c1.metric("Products", ctx.panel["product_id"].nunique())
c2.metric("History (days)", int(ctx.panel["date"].nunique()))
c3.metric("Models", "Trained" if bundle else "Not trained yet")

st.markdown("""
**Workflow:** data validation -> EDA -> feature engineering -> model training & chronological evaluation -> recursive demand
forecasts -> inventory risk engine -> explainable recommendations -> what-if simulator.

Use the pages in the left sidebar:

1. **Executive Overview** - KPIs, forecast, prioritised inventory risks
2. **Demand Forecasting** - 7/30-day forecasts, model comparison, held-out actual vs predicted
3. **Inventory Intelligence** - reorder points, safety stock, recommended orders (CSV export)
4. **Product Analytics** - EDA, pricing, clustering, customer engagement
5. **Anomaly Monitoring** - unusual demand with inventory impact and investigation status
6. **Forecast Simulator** - change stock, lead time, discount and see the decision recalculate
7. **Data & Model Management** - upload CSV, validate, train/retrain, reset demo data
""")
if bundle is None:
    st.info("Models are trained automatically the first time you open a forecasting page (about 30-60 seconds), "
            "or train them now from page 7.")
st.caption("Everything runs locally: pandas, scikit-learn, Plotly, SQLite. No external services.")
