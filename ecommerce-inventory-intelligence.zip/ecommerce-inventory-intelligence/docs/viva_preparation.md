# Viva preparation

## 1. How is this different from a recommendation system?
A recommender ranks *items for a customer* (what to show). This project forecasts *how many units will sell* and converts that into
*how much stock to hold/order*. Output = quantities and risk, evaluated with forecast-error metrics, not ranking metrics.

## 2. Why is demand forecasting useful?
Inventory decisions are made before demand is known. Too little stock = lost sales; too much = cash tied up and write-offs. A forecast
plus a lead-time-aware policy turns uncertainty into an order quantity.

## 3. Why does time-series validation matter?
Random splits let the model train on days *after* the ones it is tested on, so it can exploit future information and the reported error is
too optimistic. We split by time (train -> validation -> test) and evaluate with rolling-origin forecasts that mimic real use.
We pick the model on validation and touch the test window only to *report*.

## 4. How the algorithms work (short)
- **Seasonal naive**: tomorrow = same weekday last week. Strong, free baseline; any model must beat it.
- **Ridge regression**: linear model with an L2 penalty that shrinks coefficients (stable with correlated lags).
- **Random Forest**: many decorrelated decision trees on bootstrap samples; averages them; captures non-linearities/interactions.
- **HistGradientBoosting**: trees built sequentially, each correcting the previous ones' errors, on binned features (fast).
- **Isolation Forest**: random splits isolate outliers in fewer steps -> higher anomaly score.
- **K-Means**: assigns points to the nearest of k centroids; iterates; features are scaled so no variable dominates.

## 5. MAE, RMSE, WAPE
MAE = average absolute miss in units. RMSE = square-root of mean squared miss; punishes big misses. WAPE = total absolute error divided by
total actual sales (a % of volume; robust to zero-sales days). MAPE is shown only on days with >= 1 unit because it divides by actual.

## 6. How is data leakage prevented?
(1) Lags/rolling statistics are computed from days strictly before the prediction day. (2) Same-day views/add-to-cart are excluded.
(3) On-hand stock and generator parameters are not features. (4) Forecasts physically delete actuals after the forecast origin, then
feed each prediction forward (recursive). (5) Future price/promotion are explicit assumptions. (6) Tests alter future values and
assert features/forecasts do not change (`test_features_do_not_change_when_today_or_future_sales_change`,
`test_future_actuals_never_influence_a_forecast`).

## 7. Safety stock and reorder point
Reorder point = demand expected during lead time + safety stock. Safety stock buffers uncertainty: z x sqrt(P sigma_d^2 + d^2 sigma_L^2).
z comes from the service level (95% -> 1.645). Longer lead time or higher variability -> larger buffer. Order quantity tops the
inventory position (on-hand + on-order - backorders) up to target stock; on-order is counted once.

## 8. Why anomalies are not automatically business events
A flag means "unusual versus this product's recent history". It can be a promotion, a bulk order, a stock-out (zero sales), a site outage
or a data error. The app lists *hypotheses* and an investigation status; scores are not probabilities and do not predict persistence.

## 9. How clustering supports inventory planning
Products with similar volume/variability can share a policy: high-demand -> frequent review, higher service level; stable -> lean
automated replenishment; high-variability -> more safety stock; slow-moving -> small lots, watch overstock.

## 10. Key assumptions
No promotion/discount in future unless entered; price held; engagement held at 7-day mean; missing days = zero sales; on-order arrives
within lead time; independent daily errors in safety stock; observed sales (stock-out-censored) are the forecast target.

## 11. Limitations and improvements
See README sections 21-22: synthetic data, recursive error growth, empirical (not formal) ranges, no PO schedules/MOQ, no causal claims.

## 12. Likely questions
- **Did the complex model win?** Read it off the comparison table - the app does not presuppose it. On the demo data the three ML models
  were within a few WAPE points of each other and clearly ahead of the baseline; with other data that can change.
- **Why not use on-hand stock as a feature?** It is a decision outcome and censors sales; including it would confuse demand with supply.
- **Why is 30-day worse than 7-day?** Recursive predictions feed on earlier predictions, so errors compound.
- **Why validate AND test?** Validation chooses; test gives an unbiased check of the chosen model.
- **Is the discount effect causal?** No - it is what the model learned from history, where promotions also coincide with seasons/marketing.
- **What if the data has no inventory file?** Recommendations show "Unknown"; nothing is invented.
- **Why WAPE not MAPE?** Many days have 0-few units, making MAPE explode or undefined.
- **How is k chosen in clustering?** Silhouette score over k=2..6, user-overridable; profile names come from cluster means.
- **Are your accuracy numbers real?** They are measured on *synthetic* data by the app at run time; do not present them as business results.
