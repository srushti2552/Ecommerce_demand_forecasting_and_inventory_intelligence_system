# Demo guide (3-5 minutes)

Prep: `streamlit run app.py`; open page **Demand Forecasting** once so models are trained/cached. Keep the sidebar policy at its defaults.
Numbers below were observed in one run on the synthetic sample (seed 42) - yours should match closely but read them off the screen.

**0:00 - Overview (page 1).** "The sample is synthetic demonstration data (see the banner). Top cards show units, forecast demand,
critical/low and overstock counts, anomaly alerts." Point at the risk chart and the prioritised table.

**0:40 - Forecast (page 2).** Select **Wireless Earbuds**, horizon 7 then 30. Show history vs dashed future forecast and the estimated
band ("an estimate from past errors, not a guarantee"). Open *Model comparison*: naive baseline vs Ridge / Random Forest / HistGB;
selection used validation only, test column is held-out. *Held-out actual vs predicted* shows historical predictions, not the future.

**1:40 - Inventory risk (page 3).** Pick Wireless Earbuds in "Why this recommendation?". Read the explanation: position, lead-time
demand, safety stock, reorder point, target, order quantity. Open *Simplified example*: 245 + 30 = 275, minus 120 = 155 - "a teaching
simplification that ignores lead time and on-order stock; the real policy gives the number above."
Optionally filter Risk = Critical and export the CSV.

**2:30 - Simulator (page 6).** Product = Wireless Earbuds. Move **Supplier lead time 3 -> 10**. Observed: lead-time demand ~141 -> ~456,
reorder point ~246 -> ~590, order quantity ~51 -> ~403, risk Sufficient -> Low. Explain: longer lead time means more demand before stock
arrives, so order earlier or hold more safety stock. Then set **Planned discount 25%**: the *trained model* is re-run with that input;
note the tags - model prediction vs user assumption vs calculation. Show the manual adjustment is labelled "USER ASSUMPTION".

**3:40 - Anomalies & clusters (pages 5, 4).** Anomaly page: select a spike, show hypotheses ("not conclusions") and the inventory impact
text; set status to Investigating (saved in SQLite). Product Analytics -> Clusters: profiles derived from cluster statistics and the
policy suggestion for each.

**4:30 - Close.** Page 7: upload your own CSV, validation messages, retrain button, SQLite/storage explanation.
