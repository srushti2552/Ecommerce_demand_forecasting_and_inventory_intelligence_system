"""Orchestration: dataset context -> trained bundle -> forecasts -> inventory recommendations.

This module has no Streamlit dependency, so it is shared by the UI, the CLI scripts and the tests.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

import config
from src import database as db
from src import forecasting as fc
from src import model_evaluation as me
from src.feature_engineering import FeatureSpec, WideData
from src.inventory_engine import InventoryPolicy, compute_recommendations
from src.preprocessing import build_panel, aggregate_daily, inventory_from_panel, merge_inventory


@dataclass
class DatasetContext:
    key: str
    name: str
    is_synthetic: bool
    panel: pd.DataFrame
    meta: pd.DataFrame
    inventory: pd.DataFrame
    wide: WideData
    spec: FeatureSpec
    fingerprint: str
    notes: List[str] = field(default_factory=list)
    transactions: Optional[pd.DataFrame] = None
    validation_info: Dict[str, object] = field(default_factory=dict)

    @property
    def forecastable_products(self) -> List[str]:
        return self.meta.loc[self.meta["active"] & self.meta["history_ok"], "product_id"].tolist()

    @property
    def inactive_or_short(self) -> List[str]:
        return self.meta.loc[~(self.meta["active"] & self.meta["history_ok"]), "product_id"].tolist()

    @property
    def names(self) -> Dict[str, str]:
        return self.meta.set_index("product_id")["product_name"].to_dict()

    @property
    def categories(self) -> Dict[str, str]:
        return self.meta.set_index("product_id")["category"].to_dict()

    @property
    def last_date(self) -> pd.Timestamp:
        return self.panel["date"].max()


def fingerprint(panel: pd.DataFrame) -> str:
    h = hashlib.md5()
    h.update(f"{panel.shape}|{panel['date'].min()}|{panel['date'].max()}|{panel['units_sold'].sum():.3f}|{panel['product_id'].nunique()}".encode())
    return h.hexdigest()[:12]


def build_context(sales_clean: pd.DataFrame, inventory_clean: Optional[pd.DataFrame], key: str, name: str, is_synthetic: bool,
                  validation_info: Optional[dict] = None, persist: bool = True) -> DatasetContext:
    """validated sales rows (+ optional validated inventory snapshot) -> ready-to-use DatasetContext."""
    panel, meta, notes = build_panel(aggregate_daily(sales_clean))
    inv = merge_inventory(inventory_from_panel(panel, meta), inventory_clean)
    wide = WideData.from_panel(panel, meta)
    spec = FeatureSpec.from_panel(panel)
    tx = sales_clean if "customer_id" in sales_clean.columns else None
    ctx = DatasetContext(key, name, is_synthetic, panel, meta, inv, wide, spec, fingerprint(panel), notes, tx, validation_info or {})
    if persist:
        db.register_dataset(key, name, "synthetic" if is_synthetic else "upload", is_synthetic, len(sales_clean),
                            panel["product_id"].nunique(), panel["date"].min(), panel["date"].max(), validation_info)
        db.save_products(key, meta)
        saved = db.load_inventory(key)
        if saved.empty:
            db.save_inventory(key, inv)
        else:  # keep user edits to the inventory snapshot
            ctx.inventory = merge_inventory(inv.drop(columns=["on_hand", "on_order", "backorders", "lead_time_days",
                                                              "lead_time_std_days", "unit_cost"], errors="ignore")
                                            .reindex(columns=["product_id"]), saved)
    return ctx


def load_sample_context(persist: bool = True) -> DatasetContext:
    from src.data_loader import load_sample_data
    from src.data_validation import validate_sales, validate_inventory
    sales_raw, inv_raw = load_sample_data()
    rep = validate_sales(sales_raw)
    inv_rep = validate_inventory(inv_raw)
    return build_context(rep.cleaned, inv_rep.cleaned, "sample", "Sample (synthetic demonstration data)", True, rep.info, persist)


def get_or_train_bundle(ctx: DatasetContext, force: bool = False, progress: Optional[Callable[[float, str], None]] = None,
                        persist: bool = True) -> dict:
    """Load a saved bundle if it matches the current data; otherwise train, evaluate and save a new one."""
    if not force:
        b = fc.load_bundle(ctx.key)
        if b is not None and b.get("fingerprint") == ctx.fingerprint and b.get("version") == 1:
            return b
    b = me.train_and_evaluate(ctx.panel, ctx.meta, ctx.key, progress)
    b["fingerprint"] = ctx.fingerprint
    fc.save_bundle(b, ctx.key)
    if persist:
        db.save_model_run(ctx.key, b)
    return b


def hist_std_map(panel: pd.DataFrame, days: int = 56) -> Dict[str, float]:
    rec = panel[panel["date"] > panel["date"].max() - pd.Timedelta(days=days)]
    return rec.groupby("product_id")["units_sold"].std(ddof=0).to_dict()


def resid_std_map(bundle: dict, model_name: str) -> Dict[str, float]:
    r = bundle["residuals"]
    r = r[r["model"] == model_name]
    return r.set_index("product_id")["resid_std"].to_dict()


def forecast_products(ctx: DatasetContext, bundle: dict, model_name: Optional[str] = None, horizon: int = 30,
                      products: Optional[List[str]] = None, future_known: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    """Future forecast (after the last observed date) for forecastable products."""
    ok = set(ctx.forecastable_products)
    want = ok if products is None else ok.intersection(products)
    wide = ctx.wide if len(want) == len(ctx.wide.product_ids) else ctx.wide.subset(want)
    return fc.forecast_future(bundle, wide, model_name, horizon, None, future_known)


def needed_horizon(inventory: pd.DataFrame, policy: InventoryPolicy, minimum: int = 30) -> int:
    lt = pd.to_numeric(inventory.get("lead_time_days"), errors="coerce").fillna(policy.default_lead_time_days)
    need = int(np.ceil(lt.max() + policy.review_period_days)) if len(lt) else minimum
    return int(min(config.MAX_FORECAST_HORIZON, max(minimum, need)))


def recommendations_for(ctx: DatasetContext, bundle: dict, policy: InventoryPolicy, model_name: Optional[str] = None,
                        forecast: Optional[pd.DataFrame] = None, inventory: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    model_name = model_name or bundle["selected"]
    inv = ctx.inventory if inventory is None else inventory
    if forecast is None:
        forecast = forecast_products(ctx, bundle, model_name, needed_horizon(inv, policy))
    start = ctx.last_date + pd.Timedelta(days=1)
    return compute_recommendations(forecast, inv, policy, resid_std_map(bundle, model_name), hist_std_map(ctx.panel),
                                   ctx.names, ctx.categories, start_date=start)
