"""Plotly figure builders (no Streamlit dependency). All figures use one restrained colour palette."""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

PALETTE = ["#1f4e79", "#2e86ab", "#f18f01", "#c73e1d", "#6a994e", "#7b6d8d", "#8d99ae", "#b08968"]
RISK_COLORS = {"Critical Stock Risk": "#c73e1d", "Low Stock": "#f18f01", "Potential Overstock": "#7b6d8d",
               "Slow-Moving": "#8d99ae", "Sufficient Inventory": "#6a994e", "Unknown (stock data missing)": "#bbbbbb"}
BLUE, ORANGE, RED, GREEN, GREY = "#1f4e79", "#f18f01", "#c73e1d", "#6a994e", "#8d99ae"


def _style(fig: go.Figure, title: Optional[str] = None, height: int = 380) -> go.Figure:
    fig.update_layout(title=dict(text=title or "", font=dict(size=15)), height=height, margin=dict(l=10, r=10, t=45, b=10),
                      template="plotly_white", colorway=PALETTE, legend=dict(orientation="h", y=-0.2),
                      font=dict(size=12))
    return fig


def line_trend(df: pd.DataFrame, x: str, y: str, title: str, color: Optional[str] = None) -> go.Figure:
    fig = px.line(df, x=x, y=y, color=color)
    return _style(fig, title)


def bar(df: pd.DataFrame, x: str, y: str, title: str, color: Optional[str] = None, horizontal: bool = False) -> go.Figure:
    if horizontal:
        fig = px.bar(df, x=y, y=x, color=color, orientation="h")
        fig.update_layout(yaxis=dict(autorange="reversed"))
    else:
        fig = px.bar(df, x=x, y=y, color=color)
    return _style(fig, title)


def forecast_chart(hist: pd.DataFrame, fc_df: pd.DataFrame, title: str, history_days: int = 90, show_range: bool = True,
                   scenario: Optional[pd.DataFrame] = None) -> go.Figure:
    """hist: date, units_sold. fc_df: date, forecast (+ lower_est/upper_est). Future forecasts are visually distinct."""
    fig = go.Figure()
    h = hist.sort_values("date").tail(history_days)
    fig.add_trace(go.Scatter(x=h["date"], y=h["units_sold"], mode="lines", name="Actual (history)", line=dict(color=BLUE, width=2)))
    if show_range and "lower_est" in fc_df.columns and fc_df["lower_est"].notna().any():
        fig.add_trace(go.Scatter(x=list(fc_df["date"]) + list(fc_df["date"])[::-1],
                                 y=list(fc_df["upper_est"]) + list(fc_df["lower_est"])[::-1], fill="toself",
                                 fillcolor="rgba(241,143,1,0.15)", line=dict(width=0), name="Estimated range (backtest residuals)",
                                 hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=fc_df["date"], y=fc_df["forecast"], mode="lines+markers", name="Forecast (future)",
                             line=dict(color=ORANGE, width=2, dash="dash")))
    if scenario is not None:
        fig.add_trace(go.Scatter(x=scenario["date"], y=scenario["forecast"], mode="lines+markers", name="Scenario forecast",
                                 line=dict(color=RED, width=2)))
    fig.update_yaxes(title="Units per day", rangemode="tozero")
    return _style(fig, title)


def actual_vs_pred_chart(df: pd.DataFrame, title: str) -> go.Figure:
    """df: date, actual, pred (historical hold-out predictions - NOT future forecasts)."""
    d = df.sort_values("date")
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=d["date"], y=d["actual"], mode="lines", name="Actual", line=dict(color=BLUE, width=2)))
    fig.add_trace(go.Scatter(x=d["date"], y=d["pred"], mode="lines", name="Predicted (held-out)", line=dict(color=ORANGE, width=2, dash="dot")))
    fig.update_yaxes(title="Units per day", rangemode="tozero")
    return _style(fig, title)


def model_comparison_bar(comp: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Bar(x=comp["model"], y=comp["WAPE_val"], name="Validation WAPE", marker_color=BLUE))
    if "WAPE_test" in comp.columns:
        fig.add_trace(go.Bar(x=comp["model"], y=comp["WAPE_test"], name="Test WAPE (not used for selection)", marker_color=GREY))
    fig.update_layout(barmode="group", yaxis=dict(title="WAPE (lower is better)", tickformat=".0%"))
    return _style(fig, "Model comparison - WAPE")


def risk_bar(rec: pd.DataFrame) -> go.Figure:
    c = rec["risk_level"].value_counts().rename_axis("risk").reset_index(name="products")
    fig = px.bar(c, x="risk", y="products", color="risk", color_discrete_map=RISK_COLORS)
    fig.update_layout(showlegend=False, xaxis_title="")
    return _style(fig, "Products by inventory risk", 320)


def stock_vs_reorder_chart(rec: pd.DataFrame, top: int = 15) -> go.Figure:
    d = rec.head(top).iloc[::-1]
    fig = go.Figure()
    fig.add_trace(go.Bar(y=d["product_name"], x=d["inventory_position"], orientation="h", name="Inventory position", marker_color=BLUE))
    fig.add_trace(go.Scatter(y=d["product_name"], x=d["reorder_point"], mode="markers", name="Reorder point",
                             marker=dict(color=RED, symbol="diamond", size=10)))
    fig.update_layout(xaxis_title="Units")
    return _style(fig, "Inventory position vs reorder point (highest risk first)", max(320, 26 * len(d) + 120))


def inventory_waterfall(r: dict) -> go.Figure:
    """Visualise how the recommended order is built from the engine's own figures."""
    labels = ["Lead-time demand", "Review-period demand", "Safety stock", "Target stock", "Inventory position", "Order qty"]
    vals = [r["lead_time_demand"], r["review_period_demand"], r["safety_stock"], r["target_stock"], r["inventory_position"], r["recommended_order_qty"]]
    colors = [BLUE, BLUE, BLUE, GREEN, GREY, ORANGE]
    fig = go.Figure(go.Bar(x=labels, y=vals, marker_color=colors, text=[f"{v:.0f}" for v in vals], textposition="outside"))
    fig.update_yaxes(title="Units")
    return _style(fig, "How the recommendation is built", 330)


def scenario_compare_chart(dates, baseline, scenario, title="Original vs scenario forecast") -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dates, y=baseline, mode="lines", name="Original forecast", line=dict(color=BLUE, width=2)))
    fig.add_trace(go.Scatter(x=dates, y=scenario, mode="lines", name="Scenario forecast", line=dict(color=RED, width=2, dash="dash")))
    fig.update_yaxes(title="Units per day", rangemode="tozero")
    return _style(fig, title)


def stock_projection_chart(dates, daily, on_hand, lead_time, title="Projected on-hand stock (no new orders)") -> go.Figure:
    proj = on_hand - np.cumsum(np.asarray(daily, dtype=float))
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dates, y=np.maximum(proj, 0), mode="lines", name="Projected on-hand", line=dict(color=BLUE, width=2)))
    if 0 < lead_time <= len(dates):
        x = pd.Timestamp(dates[int(max(0, np.ceil(lead_time) - 1))]).to_pydatetime()
        fig.add_shape(type="line", x0=x, x1=x, y0=0, y1=1, yref="paper", line=dict(color=RED, dash="dot"))
        fig.add_annotation(x=x, y=1, yref="paper", text="earliest new delivery", showarrow=False, font=dict(color=RED), yanchor="bottom")
    fig.update_yaxes(title="Units", rangemode="tozero")
    return _style(fig, title, 320)


def anomaly_chart(series: pd.DataFrame, anomalies: pd.DataFrame, title: str) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=series["date"], y=series["units_sold"], mode="lines", name="Units sold", line=dict(color=BLUE, width=1.5)))
    if len(anomalies):
        for direction, color in (("Spike", RED), ("Drop", ORANGE)):
            a = anomalies[anomalies["direction"] == direction]
            if len(a):
                fig.add_trace(go.Scatter(x=a["date"], y=a["units_sold"], mode="markers", name=direction,
                                         marker=dict(color=color, size=9, symbol="circle-open", line=dict(width=2))))
    fig.update_yaxes(title="Units per day", rangemode="tozero")
    return _style(fig, title)


def cluster_scatter(prod: pd.DataFrame) -> go.Figure:
    fig = px.scatter(prod, x="avg_daily_units", y="cv", color="profile", size="revenue" if "revenue" in prod.columns else None,
                     hover_name="product_name", log_x=True)
    fig.update_layout(xaxis_title="Average daily units (log scale)", yaxis_title="Demand variability (CV)")
    return _style(fig, "Product clusters", 420)


def heatmap(df: pd.DataFrame, title: str) -> go.Figure:
    fig = px.imshow(df, aspect="auto", color_continuous_scale="Blues")
    return _style(fig, title)
