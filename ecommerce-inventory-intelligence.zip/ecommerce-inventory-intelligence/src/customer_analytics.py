"""Engagement and customer-behaviour analytics that adapt to the fields that are actually present.

Product-level engagement (views, add-to-cart, units) is NOT individual customer behaviour. Customer-level metrics
(repeat purchase, frequency, segments) are only computed when a real customer_id column exists.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd


def engagement_available(panel: pd.DataFrame) -> Dict[str, bool]:
    has = lambda c: c in panel.columns and panel[c].notna().any() and panel[c].fillna(0).sum() > 0  # noqa: E731
    return {"views": has("views"), "add_to_cart": has("add_to_cart"), "rating": has("rating")}


def engagement_by_product(panel: pd.DataFrame) -> Optional[pd.DataFrame]:
    """Product-level funnel. Units sold is used as a proxy for purchases (it counts units, not orders)."""
    av = engagement_available(panel)
    if not av["views"]:
        return None
    g = panel.groupby("product_id")
    out = pd.DataFrame({"views": g["views"].sum(), "units_sold": g["units_sold"].sum()})
    out["view_to_purchase_rate"] = out["units_sold"] / out["views"].replace(0, np.nan)
    if av["add_to_cart"]:
        out["add_to_cart"] = g["add_to_cart"].sum()
        out["view_to_cart_rate"] = out["add_to_cart"] / out["views"].replace(0, np.nan)
        out["cart_to_purchase_rate"] = (out["units_sold"] / out["add_to_cart"].replace(0, np.nan)).clip(upper=1.0)
        out["cart_abandonment_proxy"] = 1 - out["cart_to_purchase_rate"]
    out = out.join(panel.groupby("product_id")[["product_name", "category"]].last())
    return out.reset_index()


def engagement_by_category(panel: pd.DataFrame) -> Optional[pd.DataFrame]:
    p = engagement_by_product(panel)
    if p is None:
        return None
    cols = [c for c in ["views", "add_to_cart", "units_sold"] if c in p.columns]
    c = p.groupby("category")[cols].sum()
    c["view_to_purchase_rate"] = c["units_sold"] / c["views"].replace(0, np.nan)
    if "add_to_cart" in c.columns:
        c["cart_abandonment_proxy"] = 1 - (c["units_sold"] / c["add_to_cart"].replace(0, np.nan)).clip(upper=1.0)
    return c.reset_index()


def customer_metrics(transactions: pd.DataFrame) -> Dict[str, object]:
    """Customer-level metrics from validated transactions that include a real customer_id column."""
    if transactions is None or "customer_id" not in transactions.columns or transactions["customer_id"].isna().all():
        return {"available": False, "message": "No customer_id column was provided, so customer-level analytics (repeat "
                "purchase rate, purchase frequency, segments) are not computed. Product-level engagement is shown instead."}
    t = transactions.dropna(subset=["customer_id"]).copy()
    t["customer_id"] = t["customer_id"].astype(str)
    cust = t.groupby("customer_id").agg(orders=("date", "nunique"), units=("units_sold", "sum"),
                                         first=("date", "min"), last=("date", "max"))
    ref = t["date"].max()
    cust["recency_days"] = (ref - cust["last"]).dt.days
    cust["is_repeat"] = cust["orders"] > 1
    out: Dict[str, object] = {"available": True, "n_customers": len(cust), "repeat_rate": float(cust["is_repeat"].mean()),
                              "avg_orders_per_customer": float(cust["orders"].mean())}
    if len(cust) >= 20:
        r = pd.qcut(cust["recency_days"].rank(method="first"), 3, labels=["Recent", "Mid", "Lapsed"])
        f = pd.qcut(cust["orders"].rank(method="first"), 3, labels=["Low", "Mid", "High"])
        cust["segment"] = np.where((f == "High") & (r == "Recent"), "Loyal / active",
                          np.where(r == "Lapsed", "At risk / lapsed", "Developing"))
        out["segments"] = cust["segment"].value_counts().rename_axis("segment").reset_index(name="customers")
    out["customers"] = cust.reset_index()
    return out
