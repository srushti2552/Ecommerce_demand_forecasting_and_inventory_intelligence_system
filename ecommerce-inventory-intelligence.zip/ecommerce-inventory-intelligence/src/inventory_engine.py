"""Inventory intelligence engine (pure functions - no UI, no ML imports, fully unit-testable).

FORMULAS (all documented in the README)
---------------------------------------
Lead-Time Demand (LTD)   = sum of forecast daily demand over the supplier lead time L
Review-period demand     = sum of forecast daily demand over the NEXT review period R, i.e. days L .. L+R
Safety Stock (SS), protection interval P = L + R:
    statistical : SS = z * sqrt( P * sigma_d^2 + d_avg^2 * sigma_L^2 )
                  z = Normal quantile of the target service level, sigma_d = std of daily forecast error,
                  sigma_L = std of lead time (days; 0 when unknown)
    days        : SS = safety_days * d_avg                  (policy assumption)
    units       : SS = fixed number of units                (policy assumption)
Reorder Point (ROP)      = LTD + SS
Inventory Position (IP)  = On-Hand + On-Order - Backorders
Target Stock (order-up-to) = LTD + Review-period demand + SS
Recommended Order Qty    = max(0, ceil(Target Stock - IP))
On-order stock is counted exactly once (inside IP); it is NOT also added to on-hand coverage.
Arrival dates of open purchase orders are not modelled: they are assumed to arrive within the lead time.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date as _date
from statistics import NormalDist
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import config

CRITICAL, LOW, OVERSTOCK, SLOW, SUFFICIENT, UNKNOWN = (
    "Critical Stock Risk", "Low Stock", "Potential Overstock", "Slow-Moving", "Sufficient Inventory", "Unknown (stock data missing)")
RISK_RANK = {CRITICAL: 0, LOW: 1, OVERSTOCK: 2, SLOW: 3, SUFFICIENT: 4, UNKNOWN: 5}
COVER_CAP_DAYS = 365.0


@dataclass(frozen=True)
class InventoryPolicy:
    review_period_days: float = config.DEFAULT_REVIEW_PERIOD_DAYS
    service_level: float = config.DEFAULT_SERVICE_LEVEL
    safety_method: str = "statistical"          # 'statistical' | 'days' | 'units'
    safety_days: float = config.DEFAULT_SAFETY_DAYS
    safety_units: float = 0.0
    default_lead_time_days: float = config.DEFAULT_LEAD_TIME_DAYS
    critical_cover_days: float = config.CRITICAL_COVER_DAYS
    overstock_extra_cover_days: float = config.OVERSTOCK_EXTRA_COVER_DAYS
    overstock_target_multiple: float = config.OVERSTOCK_TARGET_MULTIPLE
    slow_moving_daily_demand: float = 1.0       # units/day below which a product is "slow"
    slow_cover_days: float = 60.0               # ...and cover above this many days


def resolve_slow_threshold(policy: InventoryPolicy, portfolio_daily_rates, percentile: float = config.SLOW_MOVING_PERCENTILE) -> InventoryPolicy:
    """Data-driven slow-moving threshold: the given percentile of forecast daily demand across the portfolio."""
    rates = np.asarray([r for r in portfolio_daily_rates if np.isfinite(r)], dtype=float)
    if len(rates) < 5:
        return policy
    return replace(policy, slow_moving_daily_demand=float(np.percentile(rates, percentile)))


# ---- building blocks -------------------------------------------------------------------
def demand_over(daily, days: float) -> Tuple[float, bool]:
    """Sum forecast demand over the first ``days`` days (fractional days allowed).

    If the forecast array is shorter than needed it is extended with the mean of its last 7 values and
    the second return value (extrapolated) is True.
    """
    daily = np.asarray(daily, dtype=float)
    days = max(0.0, float(days))
    n = int(np.floor(days))
    frac = days - n
    need = n + (1 if frac > 0 else 0)
    extrapolated = False
    if need > len(daily):
        tail = float(daily[-7:].mean()) if len(daily) else 0.0
        daily = np.concatenate([daily, np.full(need - len(daily), tail)])
        extrapolated = True
    total = float(daily[:n].sum()) + (float(daily[n]) * frac if frac > 0 else 0.0)
    return total, extrapolated


def demand_between(daily, start_day: float, end_day: float) -> Tuple[float, bool]:
    a, e1 = demand_over(daily, start_day)
    b, e2 = demand_over(daily, end_day)
    return max(0.0, b - a), (e1 or e2)


def z_value(service_level: float) -> float:
    return NormalDist().inv_cdf(float(np.clip(service_level, 0.50, 0.9999)))


def safety_stock(policy: InventoryPolicy, avg_daily: float, sigma_daily: Optional[float],
                 lead_time: float, lead_time_std: float, review_period: float) -> Tuple[float, str]:
    """Return (safety stock units, human-readable method note)."""
    protection = max(0.0, lead_time + review_period)
    if policy.safety_method == "units":
        return max(0.0, float(policy.safety_units)), f"fixed policy buffer of {policy.safety_units:g} units (assumption)"
    if policy.safety_method == "days":
        return max(0.0, policy.safety_days * avg_daily), f"{policy.safety_days:g} days of average demand (policy assumption)"
    if sigma_daily is None or not np.isfinite(sigma_daily):
        ss = max(0.0, policy.safety_days * avg_daily)
        return ss, f"no error statistics available -> fell back to {policy.safety_days:g} days of demand (assumption)"
    z = z_value(policy.service_level)
    var = protection * sigma_daily ** 2 + (avg_daily ** 2) * (max(0.0, lead_time_std) ** 2)
    return float(z * np.sqrt(var)), (f"z({policy.service_level:.0%})={z:.2f} x sqrt({protection:g} d x {sigma_daily:.2f}^2 + "
                                     f"{avg_daily:.2f}^2 x {lead_time_std:g}^2)")


def inventory_position(on_hand: float, on_order: float = 0.0, backorders: float = 0.0) -> float:
    return float(on_hand) + float(on_order) - float(backorders)


def coverage_days(daily, stock: float) -> float:
    """Days until cumulative forecast demand exhausts ``stock`` (capped at 365; inf-safe)."""
    daily = np.asarray(daily, dtype=float)
    if stock <= 0:
        return 0.0
    cum = np.cumsum(daily)
    idx = int(np.searchsorted(cum, stock, side="left"))
    if idx < len(daily):
        prev = cum[idx - 1] if idx > 0 else 0.0
        d = daily[idx]
        return float(idx + ((stock - prev) / d if d > 0 else 0.0))
    rate = float(daily[-7:].mean()) if len(daily) else 0.0
    remaining = stock - (cum[-1] if len(cum) else 0.0)
    if rate <= 1e-9:
        return COVER_CAP_DAYS
    return float(min(COVER_CAP_DAYS, len(daily) + remaining / rate))


def simplified_cover_horizon(on_hand: float, horizon_forecast: float, safety_allowance: float) -> Dict[str, float]:
    """The simplified teaching policy: stock must cover the ENTIRE horizon forecast plus a safety allowance.

    Required = forecast + safety ; Additional = max(0, Required - On-Hand). Example: 245 + 30 = 275; 275 - 120 = 155.
    """
    required = float(horizon_forecast) + float(safety_allowance)
    return {"required_stock": required, "additional_stock": max(0.0, required - float(on_hand))}


# ---- one product -----------------------------------------------------------------------
def _num(x, default=None):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if np.isfinite(v) else default


def compute_product_inventory(daily_forecast, on_hand, on_order=None, backorders=None, lead_time_days=None,
                              lead_time_std_days=None, policy: Optional[InventoryPolicy] = None,
                              resid_std: Optional[float] = None, hist_std: Optional[float] = None,
                              product_name: str = "Product", start_date=None) -> Dict[str, object]:
    """Full inventory calculation + classification + explanation for one product."""
    policy = policy or InventoryPolicy()
    daily = np.clip(np.nan_to_num(np.asarray(daily_forecast, dtype=float), nan=0.0), 0, None)
    flags: List[str] = []
    on_hand_v = _num(on_hand)
    L = _num(lead_time_days)
    if L is None or L <= 0:
        L = float(policy.default_lead_time_days)
        flags.append(f"Lead time not provided - assumed {L:g} days (policy default)")
    sigma_L = _num(lead_time_std_days)
    if sigma_L is None:
        sigma_L = 0.0
        flags.append("Lead-time variability unknown - assumed 0")
    oo = _num(on_order)
    if oo is None:
        oo = 0.0
        flags.append("On-order stock not provided - assumed 0")
    bo = _num(backorders)
    if bo is None:
        bo = 0.0
        flags.append("Backorders not provided - assumed 0")
    R = max(0.0, float(policy.review_period_days))

    horizon_n = min(len(daily), 30) if len(daily) else 0
    avg_daily = float(daily[:horizon_n].mean()) if horizon_n else 0.0
    ltd, e1 = demand_over(daily, L)
    rpd, e2 = demand_between(daily, L, L + R)
    if e1 or e2:
        flags.append("Forecast horizon shorter than lead time + review period - tail extrapolated at the last 7-day mean")
    sigma_d, sigma_src = resid_std, "backtest forecast error"
    if sigma_d is None or not np.isfinite(sigma_d):
        sigma_d, sigma_src = hist_std, "historical daily std (conservative proxy)"
    ss, ss_note = safety_stock(policy, avg_daily, sigma_d, L, sigma_L, R)
    if policy.safety_method == "statistical":
        ss_note += f"; sigma_d from {sigma_src if sigma_d is not None else 'n/a'}"
    rop = ltd + ss
    target = ltd + rpd + ss

    out: Dict[str, object] = {
        "product_name": product_name, "avg_daily_forecast": avg_daily, "lead_time_days": L, "lead_time_std_days": sigma_L,
        "review_period_days": R, "lead_time_demand": ltd, "review_period_demand": rpd, "safety_stock": ss,
        "safety_stock_method": ss_note, "reorder_point": rop, "target_stock": target,
        "on_hand": on_hand_v, "on_order": oo, "backorders": bo, "assumptions": flags,
        "forecast_7d": float(daily[:7].sum()), "forecast_30d": float(demand_over(daily, 30)[0]),
    }
    if on_hand_v is None:
        out.update({"inventory_position": np.nan, "recommended_order_qty": np.nan, "coverage_days_on_hand": np.nan,
                    "coverage_days_position": np.nan, "risk_level": UNKNOWN, "reasons": ["Current on-hand stock is missing, so no stock decision can be made."],
                    "days_until_order_deadline": np.nan, "expected_stockout_date": None})
        out["explanation"] = f"**{UNKNOWN.upper()} - {product_name}**: no current on-hand stock was provided, so the application does not guess a recommendation."
        return out

    pos = inventory_position(on_hand_v, oo, bo)
    qty = float(max(0, int(np.ceil(target - pos - 1e-9)))) if target - pos > 0 else 0.0
    cov_hand = coverage_days(daily, max(0.0, on_hand_v))
    cov_pos = coverage_days(daily, max(0.0, pos))
    out.update({"inventory_position": pos, "recommended_order_qty": qty, "coverage_days_on_hand": cov_hand,
                "coverage_days_position": cov_pos, "days_until_order_deadline": cov_hand - L})
    stockout = None
    if start_date is not None and cov_hand < COVER_CAP_DAYS:
        stockout = (pd.Timestamp(start_date) + pd.Timedelta(days=int(np.floor(cov_hand)))).date()
    out["expected_stockout_date"] = stockout

    # ---- classification (first matching rule wins) ----
    reasons: List[str] = []
    demand_positive = avg_daily > 1e-9
    if pos < ltd - 1e-9:
        risk = CRITICAL
        reasons.append(f"Inventory position ({pos:.0f}) is below the expected demand during lead time ({ltd:.0f}) - even with all stock on order it cannot cover the wait for a new delivery.")
    elif demand_positive and cov_hand < policy.critical_cover_days:
        risk = CRITICAL
        reasons.append(f"On-hand stock covers only {cov_hand:.1f} days of forecast demand (critical threshold {policy.critical_cover_days:g} days).")
    elif pos < rop - 1e-9:
        risk = LOW
        reasons.append(f"Inventory position ({pos:.0f}) has fallen below the reorder point ({rop:.0f}).")
    elif (avg_daily < policy.slow_moving_daily_demand) and cov_pos > policy.slow_cover_days:
        risk = SLOW
        reasons.append(f"Forecast demand is only {avg_daily:.2f} units/day (below {policy.slow_moving_daily_demand:.2f}) while stock position covers {_fmt_days(cov_pos)}.")
    elif pos > policy.overstock_target_multiple * target and cov_pos > (L + R + policy.overstock_extra_cover_days):
        risk = OVERSTOCK
        reasons.append(f"Inventory position ({pos:.0f}) is more than {policy.overstock_target_multiple:g}x the target stock ({target:.0f}) and covers {_fmt_days(cov_pos)}, well beyond lead time + review period ({L + R:g} days).")
    else:
        risk = SUFFICIENT
        reasons.append(f"Inventory position ({pos:.0f}) is at or above the reorder point ({rop:.0f}) and not excessive relative to target stock ({target:.0f}).")
    out["risk_level"] = risk
    out["reasons"] = reasons
    out["explanation"] = explain(out)
    return out


def _fmt_days(d: float) -> str:
    return f"{COVER_CAP_DAYS:.0f}+ days" if d >= COVER_CAP_DAYS - 1e-6 else f"{d:.1f} days"


def explain(r: Dict[str, object]) -> str:
    """Plain-language explanation containing every figure used, so it can be verified by hand."""
    name = r["product_name"]
    head = f"**{str(r['risk_level']).upper()} - {name}**"
    pos_line = (f"Inventory position = on-hand {r['on_hand']:.0f} + on-order {r['on_order']:.0f} - backorders {r['backorders']:.0f} "
                f"= **{r['inventory_position']:.0f}** units.")
    ltd_line = (f"Lead-time demand = {r['lead_time_demand']:.0f} units over {r['lead_time_days']:g} days; safety stock = "
                f"{r['safety_stock']:.0f} ({r['safety_stock_method']}); reorder point = {r['reorder_point']:.0f}.")
    tgt_line = (f"Target stock = lead-time demand {r['lead_time_demand']:.0f} + review-period demand {r['review_period_demand']:.0f} "
                f"({r['review_period_days']:g} d) + safety stock {r['safety_stock']:.0f} = **{r['target_stock']:.0f}**.")
    q = r["recommended_order_qty"]
    if q > 0:
        action = f"Recommended action: order **{q:.0f} units** now (target {r['target_stock']:.0f} - position {r['inventory_position']:.0f})."
        if r["days_until_order_deadline"] <= 0:
            action += f" On-hand stock lasts about {_fmt_days(r['coverage_days_on_hand'])}, which is shorter than the {r['lead_time_days']:g}-day lead time, so a stock-out before delivery is likely."
        else:
            when = "today" if r["days_until_order_deadline"] < 1 else f"within ~{r['days_until_order_deadline']:.0f} days"
            action += f" On-hand stock lasts about {_fmt_days(r['coverage_days_on_hand'])}; place the order {when} so it arrives before stock runs out."
    else:
        action = "Recommended action: no order needed now; inventory position already meets the target."
    reason = " ".join(r["reasons"])
    extra = ""
    if r["assumptions"]:
        extra = "\n\nAssumptions: " + "; ".join(r["assumptions"]) + "."
    return f"{head}\n\nReason: {reason}\n\n{pos_line}\n{ltd_line}\n{tgt_line}\n\n{action}{extra}"


# ---- whole portfolio -------------------------------------------------------------------
def compute_recommendations(forecast_long: pd.DataFrame, inventory: pd.DataFrame, policy: Optional[InventoryPolicy] = None,
                            resid_std: Optional[Dict[str, float]] = None, hist_std: Optional[Dict[str, float]] = None,
                            names: Optional[Dict[str, str]] = None, categories: Optional[Dict[str, str]] = None,
                            start_date=None, auto_slow_threshold: bool = True) -> pd.DataFrame:
    """Run the engine for every product that has both a forecast and an inventory record."""
    policy = policy or InventoryPolicy()
    resid_std, hist_std, names, categories = resid_std or {}, hist_std or {}, names or {}, categories or {}
    fc = {pid: g.sort_values("date")["forecast"].to_numpy() for pid, g in forecast_long.groupby("product_id")}
    if auto_slow_threshold and fc:
        policy = resolve_slow_threshold(policy, [float(v[:30].mean()) for v in fc.values()])
    inv = inventory.set_index("product_id") if "product_id" in inventory.columns else inventory
    rows = []
    for pid, daily in fc.items():
        rec = inv.loc[pid] if pid in inv.index else pd.Series(dtype=float)
        res = compute_product_inventory(
            daily, rec.get("on_hand"), rec.get("on_order"), rec.get("backorders"), rec.get("lead_time_days"),
            rec.get("lead_time_std_days"), policy, resid_std.get(pid), hist_std.get(pid), names.get(pid, pid), start_date)
        res["product_id"] = pid
        res["category"] = categories.get(pid, "")
        res["unit_cost"] = _num(rec.get("unit_cost"))
        rows.append(res)
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["assumptions"] = df["assumptions"].apply(lambda a: "; ".join(a))
    df["reasons"] = df["reasons"].apply(lambda a: " ".join(a))
    df["_rank"] = df["risk_level"].map(RISK_RANK)
    df = df.sort_values(["_rank", "coverage_days_on_hand"]).drop(columns="_rank").reset_index(drop=True)
    df.attrs["slow_threshold"] = policy.slow_moving_daily_demand
    return df


RECOMMENDATION_EXPORT_COLUMNS = [
    "product_id", "product_name", "category", "risk_level", "on_hand", "on_order", "backorders", "inventory_position",
    "forecast_7d", "forecast_30d", "avg_daily_forecast", "lead_time_days", "lead_time_demand", "safety_stock",
    "reorder_point", "target_stock", "recommended_order_qty", "coverage_days_on_hand", "expected_stockout_date",
    "reasons", "assumptions"]
