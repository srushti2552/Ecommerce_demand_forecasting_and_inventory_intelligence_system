"""Exploratory data analysis: pure pandas functions returning tables + data-driven interpretation text."""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from src.preprocessing import revenue_series


def filter_panel(panel: pd.DataFrame, products: Optional[Sequence[str]] = None, categories: Optional[Sequence[str]] = None,
                 date_range=None) -> pd.DataFrame:
    df = panel
    if categories:
        df = df[df["category"].isin(categories)]
    if products:
        df = df[df["product_id"].isin(products)]
    if date_range is not None and len(date_range) == 2:
        df = df[(df["date"] >= pd.Timestamp(date_range[0])) & (df["date"] <= pd.Timestamp(date_range[1]))]
    return df


def with_revenue(panel: pd.DataFrame) -> pd.DataFrame:
    df = panel.copy()
    rev = revenue_series(df)
    if rev is not None:
        df["revenue"] = rev
    return df


def kpis(panel: pd.DataFrame) -> Dict[str, object]:
    if panel.empty:
        return {"total_units": 0, "total_revenue": None, "n_products": 0, "n_categories": 0, "n_days": 0, "avg_daily_units": 0.0}
    rev = revenue_series(panel)
    n_days = int(panel["date"].nunique())
    return {"total_units": float(panel["units_sold"].sum()), "total_revenue": None if rev is None else float(rev.sum()),
            "n_products": int(panel["product_id"].nunique()), "n_categories": int(panel["category"].nunique()),
            "n_days": n_days, "avg_daily_units": float(panel["units_sold"].sum() / max(1, n_days)),
            "date_min": panel["date"].min(), "date_max": panel["date"].max()}


def category_sales(panel: pd.DataFrame) -> pd.DataFrame:
    df = with_revenue(panel)
    agg = {"units": ("units_sold", "sum"), "products": ("product_id", "nunique")}
    if "revenue" in df.columns:
        agg["revenue"] = ("revenue", "sum")
    return df.groupby("category").agg(**agg).sort_values("units", ascending=False).reset_index()


def product_table(panel: pd.DataFrame, recent_days: int = 90) -> pd.DataFrame:
    df = with_revenue(panel)
    last = df["date"].max()
    rec = df[df["date"] > last - pd.Timedelta(days=recent_days)]
    g = df.groupby("product_id")
    out = pd.DataFrame({"product_name": g["product_name"].last(), "category": g["category"].last(),
                        "total_units": g["units_sold"].sum(), "avg_daily_units": g["units_sold"].mean(),
                        "std_daily_units": g["units_sold"].std(ddof=0)})
    out["cv"] = out["std_daily_units"] / out["avg_daily_units"].replace(0, np.nan)
    out["recent_avg_daily"] = rec.groupby("product_id")["units_sold"].mean()
    if "revenue" in df.columns:
        out["total_revenue"] = g["revenue"].sum()
    return out.reset_index()


def top_products(panel: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    t = product_table(panel)
    return t.sort_values("total_units", ascending=False).head(n)


def slow_products(panel: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    t = product_table(panel)
    return t.sort_values("recent_avg_daily").head(n)


def trend(panel: pd.DataFrame, freq: str = "D") -> pd.DataFrame:
    df = with_revenue(panel)
    rule = {"D": "D", "W": "W-SUN", "M": "MS"}[freq]
    agg = {"units": ("units_sold", "sum")}
    if "revenue" in df.columns:
        agg["revenue"] = ("revenue", "sum")
    out = df.set_index("date").resample(rule).agg({"units_sold": "sum", **({"revenue": "sum"} if "revenue" in df.columns else {})})
    return out.rename(columns={"units_sold": "units"}).reset_index()


def dow_pattern(panel: pd.DataFrame) -> pd.DataFrame:
    d = panel.groupby(["product_id", panel["date"].dt.dayofweek])["units_sold"].mean().rename("avg").reset_index()
    d["rel"] = d["avg"] / d.groupby("product_id")["avg"].transform("mean").replace(0, np.nan)
    out = d.groupby("date")["rel"].mean().rename("relative_demand").reset_index().rename(columns={"date": "dow"})
    out["day"] = out["dow"].map(dict(enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])))
    return out


def monthly_seasonality(panel: pd.DataFrame) -> Optional[pd.DataFrame]:
    span = (panel["date"].max() - panel["date"].min()).days
    if span < 365:
        return None
    d = panel.groupby(["product_id", panel["date"].dt.month])["units_sold"].mean().rename("avg").reset_index()
    d["rel"] = d["avg"] / d.groupby("product_id")["avg"].transform("mean").replace(0, np.nan)
    out = d.groupby("date")["rel"].mean().rename("seasonal_index").reset_index().rename(columns={"date": "month"})
    return out


def discount_relationship(panel: pd.DataFrame) -> Optional[pd.DataFrame]:
    """Average relative demand by discount bucket (each product's sales divided by its own average)."""
    if "discount_pct" not in panel.columns or panel["discount_pct"].fillna(0).nunique() < 2:
        return None
    d = panel.copy()
    d["rel_units"] = d["units_sold"] / d.groupby("product_id")["units_sold"].transform("mean").replace(0, np.nan)
    bins = [-0.01, 0, 10, 20, 30, 100]
    d["discount_band"] = pd.cut(d["discount_pct"].fillna(0), bins=bins, labels=["0%", "1-10%", "11-20%", "21-30%", ">30%"])
    out = d.groupby("discount_band", observed=True).agg(avg_relative_demand=("rel_units", "mean"), days=("rel_units", "size")).reset_index()
    return out


def price_demand_points(panel: pd.DataFrame) -> Optional[pd.DataFrame]:
    if not panel["unit_price"].notna().any():
        return None
    g = panel.groupby("product_id")
    return pd.DataFrame({"product_name": g["product_name"].last(), "avg_price": g["unit_price"].mean(),
                         "avg_daily_units": g["units_sold"].mean()}).reset_index()


def variability_table(panel: pd.DataFrame) -> pd.DataFrame:
    t = product_table(panel)
    return t[["product_id", "product_name", "category", "avg_daily_units", "std_daily_units", "cv"]].sort_values("cv", ascending=False)


def quality_summary(panel: pd.DataFrame, validation_info: Optional[dict] = None) -> pd.DataFrame:
    rows = [("Rows in daily panel", len(panel)), ("Products", panel["product_id"].nunique()),
            ("Days with no source row (filled with 0)", int((~panel["observed"]).sum()) if "observed" in panel.columns else 0),
            ("Days with zero sales", int((panel["units_sold"] == 0).sum()))]
    for c in ["unit_price", "discount_pct", "views", "add_to_cart", "on_hand", "lead_time_days", "unit_cost", "rating"]:
        rows.append((f"Missing '{c}'", int(panel[c].isna().sum()) if c in panel.columns else "column absent"))
    vi = validation_info or {}
    for k in ("rows_uploaded", "exact_duplicates_removed", "rows_sharing_date_product_key"):
        if k in vi:
            rows.append((k.replace("_", " ").capitalize(), vi[k]))
    return pd.DataFrame(rows, columns=["Check", "Value"])


# ---- interpretation text (derived from the data, hedged for correlation vs causation) ----------
def interpret_dow(dow: pd.DataFrame) -> str:
    hi, lo = dow.loc[dow["relative_demand"].idxmax()], dow.loc[dow["relative_demand"].idxmin()]
    return (f"Demand is highest on {hi['day']} ({hi['relative_demand']:.2f}x the weekly average) and lowest on {lo['day']} "
            f"({lo['relative_demand']:.2f}x). Weekday patterns like this are why the models use day-of-week and last-week lags.")


def interpret_discount(rel: pd.DataFrame) -> str:
    base = rel.loc[rel["discount_band"] == "0%", "avg_relative_demand"]
    top = rel.sort_values("avg_relative_demand", ascending=False).iloc[0]
    if base.empty:
        return "Not enough non-discounted days to compare."
    return (f"Days in the '{top['discount_band']}' band sell {top['avg_relative_demand'] / base.iloc[0]:.2f}x the non-discounted level. "
            "This is a CORRELATION: promotions are often run together with seasonal peaks or marketing, so it does not prove the discount alone caused the lift.")


def interpret_seasonality(s: pd.DataFrame) -> str:
    hi, lo = s.loc[s["seasonal_index"].idxmax()], s.loc[s["seasonal_index"].idxmin()]
    return f"Average demand peaks in month {int(hi['month'])} ({hi['seasonal_index']:.2f}x) and is weakest in month {int(lo['month'])} ({lo['seasonal_index']:.2f}x)."


def interpret_variability(v: pd.DataFrame) -> str:
    return (f"Median coefficient of variation is {v['cv'].median():.2f}. Products with a high CV (e.g. {v.iloc[0]['product_name']}, "
            f"{v.iloc[0]['cv']:.2f}) are harder to forecast and typically need more safety stock.")
