"""Data loading and the reproducible synthetic data generator.

The generator simulates DEMAND first (weekly cycle, seasonality, growth/decline, promotions,
price effects, occasional spikes/drops) and then simulates INVENTORY with a simple periodic-review
replenishment policy so that on-hand stock, on-order stock and lead times are internally
consistent (units_sold can never exceed the stock actually available).

Hidden generator parameters (base demand, elasticities, ...) are never returned, so they
cannot leak into model features. On-hand inventory is also NOT used as a model feature.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import config

CATALOG = {
    "Electronics": [("Wireless Earbuds", 2499), ("Bluetooth Speaker", 3299), ("Smart Watch", 5999), ("Power Bank", 1799),
                    ("USB-C Cable", 399), ("Webcam", 2999), ("Gaming Mouse", 1999), ("Mechanical Keyboard", 4499),
                    ("Phone Case", 499), ("Portable SSD", 6499)],
    "Home & Kitchen": [("Air Fryer", 5499), ("Coffee Maker", 3999), ("Blender", 2799), ("Non-stick Pan Set", 2199),
                       ("Electric Kettle", 1299), ("Vacuum Flask", 899), ("Knife Set", 1599), ("Storage Containers", 799),
                       ("Desk Lamp", 1099), ("Bedsheet Set", 1899)],
    "Fitness": [("Yoga Mat", 999), ("Resistance Bands", 699), ("Dumbbell Set", 3499), ("Protein Shaker", 399),
                ("Skipping Rope", 299), ("Fitness Tracker Band", 2299), ("Foam Roller", 899), ("Gym Bag", 1399)],
    "Fashion": [("Running Shoes", 3499), ("Denim Jacket", 2799), ("Backpack", 1799), ("Sunglasses", 1499),
                ("Cotton T-Shirt", 599), ("Leather Wallet", 999), ("Winter Hoodie", 1999), ("Rain Jacket", 2299)],
    "Beauty & Care": [("Face Serum", 899), ("Sunscreen SPF50", 499), ("Hair Dryer", 1999), ("Electric Trimmer", 1599),
                      ("Perfume Gift Set", 2499), ("Moisturizer", 599), ("Shampoo Pack", 449), ("Lip Balm Set", 299)],
}
# Annual peak day-of-year and amplitude by category (hidden generator parameter).
SEASON = {"Electronics": (330, 0.30), "Home & Kitchen": (300, 0.25), "Fitness": (15, 0.30),
          "Fashion": (340, 0.30), "Beauty & Care": (350, 0.18)}
WEEKLY = np.array([0.95, 0.93, 0.95, 0.98, 1.02, 1.12, 1.10])  # Mon..Sun
WEEKLY = WEEKLY / WEEKLY.mean()


def _product_list(n_products: int):
    items = []
    for cat, prods in CATALOG.items():
        for name, price in prods:
            items.append((cat, name, price))
    return items[: max(1, min(n_products, len(items)))]


def generate_synthetic_data(seed: int = config.RANDOM_SEED, n_products: int = config.SYNTH_N_PRODUCTS,
                            start: str = config.SYNTH_START, end: str = config.SYNTH_END):
    """Return (sales_df, inventory_df). Fully deterministic for a given seed."""
    rng = np.random.default_rng(seed)
    dates = pd.date_range(start, end, freq="D")
    T = len(dates)
    doy = dates.dayofyear.values
    dow = dates.dayofweek.values
    items = _product_list(n_products)
    P = len(items)

    # global sale events: late-Nov "Mega Sale" and late-Jun "Mid-year Sale"
    global_event = np.zeros(T, dtype=bool)
    for y in range(dates.year.min(), dates.year.max() + 1):
        for (m, d0, d1) in ((11, 22, 29), (6, 20, 27)):
            global_event |= np.asarray((dates >= pd.Timestamp(y, m, d0)) & (dates <= pd.Timestamp(y, m, d1)))

    sales_rows, inv_rows = [], []
    slow_idx = set(rng.choice(P, size=max(1, P // 7), replace=False).tolist())
    launch_late_idx = set(rng.choice(P, size=max(1, P // 5), replace=False).tolist())
    policy_choice = rng.choice(["under", "normal", "over"], size=P, p=[0.2, 0.55, 0.25])

    for i, (cat, name, list_price) in enumerate(items):
        pid = f"P{i + 1:03d}"
        if name == "Wireless Earbuds":
            base, policy_choice[i], lead = 30.0, "normal", 3
        else:
            base = float(np.clip(rng.lognormal(2.6, 0.8), 3, 90))
            lead = int(rng.choice([3, 5, 7, 7, 10, 14, 21]))
        if i in slow_idx and name != "Wireless Earbuds":
            base = float(rng.uniform(0.6, 2.2))
        growth = float(np.clip(rng.normal(0.05, 0.25), -0.5, 0.8))
        peak, amp = SEASON[cat]
        amp = amp * rng.uniform(0.5, 1.2)
        beta = rng.uniform(1.2, 3.0)             # promo/discount elasticity
        price_elast = rng.uniform(0.4, 1.0)
        wk = WEEKLY * rng.normal(1, 0.03, 7)

        # price path with occasional list-price revisions
        price = np.full(T, list_price * rng.uniform(0.9, 1.1), dtype=float)
        if T > 70:
            for cp in rng.choice(np.arange(60, T), size=min(3, T - 60), replace=False):
                price[cp:] *= rng.uniform(0.95, 1.06)
        price = np.round(price, 2)

        # launch
        if i in launch_late_idx and T > 400:
            launch_idx = int(rng.integers(120, T - 200))
        else:
            launch_idx = -int(rng.integers(30, 900))
        launch_date = dates[0] + pd.Timedelta(days=launch_idx)
        age = np.arange(T) - launch_idx
        ramp = np.where(age < 0, 0.0, np.minimum(1.0, 0.35 + 0.65 * age / 45.0))

        # promotions
        disc = np.zeros(T)
        promo = np.zeros(T, dtype=int)
        t = int(rng.integers(10, 40))
        while t < T:
            length = int(rng.integers(3, 10))
            d = float(rng.choice([10, 15, 20, 25, 30, 35]))
            disc[t:t + length] = d
            promo[t:t + length] = 1
            t += length + int(rng.integers(35, 90))
        ev_disc = float(rng.choice([15, 20, 25, 30]))
        if rng.random() < 0.75:
            disc[global_event & (disc == 0)] = ev_disc
            promo[global_event] = 1

        # demand
        season = 1 + amp * np.cos(2 * np.pi * (doy - peak) / 365.25)
        trend = np.maximum(0.2, 1 + growth * np.arange(T) / 365.25)
        promo_mult = np.exp(beta * disc / 100.0) * np.where(promo == 1, 1.08, 1.0)
        price_mult = (price / price.mean()) ** (-price_elast)
        mult = np.ones(T)
        for _ in range(int(rng.integers(2, 5)) if T > 60 else 0):      # demand spikes
            s = int(rng.integers(40, T - 5))
            mult[s:s + int(rng.integers(1, 4))] *= rng.uniform(1.8, 3.5)
        for _ in range(int(rng.integers(1, 4)) if T > 60 else 0):      # unexplained drops
            s = int(rng.integers(40, T - 5))
            mult[s:s + int(rng.integers(1, 4))] *= rng.uniform(0.05, 0.35)
        mu = base * wk[dow] * season * trend * promo_mult * price_mult * mult * ramp
        k = 25.0
        demand = rng.negative_binomial(k, k / (k + np.maximum(mu, 1e-6)))
        demand = np.where(ramp == 0, 0, demand)

        # inventory simulation (end-of-day stock; sales limited by stock actually available)
        lead_sd = max(0.5, 0.15 * lead)
        factor = {"under": 0.9, "normal": 1.35, "over": 2.8}[str(policy_choice[i])]
        stock = max(5.0, base * 20 * (factor if factor > 1 else 1.0))
        arrivals = np.zeros(T + 90)
        open_orders = []  # (arrival_idx, qty)
        on_hand = np.zeros(T)
        sold = np.zeros(T)
        review_offset = int(rng.integers(0, 7))
        for t in range(T):
            stock += arrivals[t]
            open_orders = [(a, q) for (a, q) in open_orders if a > t]
            s = min(float(demand[t]), stock)
            sold[t] = s
            stock -= s
            on_hand[t] = stock
            if t % 7 == review_offset and ramp[t] > 0:
                recent = sold[max(0, t - 27): t + 1]
                rate = max(float(recent.mean()), 0.3)
                position = stock + sum(q for _, q in open_orders)
                target = rate * (lead + 7) * factor + 1.0 * rate * np.sqrt(lead) + 2
                qty = int(np.ceil(max(0.0, target - position)))
                if qty > 0:
                    a = t + max(1, int(round(lead + rng.normal(0, lead_sd))))
                    arrivals[a] += qty
                    open_orders.append((a, qty))
        on_order_end = float(sum(q for _, q in open_orders))

        # engagement
        cart = sold + rng.poisson(np.maximum(sold, 0.2) * rng.uniform(0.6, 1.6))
        cart_rate = rng.uniform(0.07, 0.14)
        views = np.maximum(cart, np.round(cart / cart_rate * rng.normal(1, 0.08, T))).astype(int)

        rating = np.clip(rng.uniform(3.6, 4.7) + np.cumsum(rng.normal(0, 0.012, T)), 3.0, 5.0).round(1)
        cost = round(float(list_price * rng.uniform(0.45, 0.75)), 2)

        df = pd.DataFrame({
            "date": dates, "product_id": pid, "product_name": name, "category": cat,
            "unit_price": price, "units_sold": sold.astype(int), "discount_pct": disc,
            "promotion": promo, "rating": rating, "views": views, "add_to_cart": cart.astype(int),
            "on_hand": on_hand.round().astype(int), "lead_time_days": lead, "unit_cost": cost,
            "launch_date": launch_date.normalize(),
        })
        sales_rows.append(df[age >= 0])
        inv_rows.append({"product_id": pid, "on_hand": int(round(on_hand[-1])), "on_order": int(round(on_order_end)),
                         "backorders": 0, "lead_time_days": lead, "lead_time_std_days": round(lead_sd, 2),
                         "unit_cost": cost})
    sales = pd.concat(sales_rows, ignore_index=True)
    sales["date"] = pd.to_datetime(sales["date"])
    return sales, pd.DataFrame(inv_rows)


def ensure_sample_files(force: bool = False):
    """Generate the demo CSV files if they do not exist (or when force=True)."""
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    if force or not (config.SAMPLE_SALES_PATH.exists() and config.SAMPLE_INVENTORY_PATH.exists()):
        sales, inv = generate_synthetic_data()
        sales.to_csv(config.SAMPLE_SALES_PATH, index=False)
        inv.to_csv(config.SAMPLE_INVENTORY_PATH, index=False)
    return config.SAMPLE_SALES_PATH, config.SAMPLE_INVENTORY_PATH


def load_sample_data(force: bool = False):
    """Load (sales_raw, inventory_raw) for the synthetic demo dataset."""
    sp, ip = ensure_sample_files(force)
    return pd.read_csv(sp), pd.read_csv(ip)


def read_csv_flexible(file_or_path) -> pd.DataFrame:
    """Read a CSV from a path or file-like object, trying common encodings and delimiters."""
    last_err = None
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            if hasattr(file_or_path, "seek"):
                file_or_path.seek(0)
            return pd.read_csv(file_or_path, encoding=enc, sep=None, engine="python")
        except Exception as exc:  # noqa: BLE001
            last_err = exc
    raise ValueError(f"Could not read the file as CSV: {last_err}")
