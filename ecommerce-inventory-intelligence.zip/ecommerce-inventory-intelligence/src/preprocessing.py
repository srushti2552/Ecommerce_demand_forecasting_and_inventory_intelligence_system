"""Turn validated rows into a complete daily product panel and a current-inventory snapshot."""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import pandas as pd

import config

OPTIONAL_PANEL_COLS = ["product_name", "category", "unit_price", "discount_pct", "promotion", "rating", "views",
                       "add_to_cart", "on_hand", "lead_time_days", "unit_cost", "launch_date"]


def aggregate_daily(df: pd.DataFrame) -> pd.DataFrame:
    """One row per (date, product_id). Units are summed; views/add_to_cart use max (avoid double counting)."""
    rules = {"units_sold": "sum"}
    for c in ["unit_price", "discount_pct", "rating", "on_hand", "lead_time_days", "unit_cost"]:
        if c in df.columns:
            rules[c] = "mean"
    for c in ["views", "add_to_cart", "promotion"]:
        if c in df.columns:
            rules[c] = "max"
    for c in ["product_name", "category", "launch_date"]:
        if c in df.columns:
            rules[c] = "first"
    out = df.groupby(["date", "product_id"], as_index=False).agg(rules)
    return out.sort_values(["product_id", "date"]).reset_index(drop=True)


def build_panel(daily: pd.DataFrame, fill_missing_days: bool = True):
    """Create a complete daily panel (product x date from first observation to the global last date).

    Missing days between observations are treated as ZERO sales when fill_missing_days=True (the standard
    assumption for transaction exports where no row means no sale). The number of filled days is reported.
    Returns (panel, product_meta, notes).
    """
    notes = []
    d = daily.copy()
    for c in OPTIONAL_PANEL_COLS:
        if c not in d.columns:
            d[c] = np.nan
    global_max = d["date"].max()
    first = d.groupby("product_id")["date"].min().rename("first_date")
    last = d.groupby("product_id")["date"].max().rename("last_date")
    meta = pd.concat([first, last], axis=1).reset_index()
    meta["active"] = (global_max - meta["last_date"]).dt.days <= config.INACTIVE_AFTER_DAYS
    n_inactive = int((~meta["active"]).sum())
    if n_inactive:
        notes.append(f"{n_inactive} product(s) have no sales rows in the last {config.INACTIVE_AFTER_DAYS} days and are treated as inactive (not forecast).")

    # full grid
    pieces = []
    for pid, f, in zip(meta["product_id"], meta["first_date"]):
        pieces.append(pd.DataFrame({"product_id": pid, "date": pd.date_range(f, global_max, freq="D")}))
    grid = pd.concat(pieces, ignore_index=True)
    panel = grid.merge(d, on=["product_id", "date"], how="left")
    panel["observed"] = panel["units_sold"].notna()
    n_filled = int((~panel["observed"]).sum())
    if n_filled:
        if fill_missing_days:
            notes.append(f"{n_filled} product-days had no row and were filled with 0 units sold (assumption: no row = no sale).")
        else:
            panel = panel[panel["observed"]].copy()
    panel["units_sold"] = panel["units_sold"].fillna(0.0)
    panel = panel.sort_values(["product_id", "date"]).reset_index(drop=True)

    g = panel.groupby("product_id", sort=False)
    for c in ["product_name", "category", "unit_price", "rating", "on_hand", "lead_time_days", "unit_cost", "launch_date"]:
        panel[c] = g[c].ffill()
        panel[c] = panel.groupby("product_id", sort=False)[c].bfill()
    for c in ["discount_pct", "promotion"]:
        panel[c] = panel[c].fillna(0)
    for c in ["views", "add_to_cart"]:
        if panel[c].notna().any():
            panel[c] = panel[c].fillna(0)
    panel["category"] = panel["category"].astype("object").where(panel["category"].notna(), "Uncategorized").astype(str)
    panel["product_name"] = panel["product_name"].astype("object").where(panel["product_name"].notna(), panel["product_id"]).astype(str)

    info = panel.groupby("product_id").agg(product_name=("product_name", "last"), category=("category", "last"),
                                          launch_date=("launch_date", "first"), n_days=("date", "count"))
    meta = meta.merge(info.reset_index(), on="product_id", how="left")
    meta["history_ok"] = meta["n_days"] > config.MIN_HISTORY_DAYS + 7
    short = int((meta["active"] & ~meta["history_ok"]).sum())
    if short:
        notes.append(f"{short} active product(s) have under {config.MIN_HISTORY_DAYS + 7} days of history and cannot be forecast yet.")
    return panel, meta, notes


def inventory_from_panel(panel: pd.DataFrame, meta: pd.DataFrame) -> pd.DataFrame:
    """Latest on-hand / lead time / cost per product taken from the sales table (only where the columns exist)."""
    last = panel.sort_values("date").groupby("product_id").tail(1).set_index("product_id")
    inv = pd.DataFrame({"product_id": last.index})
    inv["on_hand"] = last["on_hand"].values
    inv["lead_time_days"] = last["lead_time_days"].values
    inv["unit_cost"] = last["unit_cost"].values
    return inv.reset_index(drop=True)


def merge_inventory(base: pd.DataFrame, uploaded: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Combine a sales-derived snapshot with an optional uploaded snapshot (uploaded values win where present)."""
    cols = ["on_hand", "on_order", "backorders", "lead_time_days", "lead_time_std_days", "unit_cost"]
    out = base.copy()
    for c in cols:
        if c not in out.columns:
            out[c] = np.nan
    if uploaded is not None and len(uploaded):
        up = uploaded.set_index("product_id")
        out = out.set_index("product_id")
        for c in cols:
            if c in up.columns:
                out[c] = up[c].combine_first(out[c]) if c in out.columns else up[c]
        extra = up.index.difference(out.index)
        if len(extra):
            out = pd.concat([out, up.loc[extra, [c for c in cols if c in up.columns]]])
        out = out.reset_index()
    return out[["product_id"] + cols]


def product_summary(panel: pd.DataFrame, window: int = 90) -> pd.DataFrame:
    """Product-level aggregation used by several modules."""
    last_date = panel["date"].max()
    recent = panel[panel["date"] > last_date - pd.Timedelta(days=window)]
    g = recent.groupby("product_id")
    out = pd.DataFrame({
        "avg_daily_units": g["units_sold"].mean(),
        "std_daily_units": g["units_sold"].std(ddof=0),
    })
    out["cv"] = out["std_daily_units"] / out["avg_daily_units"].replace(0, np.nan)
    rev = (recent["units_sold"] * recent["unit_price"] * (1 - recent["discount_pct"].fillna(0) / 100)) if recent["unit_price"].notna().any() else None
    if rev is not None:
        out["revenue"] = rev.groupby(recent["product_id"]).sum()
    return out.reset_index()


def revenue_series(panel: pd.DataFrame) -> Optional[pd.Series]:
    """Net revenue per row (price after discount) or None when no price data exists."""
    if not panel["unit_price"].notna().any():
        return None
    return panel["units_sold"] * panel["unit_price"] * (1 - panel["discount_pct"].fillna(0) / 100.0)


def prepare_from_validated(cleaned: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, list]:
    """Convenience: validated rows -> (panel, meta, notes)."""
    return build_panel(aggregate_daily(cleaned))
