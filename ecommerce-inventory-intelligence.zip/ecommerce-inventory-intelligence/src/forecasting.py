"""Models, recursive multi-step forecasting, empirical ranges and model persistence.

Forecasting strategy (recursive)
--------------------------------
Day t+1 is predicted from history; that prediction is then written back as if it were observed and used
to build the lag/rolling features for day t+2, and so on. Actual sales after the forecast origin are
physically removed from the data before forecasting (see ``WideData.truncated_with_future``), so future
sales can never be used as input.

Assumptions for future days (documented in the UI): price held at last value, no discount, no promotion
and engagement held at its last-7-day mean - unless the user supplies planned values.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import joblib
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

import config
from src.feature_engineering import CATEGORICAL_COLUMNS, FeatureSpec, WideData

NAIVE = "Seasonal Naive (same day last week)"
RIDGE = "Ridge Regression"
RF = "Random Forest"
HGB = "Gradient Boosting (HistGB)"
MODEL_NAMES = [NAIVE, RIDGE, RF, HGB]

ASSUMPTIONS = [
    "Future price is held at the last observed list price (unless a planned price is supplied).",
    "Future discount = 0% and promotion = off (unless a planned promotion is supplied in the simulator).",
    "Website views / add-to-cart for future days are held at their last 7-day average (they are unknown in advance).",
    "Forecasts are generated recursively: each predicted day feeds the lag/rolling features of the next day.",
    "Missing days in the history were treated as zero sales (see data-quality report).",
    "Forecast errors grow with the horizon; the 30-day forecast is less reliable than the 7-day forecast.",
]


class SeasonalNaive(BaseEstimator, RegressorMixin):
    """Baseline: predict demand = demand on the same weekday last week (lag_7)."""

    def fit(self, X, y=None):
        return self

    def predict(self, X):
        return np.asarray(X["lag_7"], dtype=float)


def build_models(spec: FeatureSpec, random_state: int = config.RANDOM_SEED) -> Dict[str, object]:
    cat, num = CATEGORICAL_COLUMNS, spec.numeric_columns()

    def pre(scale: bool):
        return ColumnTransformer([
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat),
            ("num", StandardScaler() if scale else "passthrough", num),
        ])

    return {
        NAIVE: SeasonalNaive(),
        RIDGE: Pipeline([("pre", pre(True)), ("model", Ridge(alpha=10.0))]),
        RF: Pipeline([("pre", pre(False)), ("model", RandomForestRegressor(
            n_estimators=80, max_depth=14, min_samples_leaf=10, max_features=0.5, max_samples=0.5,
            n_jobs=-1, random_state=random_state))]),
        HGB: Pipeline([("pre", pre(False)), ("model", HistGradientBoostingRegressor(
            max_iter=250, learning_rate=0.06, max_leaf_nodes=31, min_samples_leaf=40,
            l2_regularization=1.0, random_state=random_state))]),
    }


def fit_models(models: Dict[str, object], train_df: pd.DataFrame, spec: FeatureSpec) -> Dict[str, object]:
    """Fit every model on the supplied TRAIN rows only and return the fitted copies."""
    from sklearn.base import clone
    X = train_df[spec.all_columns()]
    y = train_df["units_sold"].to_numpy(dtype=float)
    fitted = {}
    for name, m in models.items():
        m = clone(m)
        m.fit(X, y)
        last = m.steps[-1][1] if isinstance(m, Pipeline) else None
        if last is not None and hasattr(last, "n_jobs"):
            last.set_params(n_jobs=1)  # tiny prediction batches: avoid thread start-up overhead
        fitted[name] = m
    return fitted


def recursive_forecast(model, wide: WideData, spec: FeatureSpec, origin: int, horizon: int,
                       future_known: Optional[pd.DataFrame] = None):
    """Forecast ``horizon`` days starting at day index ``origin`` using only data before ``origin``.

    Returns (preds[P, horizon] with NaN for products lacking history, DatetimeIndex of forecast dates).
    """
    w = wide.truncated_with_future(origin, horizon, future_known)
    P = w.n_products
    preds = np.full((P, horizon), np.nan)
    check_cols = spec.numeric_columns() + ["dow", "month"]
    for h in range(horizon):
        t = origin + h
        X = w.feature_frame_at(t, spec)
        feats = X.drop(columns="product_id")
        valid = np.isfinite(feats[check_cols].to_numpy(dtype=float)).all(axis=1)
        col = np.full(P, np.nan)
        if valid.any():
            yhat = np.asarray(model.predict(feats.loc[valid]), dtype=float)
            col[valid] = np.clip(np.nan_to_num(yhat, nan=0.0, posinf=0.0, neginf=0.0), 0.0, None)
        w.U[:, t] = col
        preds[:, h] = col
        if spec.use_engagement:
            w.V[:, t] = w.V[:, t - 7:t].mean(axis=1)
            w.C[:, t] = w.C[:, t - 7:t].mean(axis=1)
    return preds, w.dates[origin:origin + horizon]


def forecast_future(bundle: dict, wide: WideData, model_name: Optional[str] = None, horizon: int = 30,
                    products=None, future_known: Optional[pd.DataFrame] = None,
                    inactive_products=()) -> pd.DataFrame:
    """Forecast beyond the last observed day. Returns a long table with an empirical *estimated* range."""
    model_name = model_name or bundle["selected"]
    spec = FeatureSpec.from_dict(bundle["feature_spec"])
    horizon = int(min(max(1, horizon), config.MAX_FORECAST_HORIZON))
    preds, dates = recursive_forecast(bundle["models"][model_name], wide, spec, wide.n_days, horizon, future_known)
    res = bundle.get("residuals")
    rows = []
    res_m = None
    if res is not None and len(res):
        res_m = res[res["model"] == model_name].set_index("product_id")
    for i, pid in enumerate(wide.product_ids):
        if products is not None and pid not in products:
            continue
        if pid in inactive_products or np.isnan(preds[i]).all():
            continue
        lo = hi = None
        if res_m is not None and pid in res_m.index:
            lo, hi = float(res_m.loc[pid, "resid_q10"]), float(res_m.loc[pid, "resid_q90"])
        df = pd.DataFrame({"product_id": pid, "date": dates, "forecast": preds[i], "model": model_name})
        df["lower_est"] = np.clip(df["forecast"] + lo, 0, None) if lo is not None else np.nan
        df["upper_est"] = np.clip(df["forecast"] + hi, 0, None) if hi is not None else np.nan
        rows.append(df)
    if not rows:
        return pd.DataFrame(columns=["product_id", "date", "forecast", "model", "lower_est", "upper_est"])
    out = pd.concat(rows, ignore_index=True)
    assert np.isfinite(out["forecast"]).all() and (out["forecast"] >= 0).all()
    return out


# ---- persistence ---------------------------------------------------------------------
def bundle_path(key: str) -> Path:
    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    return config.MODELS_DIR / f"{key}.joblib"


def save_bundle(bundle: dict, key: str) -> Path:
    p = bundle_path(key)
    joblib.dump(bundle, p)
    meta = {k: bundle[k] for k in ("version", "trained_at", "dataset_key", "selected", "feature_spec", "split", "notes") if k in bundle}
    meta["comparison"] = bundle["comparison"].to_dict(orient="records")
    with open(p.with_suffix(".json"), "w") as fh:
        json.dump(meta, fh, indent=2, default=str)
    return p


def load_bundle(key: str) -> Optional[dict]:
    p = bundle_path(key)
    if not p.exists():
        return None
    try:
        return joblib.load(p)
    except Exception:  # noqa: BLE001 - stale/incompatible file: caller retrains
        return None


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")
