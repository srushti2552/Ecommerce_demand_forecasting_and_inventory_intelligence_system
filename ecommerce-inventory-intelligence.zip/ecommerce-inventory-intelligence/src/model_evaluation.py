"""Metrics, chronological splitting, rolling-origin backtests and the full train/select/test workflow.

Protocol
--------
1. TRAIN  : all rows with target date  <  validation start
2. VALIDATE: models fitted on TRAIN are scored with rolling-origin recursive forecasts inside the validation window
             -> the winner is chosen ONLY from these validation scores
3. TEST   : models are re-fitted on TRAIN+VALIDATION and scored on the final hold-out window that was never used
             for fitting (earlier stages) or selection. Test numbers are reported but never used to pick a model.
4. DEPLOY : models are re-fitted on ALL data for real future forecasts.
No random shuffling is used anywhere.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

import config
from src import forecasting as fc
from src.feature_engineering import FeatureSpec, WideData, make_wide

METRIC_HELP = {
    "MAE": "Mean Absolute Error: on average, how many units per product-day the forecast is off by. Lower is better.",
    "RMSE": "Root Mean Squared Error: like MAE but punishes big misses more. Lower is better.",
    "WAPE": "Weighted Absolute Percentage Error = total absolute error / total actual sales. 0.20 means the forecast "
            "is off by about 20% of sales volume. Safe when some days have zero sales.",
    "MAPE": "Mean Absolute Percentage Error, computed only on days with at least 1 unit sold (otherwise it divides "
            "by zero). Can overstate error for low-volume items.",
}


# ---- metrics -------------------------------------------------------------------------
def mae(a, p) -> float:
    a, p = np.asarray(a, float), np.asarray(p, float)
    return float(np.mean(np.abs(a - p))) if len(a) else float("nan")


def rmse(a, p) -> float:
    a, p = np.asarray(a, float), np.asarray(p, float)
    return float(np.sqrt(np.mean((a - p) ** 2))) if len(a) else float("nan")


def wape(a, p) -> float:
    a, p = np.asarray(a, float), np.asarray(p, float)
    den = np.abs(a).sum()
    return float(np.abs(a - p).sum() / den) if den > 0 else float("nan")


def mape_safe(a, p, min_actual: float = 1.0) -> float:
    a, p = np.asarray(a, float), np.asarray(p, float)
    m = a >= min_actual
    return float(np.mean(np.abs(a[m] - p[m]) / a[m])) if m.any() else float("nan")


def metrics_table(df: pd.DataFrame, by: str = "model") -> pd.DataFrame:
    rows = []
    for key, g in df.groupby(by):
        rows.append({by: key, "MAE": mae(g["actual"], g["pred"]), "RMSE": rmse(g["actual"], g["pred"]),
                     "WAPE": wape(g["actual"], g["pred"]), "MAPE": mape_safe(g["actual"], g["pred"]), "n": len(g)})
    return pd.DataFrame(rows)


# ---- splitting -----------------------------------------------------------------------
def choose_split(n_days: int, test_days: int = config.TEST_DAYS, val_days: int = config.VAL_DAYS) -> Dict[str, int]:
    """Chronological split indices (day indices into the calendar). Raises ValueError when data is too short."""
    if n_days < config.MIN_TOTAL_DAYS_TO_TRAIN:
        raise ValueError(f"Only {n_days} days of history; at least {config.MIN_TOTAL_DAYS_TO_TRAIN} days are needed to "
                         "train and honestly evaluate forecasting models (train + validation + test windows).")
    if n_days < 300:  # shrink windows for short histories
        test_days = max(14, (n_days // 10) // 7 * 7)
        val_days = max(28, (n_days // 6) // 7 * 7)
    val_days = max(7, val_days // 7 * 7)
    test_start = n_days - test_days
    val_start = test_start - val_days
    if val_start < 28 + 30:
        raise ValueError("Not enough history left for training after reserving validation and test windows.")
    return {"val_start": val_start, "test_start": test_start, "n_days": n_days, "val_days": val_days, "test_days": test_days}


def chronological_split(df: pd.DataFrame, val_start_date, test_start_date):
    """Split a feature table (with a 'date' column) into train / validation / test by date - no shuffling."""
    train = df[df["date"] < val_start_date]
    val = df[(df["date"] >= val_start_date) & (df["date"] < test_start_date)]
    test = df[df["date"] >= test_start_date]
    return train, val, test


# ---- backtests -----------------------------------------------------------------------
def rolling_origin_backtest(models: Dict[str, object], wide: WideData, spec: FeatureSpec,
                            origins: List[int], horizon: int) -> pd.DataFrame:
    """Forecast ``horizon`` days from each origin using only earlier data; compare with what really happened."""
    rows = []
    for o in origins:
        h = min(horizon, wide.n_days - o)
        if h <= 0:
            continue
        actual = wide.U[:, o:o + h]
        dates = wide.dates[o:o + h]
        for name, model in models.items():
            preds, _ = fc.recursive_forecast(model, wide, spec, o, h)
            ok = np.isfinite(preds) & np.isfinite(actual)
            pi, ti = np.where(ok)
            rows.append(pd.DataFrame({
                "model": name, "origin_date": wide.dates[o], "step": ti + 1, "date": dates[ti],
                "product_id": wide.product_ids[pi], "actual": actual[pi, ti], "pred": preds[pi, ti],
            }))
    if not rows:
        return pd.DataFrame(columns=["model", "origin_date", "step", "date", "product_id", "actual", "pred"])
    return pd.concat(rows, ignore_index=True)


def _origins(start: int, days: int, step: int, horizon: int) -> List[int]:
    return [start + k * step for k in range(days // step) if start + k * step + horizon <= start + days]


def residual_summary(pred_df: pd.DataFrame) -> pd.DataFrame:
    """Per model and product: std and 10th/90th percentile of (actual - pred). Used for ESTIMATED ranges and safety stock."""
    d = pred_df.assign(resid=pred_df["actual"] - pred_df["pred"])
    g = d.groupby(["model", "product_id"])["resid"]
    out = pd.DataFrame({"resid_std": g.std(ddof=0), "resid_q10": g.quantile(0.10), "resid_q90": g.quantile(0.90),
                        "n": g.size()}).reset_index()
    return out


# ---- full workflow ---------------------------------------------------------------------
def train_and_evaluate(panel: pd.DataFrame, meta: Optional[pd.DataFrame] = None, dataset_key: str = "dataset",
                       progress: Optional[Callable[[float, str], None]] = None,
                       seed: int = config.RANDOM_SEED) -> dict:
    """Run the complete protocol and return a model bundle (see module docstring)."""
    say = progress or (lambda frac, msg: None)
    wide, spec = make_wide(panel, meta)
    split = choose_split(wide.n_days)
    vs, ts, T = split["val_start"], split["test_start"], wide.n_days
    notes = []
    if T < 365:
        notes.append("Less than one year of history: yearly seasonality cannot be learned reliably.")

    say(0.05, "Building training features")
    train_df = wide.training_frame(spec, t_end=vs)
    if len(train_df) < 500:
        raise ValueError(f"Only {len(train_df)} usable training rows - too little data to train reliably.")
    base_models = fc.build_models(spec, seed)

    say(0.15, "Fitting models on the training window")
    models_tr = fc.fit_models(base_models, train_df, spec)

    say(0.35, "Validating (rolling-origin, recursive forecasts)")
    val_origins = _origins(vs, split["val_days"], config.BACKTEST_STEP, config.BACKTEST_HORIZON)
    val_preds = rolling_origin_backtest(models_tr, wide, spec, val_origins, config.BACKTEST_HORIZON)
    val_m = metrics_table(val_preds)
    if val_m.empty:
        raise ValueError("Validation window produced no comparable predictions.")
    best = val_m.sort_values(["WAPE", "RMSE"]).iloc[0]["model"]

    say(0.55, "Re-fitting on train + validation and scoring the untouched test window")
    train_val_df = wide.training_frame(spec, t_end=ts)
    models_tv = fc.fit_models(base_models, train_val_df, spec)
    test_origins = _origins(ts, split["test_days"], config.BACKTEST_STEP, config.BACKTEST_HORIZON)
    test_preds = rolling_origin_backtest(models_tv, wide, spec, test_origins, config.BACKTEST_HORIZON)
    test_m = metrics_table(test_preds)
    long_h = split["test_days"]
    test_long = rolling_origin_backtest(models_tv, wide, spec, [ts], long_h)
    test_long_m = metrics_table(test_long)

    say(0.8, "Fitting deployment models on all data")
    all_df = wide.training_frame(spec)
    models_all = fc.fit_models(base_models, all_df, spec)

    comp = val_m.rename(columns={c: f"{c}_val" for c in ["MAE", "RMSE", "WAPE", "MAPE", "n"]})
    comp = comp.merge(test_m.rename(columns={c: f"{c}_test" for c in ["MAE", "RMSE", "WAPE", "MAPE", "n"]}), on="model", how="left")
    comp = comp.merge(test_long_m[["model", "WAPE"]].rename(columns={"WAPE": f"WAPE_test_{long_h}d"}), on="model", how="left")
    comp["selected"] = comp["model"] == best
    comp = comp.set_index("model").loc[[m for m in fc.MODEL_NAMES if m in set(comp["model"])]].reset_index()
    naive_w = float(comp.loc[comp["model"] == fc.NAIVE, "WAPE_val"].iloc[0])
    comp["val_WAPE_vs_naive"] = (comp["WAPE_val"] - naive_w) / naive_w if naive_w else np.nan

    resid = residual_summary(pd.concat([val_preds, test_preds], ignore_index=True))
    selected_test = test_preds[test_preds["model"] == best]
    product_metrics = metrics_table(selected_test, by="product_id") if len(selected_test) else pd.DataFrame()
    names = panel.groupby("product_id")["product_name"].last()
    if len(product_metrics):
        product_metrics["product_name"] = product_metrics["product_id"].map(names)

    say(1.0, "Done")
    return {
        "version": 1, "trained_at": fc.now_iso(), "dataset_key": dataset_key,
        "feature_spec": spec.to_dict(), "models": models_all, "selected": best, "comparison": comp,
        "split": {"val_start": str(wide.dates[vs].date()), "test_start": str(wide.dates[ts].date()),
                  "last_date": str(wide.dates[-1].date()), "val_days": split["val_days"], "test_days": split["test_days"],
                  "n_days": T, "backtest_horizon": config.BACKTEST_HORIZON, "n_train_rows": int(len(train_df))},
        "val_predictions": val_preds, "test_predictions": test_preds, "test_long_predictions": test_long,
        "residuals": resid, "product_metrics": product_metrics, "notes": notes,
    }
