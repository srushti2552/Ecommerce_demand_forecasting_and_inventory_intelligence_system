"""Leakage-safe feature engineering.

Design
------
Data is held as "wide" matrices (products x days). For a prediction day ``t`` the feature builder reads:

* HISTORY columns  ``< t``  : units sold, views, add-to-cart  (lags, rolling stats, engagement)
* KNOWN-AT-PREDICTION-TIME covariates for day ``t`` itself: calendar, list price, discount, promotion flag.
  For future days these are *assumptions* (default: no promotion, price held at last value) unless the user
  supplies planned values.

The SAME function (``WideData.features_at``) is used for model training and for step-by-step (recursive)
forecasting, so training/serving features cannot drift apart. Same-day views / add-to-cart are never used
because they are consequences of the day's demand and would not be known in advance.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

import config

CATEGORICAL_COLUMNS = ["category", "dow", "month"]


@dataclass
class FeatureSpec:
    use_price: bool = True
    use_discount: bool = True
    use_promo: bool = True
    use_engagement: bool = True

    @classmethod
    def from_panel(cls, panel: pd.DataFrame) -> "FeatureSpec":
        has = lambda c: c in panel.columns and panel[c].notna().any()  # noqa: E731
        return cls(
            use_price=bool(has("unit_price")),
            use_discount=bool(has("discount_pct") and panel["discount_pct"].nunique() > 1),
            use_promo=bool(has("promotion") and panel["promotion"].nunique() > 1),
            use_engagement=bool(has("views") and has("add_to_cart")),
        )

    def to_dict(self) -> Dict[str, bool]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, bool]) -> "FeatureSpec":
        return cls(**d)

    def numeric_columns(self) -> List[str]:
        cols = ["weekofyear", "is_weekend", "age_days"]
        cols += [f"lag_{k}" for k in config.LAGS]
        for w in config.ROLLING_WINDOWS:
            cols += [f"roll_mean_{w}", f"roll_std_{w}"]
        cols += ["growth_7_28"]
        if self.use_price:
            cols += ["unit_price", "price_ratio_28"]
        if self.use_discount:
            cols += ["discount_pct"]
        if self.use_promo:
            cols += ["promotion"]
        if self.use_engagement:
            cols += ["views_mean_7", "cart_rate_7", "conv_rate_7"]
        return cols

    def all_columns(self) -> List[str]:
        return self.numeric_columns() + CATEGORICAL_COLUMNS


def _empty(P):
    return np.full(P, np.nan)


class WideData:
    """Products x days matrices plus helpers to build features for any day index."""

    def __init__(self, dates, product_ids, categories, U, V, C, price, disc, promo, launch_idx):
        self.dates = pd.DatetimeIndex(dates)
        self.product_ids = np.asarray(product_ids, dtype=object)
        self.categories = np.asarray(categories, dtype=object)
        self.U, self.V, self.C = U, V, C
        self.price, self.disc, self.promo = price, disc, promo
        self.launch_idx = np.asarray(launch_idx, dtype=float)

    # ---- construction ---------------------------------------------------------------
    @classmethod
    def from_panel(cls, panel: pd.DataFrame, meta: Optional[pd.DataFrame] = None) -> "WideData":
        dates = pd.date_range(panel["date"].min(), panel["date"].max(), freq="D")
        pids = sorted(panel["product_id"].unique())

        def pivot(col, fill=None):
            w = panel.pivot(index="product_id", columns="date", values=col).reindex(index=pids, columns=dates)
            return w.to_numpy(dtype=float, copy=True)

        U = pivot("units_sold")
        if meta is not None:  # tail after a product's last observed row is a fill artefact, not data
            last = meta.set_index("product_id")["last_date"].reindex(pids)
            for i, ld in enumerate(last.values):
                if pd.notna(ld):
                    U[i, dates > ld] = np.nan
        V = pivot("views") if panel["views"].notna().any() else np.full_like(U, np.nan)
        C = pivot("add_to_cart") if panel["add_to_cart"].notna().any() else np.full_like(U, np.nan)
        price = pivot("unit_price")
        disc = np.nan_to_num(pivot("discount_pct"), nan=0.0)
        promo = np.nan_to_num(pivot("promotion"), nan=0.0)
        cat = panel.groupby("product_id")["category"].last().reindex(pids).values
        first_idx = np.array([np.argmax(np.isfinite(U[i])) if np.isfinite(U[i]).any() else 0 for i in range(len(pids))], dtype=float)
        launch_idx = first_idx.copy()
        if "launch_date" in panel.columns and panel["launch_date"].notna().any():
            ld = panel.groupby("product_id")["launch_date"].first().reindex(pids)
            off = (pd.to_datetime(ld) - dates[0]).dt.days.to_numpy(dtype=float)
            launch_idx = np.where(np.isfinite(off), off, first_idx)
        return cls(dates, pids, cat, U, V, C, price, disc, promo, launch_idx)

    @property
    def n_products(self) -> int:
        return len(self.product_ids)

    @property
    def n_days(self) -> int:
        return len(self.dates)

    def subset(self, product_ids) -> "WideData":
        """Copy restricted to the given products (keeps their order in the original matrix)."""
        keep = np.isin(self.product_ids, list(product_ids))
        return WideData(self.dates, self.product_ids[keep], self.categories[keep], self.U[keep].copy(), self.V[keep].copy(),
                        self.C[keep].copy(), self.price[keep].copy(), self.disc[keep].copy(), self.promo[keep].copy(),
                        self.launch_idx[keep].copy())

    def copy(self) -> "WideData":
        return WideData(self.dates, self.product_ids, self.categories, self.U.copy(), self.V.copy(), self.C.copy(),
                        self.price.copy(), self.disc.copy(), self.promo.copy(), self.launch_idx.copy())

    def truncated_with_future(self, origin: int, horizon: int, future_known: Optional[pd.DataFrame] = None) -> "WideData":
        """Copy of the data where everything from ``origin`` onwards is replaced by *assumptions*.

        Actual units/views/cart at or after ``origin`` are discarded (set to NaN), so a forecast made from
        this object physically cannot see them. Covariates for the horizon default to: price held at its last
        value, discount 0, promotion 0 - unless ``future_known`` supplies planned values.
        """
        P = self.n_products
        end = origin + horizon
        dates = pd.date_range(self.dates[0], periods=end, freq="D")
        U = np.full((P, end), np.nan)
        V = np.full((P, end), np.nan)
        C = np.full((P, end), np.nan)
        price = np.full((P, end), np.nan)
        disc = np.zeros((P, end))
        promo = np.zeros((P, end))
        m = min(origin, self.n_days)
        U[:, :m], V[:, :m], C[:, :m] = self.U[:, :m], self.V[:, :m], self.C[:, :m]
        price[:, :m], disc[:, :m], promo[:, :m] = self.price[:, :m], self.disc[:, :m], self.promo[:, :m]
        last_price = pd.DataFrame(price[:, :m]).ffill(axis=1).to_numpy(copy=True)[:, -1] if m > 0 else np.full(P, np.nan)
        price[:, m:] = last_price[:, None]
        w = WideData(dates, self.product_ids, self.categories, U, V, C, price, disc, promo, self.launch_idx)
        if future_known is not None and len(future_known):
            fk = future_known.copy()
            fk["date"] = pd.to_datetime(fk["date"])
            pidx = {p: i for i, p in enumerate(self.product_ids)}
            for _, r in fk.iterrows():
                if r["product_id"] not in pidx:
                    continue
                t = int((r["date"] - dates[0]).days)
                if origin <= t < end:
                    i = pidx[r["product_id"]]
                    if "discount_pct" in fk.columns and pd.notna(r.get("discount_pct")):
                        w.disc[i, t] = float(r["discount_pct"])
                    if "promotion" in fk.columns and pd.notna(r.get("promotion")):
                        w.promo[i, t] = float(r["promotion"])
                    if "unit_price" in fk.columns and pd.notna(r.get("unit_price")):
                        w.price[i, t:] = float(r["unit_price"])
        return w

    # ---- features -------------------------------------------------------------------
    def features_at(self, t: int, spec: FeatureSpec) -> Dict[str, np.ndarray]:
        """Feature vectors (one entry per product) for day index ``t``. Reads history columns < t only."""
        P = self.n_products
        d = self.dates[t] if t < self.n_days else self.dates[-1] + pd.Timedelta(days=t - self.n_days + 1)
        f: Dict[str, np.ndarray] = {
            "weekofyear": np.full(P, float(d.isocalendar()[1])),
            "is_weekend": np.full(P, float(d.dayofweek >= 5)),
            "dow": np.full(P, d.dayofweek),
            "month": np.full(P, d.month),
            "category": self.categories,
            "age_days": np.clip(t - self.launch_idx, 0, 1500),
        }
        enough = t >= max(config.LAGS + config.ROLLING_WINDOWS)
        for k in config.LAGS:
            f[f"lag_{k}"] = self.U[:, t - k] if t - k >= 0 else _empty(P)
        for w in config.ROLLING_WINDOWS:
            if t >= w:
                win = self.U[:, t - w:t]
                f[f"roll_mean_{w}"] = win.mean(axis=1)
                f[f"roll_std_{w}"] = win.std(axis=1)
            else:
                f[f"roll_mean_{w}"] = _empty(P)
                f[f"roll_std_{w}"] = _empty(P)
        f["growth_7_28"] = (f["roll_mean_7"] - f["roll_mean_28"]) / (f["roll_mean_28"] + 1.0)
        if spec.use_price:
            f["unit_price"] = self.price[:, t]
            f["price_ratio_28"] = self.price[:, t] / self.price[:, t - 28:t].mean(axis=1) - 1.0 if enough else _empty(P)
        if spec.use_discount:
            f["discount_pct"] = self.disc[:, t]
        if spec.use_promo:
            f["promotion"] = self.promo[:, t]
        if spec.use_engagement:
            if t >= 7:
                vw, cw, uw = self.V[:, t - 7:t], self.C[:, t - 7:t], self.U[:, t - 7:t]
                vs = vw.sum(axis=1)
                f["views_mean_7"] = vw.mean(axis=1)
                f["cart_rate_7"] = cw.sum(axis=1) / (vs + 1.0)
                f["conv_rate_7"] = uw.sum(axis=1) / (vs + 1.0)
            else:
                for c in ("views_mean_7", "cart_rate_7", "conv_rate_7"):
                    f[c] = _empty(P)
        return f

    def feature_frame_at(self, t: int, spec: FeatureSpec) -> pd.DataFrame:
        f = self.features_at(t, spec)
        df = pd.DataFrame({c: f[c] for c in spec.all_columns()})
        df.insert(0, "product_id", self.product_ids)
        return df

    def training_frame(self, spec: FeatureSpec, t_start: Optional[int] = None, t_end: Optional[int] = None) -> pd.DataFrame:
        """Long table of (product, date) rows with features and target ``units_sold`` for t in [t_start, t_end)."""
        t_start = max(config.LAGS + config.ROLLING_WINDOWS) if t_start is None else max(t_start, max(config.LAGS))
        t_end = self.n_days if t_end is None else min(t_end, self.n_days)
        cols = spec.all_columns()
        num_cols = spec.numeric_columns() + ["dow", "month"]
        chunks = {c: [] for c in cols}
        tgt, dts, pids = [], [], []
        for t in range(t_start, t_end):
            f = self.features_at(t, spec)
            y = self.U[:, t]
            ok = np.isfinite(y)
            for c in num_cols:
                ok &= np.isfinite(f[c].astype(float))
            if not ok.any():
                continue
            for c in cols:
                chunks[c].append(np.asarray(f[c])[ok])
            tgt.append(y[ok])
            dts.append(np.full(ok.sum(), t))
            pids.append(self.product_ids[ok])
        if not tgt:
            return pd.DataFrame(columns=["product_id", "date", "t_index", "units_sold"] + cols)
        df = pd.DataFrame({c: np.concatenate(chunks[c]) for c in cols})
        df.insert(0, "units_sold", np.concatenate(tgt))
        t_idx = np.concatenate(dts)
        df.insert(0, "t_index", t_idx)
        df.insert(0, "date", self.dates[t_idx])
        df.insert(0, "product_id", np.concatenate(pids))
        return df


def make_wide(panel: pd.DataFrame, meta: Optional[pd.DataFrame] = None):
    """Build (WideData, FeatureSpec) from a panel."""
    return WideData.from_panel(panel, meta), FeatureSpec.from_panel(panel)
