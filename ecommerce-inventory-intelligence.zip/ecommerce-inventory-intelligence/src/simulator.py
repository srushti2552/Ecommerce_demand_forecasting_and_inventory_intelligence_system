"""Forecast & inventory what-if simulator.

Every number comes from the real project functions:
* the BASELINE forecast is the trained model's recursive forecast with the standard assumptions (no promotion);
* a SCENARIO forecast re-runs the SAME model with the user's planned discount/promotion supplied as known future
  covariates (only when the model and data can support it);
* a MANUAL demand adjustment (%) is applied on top and always labelled as a user assumption, never as ML output;
* inventory figures come from ``inventory_engine``.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from src import forecasting as fc
from src.inventory_engine import InventoryPolicy, compute_product_inventory
from src.pipeline import DatasetContext, hist_std_map, resid_std_map

SIM_HORIZON = 60
MIN_PROMO_DAYS = 10


@dataclass
class Scenario:
    product_id: str
    on_hand: float
    lead_time_days: float
    lead_time_std_days: float = 0.0
    on_order: float = 0.0
    backorders: float = 0.0
    review_period_days: float = 7.0
    safety_method: Optional[str] = None      # None -> use policy's method; else 'units' | 'days' | 'statistical'
    safety_units: float = 0.0
    safety_days: float = 3.0
    service_level: Optional[float] = None
    discount_pct: float = 0.0
    promotion: bool = False
    promo_days: int = 7
    demand_adjust_pct: float = 0.0


@dataclass
class ScenarioResult:
    dates: pd.DatetimeIndex
    baseline_daily: np.ndarray
    scenario_daily: np.ndarray
    original: Dict[str, object]
    revised: Dict[str, object]
    diff: pd.DataFrame
    forecast_source: str
    promo_support: Dict[str, object]
    narrative: List[str] = field(default_factory=list)
    baseline_range: Optional[pd.DataFrame] = None


def promo_support(ctx: DatasetContext, bundle: dict, model_name: str, product_id: str) -> Dict[str, object]:
    """Can this model/data produce a promotion-based scenario forecast for the product?"""
    spec = bundle["feature_spec"]
    p = ctx.panel[ctx.panel["product_id"] == product_id]
    n_promo = int((p["promotion"].fillna(0) > 0).sum() | 0) if "promotion" in p else 0
    n_disc = int((p["discount_pct"].fillna(0) > 0).sum())
    n = max(n_promo, n_disc)
    on = p[(p["promotion"].fillna(0) > 0) | (p["discount_pct"].fillna(0) > 0)]["units_sold"]
    off = p[~((p["promotion"].fillna(0) > 0) | (p["discount_pct"].fillna(0) > 0))]["units_sold"]
    hist_ratio = float(on.mean() / off.mean()) if len(on) and len(off) and off.mean() > 0 else None
    reasons = []
    if not (spec["use_discount"] or spec["use_promo"]):
        reasons.append("the dataset has no usable price/promotion variation, so models were trained without these features")
    if model_name == fc.NAIVE:
        reasons.append("the Seasonal Naive baseline cannot use discount or promotion inputs")
    if n < MIN_PROMO_DAYS:
        reasons.append(f"this product has only {n} historical promotion/discount days (need {MIN_PROMO_DAYS}+)")
    return {"supported": not reasons, "reasons": reasons, "n_promo_days": n, "historical_promo_ratio": hist_ratio}


def _product_forecast(ctx, bundle, model_name, product_id, horizon, future_known=None) -> pd.DataFrame:
    wide = ctx.wide.subset([product_id])
    return fc.forecast_future(bundle, wide, model_name, horizon, None, future_known)


def baseline_forecast(ctx: DatasetContext, bundle: dict, model_name: str, product_id: str, horizon: int = SIM_HORIZON) -> pd.DataFrame:
    return _product_forecast(ctx, bundle, model_name, product_id, horizon)


def _policy_for(base: InventoryPolicy, sc: Scenario, use_scenario_safety: bool) -> InventoryPolicy:
    p = replace(base, review_period_days=sc.review_period_days)
    if use_scenario_safety:
        if sc.service_level is not None:
            p = replace(p, service_level=sc.service_level)
        if sc.safety_method:
            p = replace(p, safety_method=sc.safety_method, safety_units=sc.safety_units, safety_days=sc.safety_days)
    return p


def run_scenario(ctx: DatasetContext, bundle: dict, model_name: str, base_policy: InventoryPolicy, original: Scenario,
                 scenario: Scenario, baseline: Optional[pd.DataFrame] = None) -> ScenarioResult:
    """Compute original vs simulated forecast and inventory decision for one product."""
    pid = scenario.product_id
    if baseline is None:
        baseline = baseline_forecast(ctx, bundle, model_name, pid)
    if baseline.empty:
        raise ValueError("This product has no forecast (inactive or too little history).")
    baseline = baseline.sort_values("date")
    base_daily = baseline["forecast"].to_numpy(dtype=float)
    dates = pd.DatetimeIndex(baseline["date"])

    support = promo_support(ctx, bundle, model_name, pid)
    wants_promo = scenario.discount_pct > 0 or scenario.promotion
    scen_daily = base_daily.copy()
    sources = ["Model baseline (no planned promotion)"]
    narrative: List[str] = []
    if wants_promo:
        if support["supported"]:
            n = int(min(max(1, scenario.promo_days), len(dates)))
            fk = pd.DataFrame({"product_id": pid, "date": dates[:n], "discount_pct": float(scenario.discount_pct),
                               "promotion": 1.0 if (scenario.promotion or scenario.discount_pct > 0) else 0.0})
            scen_daily = _product_forecast(ctx, bundle, model_name, pid, len(dates), fk)["forecast"].to_numpy(dtype=float)
            sources = [f"{model_name} re-run with planned discount {scenario.discount_pct:g}% / promotion for {n} day(s) (user-supplied inputs, model-predicted response)"]
            base_n, scen_n = base_daily[:n].sum(), scen_daily[:n].sum()
            if base_n > 0:
                chg = scen_n / base_n - 1
                narrative.append(f"During the {n}-day promotion window the model predicts {scen_n:.0f} units vs {base_n:.0f} without it ({chg:+.0%}).")
                if chg <= 0:
                    narrative.append("Note: the model did not learn a positive demand response for this input combination - treat this scenario with caution or use the manual adjustment.")
            if support["historical_promo_ratio"]:
                narrative.append(f"For reference, this product historically sold {support['historical_promo_ratio']:.2f}x as many units on promotion days (raw average, not causal).")
        else:
            narrative.append("Promotion/discount inputs were NOT applied to the model: " + "; ".join(support["reasons"]) +
                             ". Use the manual demand adjustment instead.")
    if abs(scenario.demand_adjust_pct) > 1e-9:
        scen_daily = scen_daily * (1 + scenario.demand_adjust_pct / 100.0)
        sources.append(f"manual demand adjustment {scenario.demand_adjust_pct:+g}% (USER ASSUMPTION, not a model prediction)")
    scen_daily = np.clip(scen_daily, 0, None)

    rstd = resid_std_map(bundle, model_name).get(pid)
    hstd = hist_std_map(ctx.panel).get(pid)
    name = ctx.names.get(pid, pid)
    start = ctx.last_date + pd.Timedelta(days=1)
    orig_inv = compute_product_inventory(base_daily, original.on_hand, original.on_order, original.backorders, original.lead_time_days,
                                         original.lead_time_std_days, _policy_for(base_policy, original, False), rstd, hstd, name, start)
    rev_inv = compute_product_inventory(scen_daily, scenario.on_hand, scenario.on_order, scenario.backorders, scenario.lead_time_days,
                                        scenario.lead_time_std_days, _policy_for(base_policy, scenario, True), rstd, hstd, name, start)

    keys = [("Forecast, next 7 days", "forecast_7d"), ("Forecast, next 30 days", "forecast_30d"), ("On-hand stock", "on_hand"),
            ("Lead time (days)", "lead_time_days"), ("Lead-time demand", "lead_time_demand"), ("Safety stock", "safety_stock"),
            ("Reorder point", "reorder_point"), ("Inventory position", "inventory_position"), ("Target stock", "target_stock"),
            ("Recommended order qty", "recommended_order_qty"), ("Stock cover on hand (days)", "coverage_days_on_hand"),
            ("Risk level", "risk_level")]
    rows = []
    for label, k in keys:
        a, b = orig_inv.get(k), rev_inv.get(k)
        d = (b - a) if isinstance(a, (int, float, np.floating)) and isinstance(b, (int, float, np.floating)) else ("changed" if a != b else "-")
        rows.append({"Metric": label, "Original": a, "Simulated": b, "Change": d})
    diff = pd.DataFrame(rows)

    if abs(scenario.lead_time_days - original.lead_time_days) > 1e-9:
        narrative.append(
            f"Lead time changed {original.lead_time_days:g} -> {scenario.lead_time_days:g} days: lead-time demand moves from "
            f"{orig_inv['lead_time_demand']:.0f} to {rev_inv['lead_time_demand']:.0f} units and the reorder point from "
            f"{orig_inv['reorder_point']:.0f} to {rev_inv['reorder_point']:.0f}. A longer replenishment time means more demand "
            "occurs before new stock arrives, so you must order earlier and/or hold more safety stock.")
    if abs(scenario.on_hand - original.on_hand) > 1e-9:
        narrative.append(f"On-hand stock changed {original.on_hand:g} -> {scenario.on_hand:g}: inventory position {orig_inv['inventory_position']:.0f} -> {rev_inv['inventory_position']:.0f}.")
    if orig_inv["risk_level"] != rev_inv["risk_level"]:
        narrative.append(f"Risk level changes from '{orig_inv['risk_level']}' to '{rev_inv['risk_level']}'.")
    if abs(rev_inv["recommended_order_qty"] - orig_inv["recommended_order_qty"]) > 0.5:
        narrative.append(f"Recommended order quantity changes from {orig_inv['recommended_order_qty']:.0f} to {rev_inv['recommended_order_qty']:.0f} units.")
    rng = baseline[["date", "lower_est", "upper_est"]] if baseline["lower_est"].notna().any() else None
    return ScenarioResult(dates, base_daily, scen_daily, orig_inv, rev_inv, diff, " + ".join(sources), support, narrative, rng)


def scenario_from_inventory(ctx: DatasetContext, product_id: str, policy: InventoryPolicy) -> Scenario:
    """Initial scenario = current inventory record (missing values are replaced by policy defaults)."""
    r = ctx.inventory[ctx.inventory["product_id"] == product_id]
    g = lambda c, d: float(r[c].iloc[0]) if len(r) and pd.notna(r[c].iloc[0]) else d  # noqa: E731
    return Scenario(product_id=product_id, on_hand=g("on_hand", 0.0), lead_time_days=g("lead_time_days", policy.default_lead_time_days),
                    lead_time_std_days=g("lead_time_std_days", 0.0), on_order=g("on_order", 0.0), backorders=g("backorders", 0.0),
                    review_period_days=policy.review_period_days, service_level=policy.service_level)
