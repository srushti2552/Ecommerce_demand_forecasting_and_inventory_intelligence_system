"""Demand anomaly detection (Isolation Forest + robust rolling statistics).

Point-in-time features: every feature for day t is computed from days BEFORE t (shifted rolling statistics) plus the
observed value on day t, so no future observation influences a day's features.
NOTE: the Isolation Forest itself is fitted on the whole analysed window (retrospective monitoring); flagged points are
"unusual relative to the product's own recent behaviour", not probabilities of anything.
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

import config

FEATURES = ["ratio_to_ref28", "z_robust", "ratio_to_lastweek", "vol_ratio_7_28"]


def anomaly_features(panel: pd.DataFrame) -> pd.DataFrame:
    """Per product-day features describing how unusual the observed sales are versus the PRECEDING history."""
    df = panel.sort_values(["product_id", "date"]).reset_index(drop=True).copy()
    g = df.groupby("product_id", sort=False)["units_sold"]
    s1 = g.shift(1)
    grp = s1.groupby(df["product_id"], sort=False)
    df["ref_mean_28"] = grp.transform(lambda s: s.rolling(28, min_periods=28).mean())
    df["ref_median_28"] = grp.transform(lambda s: s.rolling(28, min_periods=28).median())
    df["ref_mad_28"] = grp.transform(lambda s: s.rolling(28, min_periods=28).apply(lambda x: np.median(np.abs(x - np.median(x))), raw=True))
    df["ref_std_7"] = grp.transform(lambda s: s.rolling(7, min_periods=7).std())
    df["ref_std_28"] = grp.transform(lambda s: s.rolling(28, min_periods=28).std())
    df["lag_7"] = g.shift(7)
    # day-of-week aware reference: expected = 28-day mean (weekly pattern is handled by the lag-7 ratio)
    df["ratio_to_ref28"] = df["units_sold"] / (df["ref_mean_28"] + 1.0)
    scale = (1.4826 * df["ref_mad_28"]).clip(lower=1.0)
    df["z_robust"] = (df["units_sold"] - df["ref_median_28"]) / scale
    df["ratio_to_lastweek"] = df["units_sold"] / (df["lag_7"] + 1.0)
    df["vol_ratio_7_28"] = df["ref_std_7"] / (df["ref_std_28"] + 1e-6)
    return df


def detect_anomalies(panel: pd.DataFrame, contamination: float = config.ANOMALY_CONTAMINATION, z_threshold: float = 4.0,
                     drop_z_threshold: float = 3.0,
                     seed: int = config.RANDOM_SEED, min_reference: float = config.ANOMALY_MIN_DAILY_REFERENCE) -> pd.DataFrame:
    """Return flagged anomalies with scores, reference level, direction and method that fired."""
    f = anomaly_features(panel)
    ok = f[FEATURES].replace([np.inf, -np.inf], np.nan).notna().all(axis=1) & f["observed"] if "observed" in f.columns else \
        f[FEATURES].replace([np.inf, -np.inf], np.nan).notna().all(axis=1)
    f = f[ok].copy()
    if len(f) < 200:
        return pd.DataFrame()
    X = f[FEATURES].to_numpy(dtype=float)
    # log-transform the ratios so spikes and drops are symmetric for the isolation forest
    Xt = np.column_stack([np.log1p(np.clip(X[:, 0], 0, None)), np.clip(X[:, 1], -15, 15),
                          np.log1p(np.clip(X[:, 2], 0, None)), np.log1p(np.clip(X[:, 3], 0, None))])
    iso = IsolationForest(n_estimators=200, contamination=contamination, random_state=seed)
    iso.fit(Xt)
    f["anomaly_score"] = -iso.score_samples(Xt)           # higher = more unusual
    f["iforest_flag"] = iso.predict(Xt) == -1
    f["mad_flag"] = np.where(f["z_robust"] >= 0, f["z_robust"] >= z_threshold, f["z_robust"] <= -drop_z_threshold)
    big_enough = (f["ref_mean_28"] >= min_reference) | (f["units_sold"] >= 2 * min_reference)
    f["is_anomaly"] = f["iforest_flag"] & f["mad_flag"] & big_enough
    out = f[f["is_anomaly"]].copy()
    if out.empty:
        return pd.DataFrame()
    out["direction"] = np.where(out["units_sold"] >= out["ref_median_28"], "Spike", "Drop")
    out["reference_level"] = out["ref_mean_28"]
    out["deviation_units"] = out["units_sold"] - out["reference_level"]
    out["method"] = "Isolation Forest + robust z-score"
    out["promo_related"] = ((out.get("promotion", 0) > 0) | (out.get("discount_pct", 0) > 0)) if ("promotion" in out.columns or "discount_pct" in out.columns) else False
    keep = ["product_id", "product_name", "category", "date", "units_sold", "reference_level", "deviation_units", "z_robust",
            "anomaly_score", "direction", "method", "promo_related", "discount_pct", "promotion", "views", "on_hand", "ratio_to_ref28"]
    keep = [c for c in keep if c in out.columns]
    out = out[keep].sort_values("anomaly_score", ascending=False).reset_index(drop=True)
    out["hypotheses"] = out.apply(_hypotheses, axis=1)
    return out


def _hypotheses(r: pd.Series) -> str:
    """Possible explanations - HYPOTHESES to investigate, not conclusions."""
    h = []
    promo = r.get("promotion", 0)
    disc = r.get("discount_pct", 0)
    if r["direction"] == "Spike":
        if (pd.notna(promo) and promo > 0) or (pd.notna(disc) and disc > 0):
            h.append("coincides with a promotion/discount (may be an expected promotional lift)")
        h.append("possible unusual customer interest, marketing push or bulk/B2B order")
        h.append("possible data-quality issue (duplicate load or mis-keyed quantity)")
    else:
        if r["units_sold"] == 0:
            h.append("zero sales: check for a stock-out, listing outage or missing data")
        if pd.notna(r.get("on_hand")) and r.get("on_hand") == 0:
            h.append("stock on hand was zero, so sales were probably capped by availability")
        h.append("possible site/payment issue, competitor action or delayed data capture")
    return "; ".join(h) + " (hypotheses only)"


def inventory_impact(anomaly_row: pd.Series, on_hand: Optional[float], lead_time_days: Optional[float]) -> Dict[str, object]:
    """How would the anomalous demand level change stock risk, and should the inventory calculation be reviewed?"""
    ref, obs = float(anomaly_row["reference_level"]), float(anomaly_row["units_sold"])
    res: Dict[str, object] = {"extra_units_vs_reference": obs - ref}
    if on_hand is None or not np.isfinite(on_hand):
        res["note"] = "No on-hand stock available, so impact on stock risk cannot be quantified."
        return res
    cover_ref = on_hand / ref if ref > 0 else np.inf
    cover_obs = on_hand / obs if obs > 0 else np.inf
    res.update({"cover_days_at_reference": cover_ref, "cover_days_at_observed_rate": cover_obs})
    L = lead_time_days if lead_time_days and np.isfinite(lead_time_days) else None
    if anomaly_row["direction"] == "Spike":
        msg = f"If demand stayed at {obs:.0f}/day instead of ~{ref:.0f}/day, current stock would last {cover_obs:.1f} days instead of {cover_ref:.1f}."
        if L is not None and cover_obs < L:
            msg += f" That is shorter than the {L:g}-day lead time -> review the reorder point/safety stock."
        else:
            msg += " An anomaly is not evidence that demand will persist; review only if it repeats."
    else:
        msg = (f"Observed {obs:.0f} vs ~{ref:.0f}/day reference. A one-off drop does not by itself justify cutting stock; "
               "check whether it was an outage or data gap before changing inventory settings.")
    res["note"] = msg
    return res
