"""SQLite persistence.

What is stored WHERE
--------------------
SQLite (data/app.db)  : dataset metadata, inventory snapshots (editable), forecast runs + forecasts, model runs and
                        their evaluation metrics, inventory recommendations, anomaly results + investigation status,
                        saved simulator scenarios.
CSV files (data/)     : the (large) daily sales tables - sample_sales.csv.gz and uploaded_<key>.csv.gz - are NOT copied
                        into SQLite, to avoid duplicating big tables.
Joblib (models/)      : trained model bundles (<dataset_key>.joblib + a human-readable .json summary).
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS datasets(
    dataset_key TEXT PRIMARY KEY, name TEXT, source TEXT, is_synthetic INTEGER, n_rows INTEGER, n_products INTEGER,
    date_min TEXT, date_max TEXT, created_at TEXT, meta_json TEXT);
CREATE TABLE IF NOT EXISTS inventory(
    dataset_key TEXT, product_id TEXT, on_hand REAL, on_order REAL, backorders REAL, lead_time_days REAL,
    lead_time_std_days REAL, unit_cost REAL, updated_at TEXT, PRIMARY KEY(dataset_key, product_id));
CREATE TABLE IF NOT EXISTS products(
    dataset_key TEXT, product_id TEXT, product_name TEXT, category TEXT, launch_date TEXT, active INTEGER,
    PRIMARY KEY(dataset_key, product_id));
CREATE TABLE IF NOT EXISTS forecast_runs(
    run_id INTEGER PRIMARY KEY AUTOINCREMENT, dataset_key TEXT, created_at TEXT, model_name TEXT, horizon_days INTEGER,
    params_json TEXT);
CREATE TABLE IF NOT EXISTS forecasts(
    run_id INTEGER, product_id TEXT, date TEXT, forecast REAL, lower_est REAL, upper_est REAL);
CREATE TABLE IF NOT EXISTS model_runs(
    run_id INTEGER PRIMARY KEY AUTOINCREMENT, dataset_key TEXT, created_at TEXT, selected_model TEXT, split_json TEXT);
CREATE TABLE IF NOT EXISTS model_evaluations(
    run_id INTEGER, model_name TEXT, split TEXT, mae REAL, rmse REAL, wape REAL, mape REAL, selected INTEGER);
CREATE TABLE IF NOT EXISTS recommendations(
    dataset_key TEXT, created_at TEXT, product_id TEXT, product_name TEXT, risk_level TEXT, on_hand REAL, on_order REAL,
    inventory_position REAL, lead_time_days REAL, lead_time_demand REAL, safety_stock REAL, reorder_point REAL,
    target_stock REAL, recommended_order_qty REAL, coverage_days_on_hand REAL, explanation TEXT, policy_json TEXT);
CREATE TABLE IF NOT EXISTS anomalies(
    dataset_key TEXT, product_id TEXT, date TEXT, units_sold REAL, reference_level REAL, anomaly_score REAL,
    direction TEXT, hypotheses TEXT, PRIMARY KEY(dataset_key, product_id, date));
CREATE TABLE IF NOT EXISTS anomaly_status(
    dataset_key TEXT, product_id TEXT, date TEXT, status TEXT, note TEXT, updated_at TEXT,
    PRIMARY KEY(dataset_key, product_id, date));
CREATE TABLE IF NOT EXISTS scenarios(
    scenario_id INTEGER PRIMARY KEY AUTOINCREMENT, dataset_key TEXT, created_at TEXT, product_id TEXT, name TEXT,
    config_json TEXT, result_json TEXT);
"""
DATASET_TABLES = ["inventory", "products", "recommendations", "anomalies", "anomaly_status", "scenarios", "forecast_runs", "model_runs"]


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def connect(db_path: Optional[Path] = None):
    path = Path(db_path or config.DB_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(path))
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db(db_path: Optional[Path] = None) -> None:
    with connect(db_path) as con:
        con.executescript(SCHEMA)


def register_dataset(key: str, name: str, source: str, is_synthetic: bool, n_rows: int, n_products: int,
                     date_min, date_max, meta: Optional[dict] = None, db_path=None) -> None:
    init_db(db_path)
    with connect(db_path) as con:
        con.execute("INSERT OR REPLACE INTO datasets VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (key, name, source, int(is_synthetic), int(n_rows), int(n_products), str(date_min)[:10], str(date_max)[:10],
                     _now(), json.dumps(meta or {}, default=str)))


def list_datasets(db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        return pd.read_sql_query("SELECT * FROM datasets ORDER BY created_at DESC", con)


def save_products(key: str, meta: pd.DataFrame, db_path=None) -> None:
    init_db(db_path)
    rows = [(key, r.product_id, r.product_name, r.category, str(r.launch_date)[:10] if pd.notna(r.launch_date) else None, int(r.active))
            for r in meta.itertuples()]
    with connect(db_path) as con:
        con.execute("DELETE FROM products WHERE dataset_key=?", (key,))
        con.executemany("INSERT INTO products VALUES (?,?,?,?,?,?)", rows)


def save_inventory(key: str, inv: pd.DataFrame, db_path=None) -> None:
    init_db(db_path)
    cols = ["on_hand", "on_order", "backorders", "lead_time_days", "lead_time_std_days", "unit_cost"]
    ts = _now()
    rows = []
    for r in inv.itertuples(index=False):
        d = r._asdict()
        rows.append((key, str(d["product_id"])) + tuple(None if pd.isna(d.get(c)) else float(d.get(c)) for c in cols) + (ts,))
    with connect(db_path) as con:
        con.execute("DELETE FROM inventory WHERE dataset_key=?", (key,))
        con.executemany("INSERT INTO inventory VALUES (?,?,?,?,?,?,?,?,?)", rows)


def load_inventory(key: str, db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        return pd.read_sql_query("SELECT product_id,on_hand,on_order,backorders,lead_time_days,lead_time_std_days,unit_cost "
                                 "FROM inventory WHERE dataset_key=?", con, params=(key,))


def save_model_run(key: str, bundle: dict, db_path=None) -> int:
    init_db(db_path)
    with connect(db_path) as con:
        cur = con.execute("INSERT INTO model_runs(dataset_key, created_at, selected_model, split_json) VALUES (?,?,?,?)",
                          (key, bundle.get("trained_at", _now()), bundle["selected"], json.dumps(bundle["split"])))
        rid = cur.lastrowid
        rows = []
        for r in bundle["comparison"].itertuples():
            sel = int(r.selected)
            rows.append((rid, r.model, "validation", r.MAE_val, r.RMSE_val, r.WAPE_val, r.MAPE_val, sel))
            rows.append((rid, r.model, "test", r.MAE_test, r.RMSE_test, r.WAPE_test, r.MAPE_test, sel))
        con.executemany("INSERT INTO model_evaluations VALUES (?,?,?,?,?,?,?,?)", rows)
    return rid


def load_model_runs(key: str, db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        return pd.read_sql_query(
            "SELECT m.run_id, m.created_at, m.selected_model, e.model_name, e.split, e.mae, e.rmse, e.wape, e.mape, e.selected "
            "FROM model_runs m JOIN model_evaluations e USING(run_id) WHERE m.dataset_key=? ORDER BY m.run_id DESC", con, params=(key,))


def save_forecast_run(key: str, forecast: pd.DataFrame, model_name: str, horizon: int, params: Optional[dict] = None, db_path=None) -> int:
    init_db(db_path)
    with connect(db_path) as con:
        cur = con.execute("INSERT INTO forecast_runs(dataset_key, created_at, model_name, horizon_days, params_json) VALUES (?,?,?,?,?)",
                          (key, _now(), model_name, int(horizon), json.dumps(params or {}, default=str)))
        rid = cur.lastrowid
        rows = [(rid, r.product_id, str(pd.Timestamp(r.date).date()), float(r.forecast),
                 None if pd.isna(r.lower_est) else float(r.lower_est), None if pd.isna(r.upper_est) else float(r.upper_est))
                for r in forecast.itertuples()]
        con.executemany("INSERT INTO forecasts VALUES (?,?,?,?,?,?)", rows)
    return rid


def list_forecast_runs(key: str, db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        return pd.read_sql_query("SELECT * FROM forecast_runs WHERE dataset_key=? ORDER BY run_id DESC", con, params=(key,))


def save_recommendations(key: str, rec: pd.DataFrame, policy: Optional[dict] = None, db_path=None) -> None:
    init_db(db_path)
    ts = _now()
    pj = json.dumps(policy or {}, default=str)
    num = lambda v: None if v is None or pd.isna(v) else float(v)  # noqa: E731
    rows = [(key, ts, r.product_id, r.product_name, r.risk_level, num(r.on_hand), num(r.on_order), num(r.inventory_position),
             num(r.lead_time_days), num(r.lead_time_demand), num(r.safety_stock), num(r.reorder_point), num(r.target_stock),
             num(r.recommended_order_qty), num(r.coverage_days_on_hand), r.explanation, pj) for r in rec.itertuples()]
    with connect(db_path) as con:
        con.execute("DELETE FROM recommendations WHERE dataset_key=?", (key,))
        con.executemany("INSERT INTO recommendations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)


def load_recommendations(key: str, db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        return pd.read_sql_query("SELECT * FROM recommendations WHERE dataset_key=?", con, params=(key,))


def save_anomalies(key: str, an: pd.DataFrame, db_path=None) -> None:
    init_db(db_path)
    rows = [(key, r.product_id, str(pd.Timestamp(r.date).date()), float(r.units_sold), float(r.reference_level), float(r.anomaly_score),
             r.direction, r.hypotheses) for r in an.itertuples()]
    with connect(db_path) as con:
        con.execute("DELETE FROM anomalies WHERE dataset_key=?", (key,))
        con.executemany("INSERT OR REPLACE INTO anomalies VALUES (?,?,?,?,?,?,?,?)", rows)


def set_anomaly_status(key: str, product_id: str, date, status: str, note: str = "", db_path=None) -> None:
    init_db(db_path)
    with connect(db_path) as con:
        con.execute("INSERT OR REPLACE INTO anomaly_status VALUES (?,?,?,?,?,?)",
                    (key, product_id, str(pd.Timestamp(date).date()), status, note, _now()))


def load_anomaly_status(key: str, db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        df = pd.read_sql_query("SELECT product_id, date, status, note FROM anomaly_status WHERE dataset_key=?", con, params=(key,))
    df["date"] = pd.to_datetime(df["date"])
    return df


def save_scenario(key: str, product_id: str, name: str, config_d: dict, result_d: dict, db_path=None) -> int:
    init_db(db_path)
    with connect(db_path) as con:
        cur = con.execute("INSERT INTO scenarios(dataset_key, created_at, product_id, name, config_json, result_json) VALUES (?,?,?,?,?,?)",
                          (key, _now(), product_id, name, json.dumps(config_d, default=str), json.dumps(result_d, default=str)))
        return cur.lastrowid


def list_scenarios(key: str, db_path=None) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as con:
        return pd.read_sql_query("SELECT scenario_id, created_at, product_id, name, config_json, result_json FROM scenarios "
                                 "WHERE dataset_key=? ORDER BY scenario_id DESC", con, params=(key,))


def clear_dataset(key: str, db_path=None) -> None:
    """Delete everything stored for one dataset key (used by 'reset sample dataset' and when replacing uploads)."""
    init_db(db_path)
    with connect(db_path) as con:
        run_ids = [r[0] for r in con.execute("SELECT run_id FROM model_runs WHERE dataset_key=?", (key,))]
        for rid in run_ids:
            con.execute("DELETE FROM model_evaluations WHERE run_id=?", (rid,))
        fr = [r[0] for r in con.execute("SELECT run_id FROM forecast_runs WHERE dataset_key=?", (key,))]
        for rid in fr:
            con.execute("DELETE FROM forecasts WHERE run_id=?", (rid,))
        for t in DATASET_TABLES:
            con.execute(f"DELETE FROM {t} WHERE dataset_key=?", (key,))
        con.execute("DELETE FROM datasets WHERE dataset_key=?", (key,))
