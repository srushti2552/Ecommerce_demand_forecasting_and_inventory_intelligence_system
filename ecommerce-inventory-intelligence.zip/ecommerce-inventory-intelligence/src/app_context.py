"""Streamlit glue shared by every page: session state, caching, sidebar, display helpers.

Streamlit is imported at module level on purpose - this is the only module (besides app.py and pages/) that needs it.
Cached results are keyed by the dataset fingerprint and the model-bundle timestamp, so they are invalidated
automatically whenever the data or the trained models change.
"""
from __future__ import annotations

from typing import Optional

import pandas as pd
import streamlit as st

import config
from src import database as db
from src import forecasting as fc
from src import pipeline as pl
from src.anomaly_detection import detect_anomalies
from src.inventory_engine import InventoryPolicy
from src.product_clustering import cluster_products

CSS = """
<style>
.block-container {padding-top: 1.6rem; padding-bottom: 2rem; max-width: 1250px;}
h1 {font-size: 1.7rem !important; font-weight: 650 !important; margin-bottom: .2rem;}
h2, h3 {font-size: 1.15rem !important; font-weight: 600 !important;}
[data-testid="stMetricValue"] {font-size: 1.45rem;}
[data-testid="stMetricLabel"] {font-size: .8rem; color: #5b6573;}
.demo-banner {background:#fff4e0; border:1px solid #f1c27d; color:#7a4b00; padding:.35rem .7rem; border-radius:6px; font-size:.85rem;}
.real-banner {background:#e8f3ec; border:1px solid #9ec5ad; color:#1f5133; padding:.35rem .7rem; border-radius:6px; font-size:.85rem;}
.tag {display:inline-block; padding:.05rem .5rem; border-radius:10px; font-size:.75rem; margin-right:.3rem;}
.tag-model {background:#dbe8f5; color:#1f4e79;} .tag-user {background:#fde8c8; color:#8a5200;} .tag-calc {background:#e3efd9; color:#3b6320;}
</style>
"""


# ---- version-tolerant display helpers ---------------------------------------------------
def show_plot(fig, key: Optional[str] = None):
    try:
        st.plotly_chart(fig, use_container_width=True, key=key)
    except TypeError:                      # newest Streamlit versions replaced this argument
        st.plotly_chart(fig, width="stretch", key=key)


def show_df(df: pd.DataFrame, **kw):
    try:
        st.dataframe(df, use_container_width=True, hide_index=True, **kw)
    except TypeError:                      # newest Streamlit versions replaced this argument
        st.dataframe(df, width="stretch", hide_index=True, **kw)


def fmt_num(x, digits: int = 0) -> str:
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return "n/a"
    return f"{x:,.{digits}f}"


def fmt_money(x) -> str:
    return "n/a" if x is None else f"{x:,.0f}"


# ---- state ---------------------------------------------------------------------------
def init_state():
    db.init_db()
    if "ctx" not in st.session_state:
        with st.spinner("Loading demonstration dataset..."):
            st.session_state["ctx"] = pl.load_sample_context()
        st.session_state["bundle"] = None


def get_ctx() -> pl.DatasetContext:
    init_state()
    return st.session_state["ctx"]


def set_ctx(ctx: pl.DatasetContext):
    st.session_state["ctx"] = ctx
    st.session_state["bundle"] = None
    st.cache_data.clear()


def get_bundle(auto_train: bool = True) -> Optional[dict]:
    """Return the trained model bundle for the current dataset (loading from disk, or training with a progress bar)."""
    ctx = get_ctx()
    b = st.session_state.get("bundle")
    if b is not None and b.get("fingerprint") == ctx.fingerprint:
        return b
    b = fc.load_bundle(ctx.key)
    if b is not None and b.get("fingerprint") == ctx.fingerprint:
        st.session_state["bundle"] = b
        return b
    if not auto_train:
        return None
    return train_with_progress(force=True)


def train_with_progress(force: bool = True) -> Optional[dict]:
    ctx = get_ctx()
    bar = st.progress(0.0, text="Training models...")
    try:
        b = pl.get_or_train_bundle(ctx, force=force, progress=lambda f, m: bar.progress(min(1.0, f), text=m))
    except ValueError as exc:
        bar.empty()
        st.error(f"Models could not be trained: {exc}")
        st.session_state["bundle"] = None
        return None
    bar.empty()
    st.session_state["bundle"] = b
    st.cache_data.clear()
    return b


# ---- sidebar -------------------------------------------------------------------------
def setup_page(title: str, subtitle: str = "", need_model: bool = True, policy_controls: bool = False):
    """Call first in every page. Returns (ctx, bundle, policy)."""
    st.set_page_config(page_title=f"{title} | Inventory Intelligence", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    ctx = get_ctx()
    with st.sidebar:
        st.markdown("**Inventory Intelligence**")
        if ctx.is_synthetic:
            st.markdown(f"<div class='demo-banner'><b>DEMO DATA</b><br>{config.DEMO_LABEL}</div>", unsafe_allow_html=True)
        else:
            st.markdown(f"<div class='real-banner'><b>Uploaded data</b><br>{ctx.name}</div>", unsafe_allow_html=True)
        st.caption(f"{ctx.panel['product_id'].nunique()} products | {ctx.panel['date'].min():%d %b %Y} - {ctx.panel['date'].max():%d %b %Y}")
    policy = policy_sidebar() if policy_controls else default_policy()
    st.title(title)
    if subtitle:
        st.caption(subtitle)
    if ctx.is_synthetic:
        st.markdown(f"<div class='demo-banner'>{config.DEMO_LABEL}. Metrics shown are measured on this generated data only.</div>", unsafe_allow_html=True)
    bundle = get_bundle() if need_model else get_bundle(auto_train=False)
    if need_model and bundle is None:
        st.stop()
    return ctx, bundle, policy


def default_policy() -> InventoryPolicy:
    return st.session_state.get("policy", InventoryPolicy())


def policy_sidebar() -> InventoryPolicy:
    base = st.session_state.get("policy", InventoryPolicy())
    with st.sidebar:
        st.markdown("---")
        st.markdown("**Inventory policy**")
        review = st.number_input("Review period (days)", 0, 60, int(base.review_period_days), 1, key="pol_review",
                                 help="How often stock is reviewed/ordered. Target stock covers lead time + this period.")
        method_label = st.selectbox("Safety stock method", ["Statistical (service level)", "Days of demand", "Fixed units"],
                                    index={"statistical": 0, "days": 1, "units": 2}[base.safety_method], key="pol_method")
        method = {"Statistical (service level)": "statistical", "Days of demand": "days", "Fixed units": "units"}[method_label]
        sl = st.slider("Target service level", 0.80, 0.995, float(base.service_level), 0.005, key="pol_sl", disabled=method != "statistical")
        sdays = st.number_input("Safety days", 0.0, 60.0, float(base.safety_days), 0.5, key="pol_sdays", disabled=method != "days")
        sunits = st.number_input("Safety units", 0.0, 100000.0, float(base.safety_units), 5.0, key="pol_sunits", disabled=method != "units")
        dl = st.number_input("Default lead time if missing (days)", 1, 120, int(base.default_lead_time_days), 1, key="pol_dlt")
        with st.expander("Classification thresholds"):
            crit = st.number_input("Critical if on-hand covers < N days", 0.5, 30.0, float(base.critical_cover_days), 0.5, key="pol_crit")
            extra = st.number_input("Overstock: extra cover beyond lead+review (days)", 5.0, 365.0, float(base.overstock_extra_cover_days), 5.0, key="pol_ex")
            mult = st.number_input("Overstock: position > N x target", 1.0, 10.0, float(base.overstock_target_multiple), 0.5, key="pol_mult")
            scov = st.number_input("Slow-moving: cover above N days", 10.0, 365.0, float(base.slow_cover_days), 5.0, key="pol_scov")
    pol = InventoryPolicy(review_period_days=float(review), service_level=float(sl), safety_method=method, safety_days=float(sdays),
                          safety_units=float(sunits), default_lead_time_days=float(dl), critical_cover_days=float(crit),
                          overstock_extra_cover_days=float(extra), overstock_target_multiple=float(mult), slow_cover_days=float(scov))
    st.session_state["policy"] = pol
    return pol


# ---- cached computations ---------------------------------------------------------------
@st.cache_data(show_spinner=False)
def _forecast_cached(fp: str, bundle_stamp: str, model_name: str, horizon: int, products: tuple, _ctx, _bundle) -> pd.DataFrame:
    return pl.forecast_products(_ctx, _bundle, model_name, horizon, list(products) if products else None)


def get_forecast(ctx, bundle, model_name: Optional[str] = None, horizon: int = 30, products=None) -> pd.DataFrame:
    model_name = model_name or bundle["selected"]
    return _forecast_cached(ctx.fingerprint, bundle["trained_at"], model_name, int(horizon), tuple(sorted(products)) if products else (),
                            ctx, bundle)


def get_recommendations(ctx, bundle, policy: InventoryPolicy, model_name: Optional[str] = None) -> pd.DataFrame:
    model_name = model_name or bundle["selected"]
    inv = ctx.inventory
    fcst = get_forecast(ctx, bundle, model_name, pl.needed_horizon(inv, policy))
    return pl.recommendations_for(ctx, bundle, policy, model_name, fcst, inv)


@st.cache_data(show_spinner=False)
def _anomalies_cached(fp: str, contamination: float, _panel) -> pd.DataFrame:
    return detect_anomalies(_panel, contamination=contamination)


def get_anomalies(ctx, contamination: float = config.ANOMALY_CONTAMINATION) -> pd.DataFrame:
    return _anomalies_cached(ctx.fingerprint, float(contamination), ctx.panel)


@st.cache_data(show_spinner=False)
def _clusters_cached(fp: str, k: int, _panel) -> dict:
    return cluster_products(_panel, k=k or None)


def get_clusters(ctx, k: int = 0) -> dict:
    return _clusters_cached(ctx.fingerprint, int(k), ctx.panel)


def tag(kind: str, text: str) -> str:
    cls = {"model": "tag-model", "user": "tag-user", "calc": "tag-calc"}[kind]
    return f"<span class='tag {cls}'>{text}</span>"
