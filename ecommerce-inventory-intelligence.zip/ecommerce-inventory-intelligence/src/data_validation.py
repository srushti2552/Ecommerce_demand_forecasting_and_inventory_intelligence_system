"""CSV validation, column mapping and data-quality reporting.

Principles
- Required fields missing -> clear error, no invented data.
- Rows with unparseable dates / non-numeric or negative units are DROPPED and counted (never silently zero-filled).
- Optional fields are validated when present; invalid optional values become missing (NaN), not guessed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

SALES_REQUIRED = ["date", "product_id", "units_sold"]
SALES_OPTIONAL = ["product_name", "category", "unit_price", "discount_pct", "promotion", "rating", "views",
                  "add_to_cart", "on_hand", "lead_time_days", "unit_cost", "launch_date", "customer_id"]
SALES_FIELDS = SALES_REQUIRED + SALES_OPTIONAL
NUMERIC_OPTIONAL = ["unit_price", "discount_pct", "rating", "views", "add_to_cart", "on_hand", "lead_time_days", "unit_cost"]

INVENTORY_REQUIRED = ["product_id", "on_hand"]
INVENTORY_OPTIONAL = ["on_order", "backorders", "lead_time_days", "lead_time_std_days", "unit_cost"]
INVENTORY_FIELDS = INVENTORY_REQUIRED + INVENTORY_OPTIONAL

ALIASES = {
    "date": ["date", "order_date", "sale_date", "sales_date", "day", "timestamp", "invoice_date", "orderdate", "invoicedate"],
    "product_id": ["product_id", "sku", "item_id", "productid", "stockcode", "item", "product_code", "stock_code"],
    "units_sold": ["units_sold", "quantity", "qty", "units", "sales_qty", "quantity_sold", "sold", "unitssold"],
    "product_name": ["product_name", "name", "description", "item_name", "title", "productname"],
    "category": ["category", "product_category", "department", "class", "category_name"],
    "unit_price": ["unit_price", "price", "selling_price", "unitprice", "list_price"],
    "discount_pct": ["discount_pct", "discount", "discount_percent", "discount_percentage"],
    "promotion": ["promotion", "promo", "is_promo", "on_promotion", "promotion_flag"],
    "rating": ["rating", "product_rating", "avg_rating", "stars"],
    "views": ["views", "page_views", "website_views", "visits", "product_views"],
    "add_to_cart": ["add_to_cart", "cart_adds", "add_to_cart_count", "carts", "adds_to_cart"],
    "on_hand": ["on_hand", "on_hand_inventory", "stock", "current_stock", "inventory", "stock_on_hand", "quantity_on_hand"],
    "lead_time_days": ["lead_time_days", "lead_time", "supplier_lead_time", "leadtime"],
    "unit_cost": ["unit_cost", "cost", "cogs", "cost_price"],
    "launch_date": ["launch_date", "release_date", "introduced_on"],
    "customer_id": ["customer_id", "customerid", "user_id", "cust_id", "client_id"],
    "on_order": ["on_order", "on_order_stock", "open_po", "outstanding_po", "incoming", "on_order_qty"],
    "backorders": ["backorders", "backorder", "back_orders", "backordered"],
    "lead_time_std_days": ["lead_time_std_days", "lead_time_std", "lead_time_sd"],
}


def _norm(c: str) -> str:
    return str(c).strip().lower().replace(" ", "_").replace("-", "_")


def suggest_mapping(columns, fields: List[str]) -> Dict[str, Optional[str]]:
    """Guess which source column maps to each canonical field (None if no match)."""
    lookup = {_norm(c): c for c in columns}
    mapping: Dict[str, Optional[str]] = {}
    used = set()
    for f in fields:
        found = None
        for alias in ALIASES.get(f, [f]):
            src = lookup.get(alias)
            if src is not None and src not in used:
                found = src
                break
        mapping[f] = found
        if found:
            used.add(found)
    return mapping


@dataclass
class ValidationReport:
    ok: bool = False
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    info: Dict[str, object] = field(default_factory=dict)
    missing_summary: Optional[pd.DataFrame] = None
    issue_rows: Optional[pd.DataFrame] = None
    cleaned: Optional[pd.DataFrame] = None

    def summary_lines(self) -> List[str]:
        lines = [f"ERROR: {e}" for e in self.errors] + [f"Warning: {w}" for w in self.warnings]
        return lines or ["No issues found."]


def _to_bool01(s: pd.Series) -> pd.Series:
    txt = s.astype(str).str.strip().str.lower()
    truthy = txt.isin(["1", "true", "yes", "y", "t", "promo"])
    num = pd.to_numeric(s, errors="coerce")
    return (truthy | (num.fillna(0) > 0)).astype(int)


def _select_mapped(raw: pd.DataFrame, mapping: Dict[str, Optional[str]], fields: List[str]) -> pd.DataFrame:
    out = pd.DataFrame(index=raw.index)
    for f in fields:
        src = mapping.get(f)
        if src and src in raw.columns:
            out[f] = raw[src]
    return out


def validate_sales(raw: pd.DataFrame, mapping: Optional[Dict[str, Optional[str]]] = None,
                   dayfirst: bool = False) -> ValidationReport:
    """Validate and standardise a raw sales table. Returns a ValidationReport (cleaned df in .cleaned)."""
    rep = ValidationReport()
    if raw is None or len(raw) == 0:
        rep.errors.append("The file is empty - no rows to analyse.")
        return rep
    mapping = mapping or suggest_mapping(raw.columns, SALES_FIELDS)

    missing_req = [f for f in SALES_REQUIRED if not mapping.get(f) or mapping[f] not in raw.columns]
    if missing_req:
        hints = {"date": "a date column", "product_id": "a product identifier / SKU", "units_sold": "quantity sold per row"}
        for f in missing_req:
            rep.errors.append(f"Required field '{f}' is not mapped ({hints[f]}). Map a column to it before continuing.")
        return rep

    df = _select_mapped(raw, mapping, SALES_FIELDS)
    n0 = len(df)
    rep.info["rows_uploaded"] = n0
    absent_optional = [f for f in SALES_OPTIONAL if f not in df.columns]
    rep.info["optional_fields_absent"] = absent_optional

    # dates
    df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=dayfirst)
    bad_date = df["date"].isna()
    # product id
    df["product_id"] = df["product_id"].astype(str).str.strip()
    bad_pid = df["product_id"].isin(["", "nan", "None", "NaN"])
    # units
    df["units_sold"] = pd.to_numeric(df["units_sold"], errors="coerce")
    bad_units_nonnum = df["units_sold"].isna()
    bad_units_neg = df["units_sold"] < 0
    bad_units_inf = ~np.isfinite(df["units_sold"].astype(float).fillna(0))

    issue_masks = {"invalid or missing date": bad_date, "missing product_id": bad_pid,
                   "missing or non-numeric units_sold": bad_units_nonnum, "negative units_sold": bad_units_neg,
                   "non-finite units_sold": bad_units_inf}
    counts = {k: int(m.sum()) for k, m in issue_masks.items()}
    rep.info["invalid_counts"] = counts
    drop = bad_date | bad_pid | bad_units_nonnum | bad_units_neg | bad_units_inf
    if drop.any():
        rep.issue_rows = raw.loc[drop].head(200)
        for k, c in counts.items():
            if c:
                rep.warnings.append(f"{c} row(s) with {k} were removed.")
    df = df.loc[~drop].copy()
    if len(df) == 0:
        rep.errors.append("No valid rows remain after removing invalid dates/products/units. Check the column mapping and date format.")
        return rep
    if drop.mean() > 0.2:
        rep.errors.append(f"{drop.mean():.0%} of rows are invalid - the column mapping or date format is probably wrong.")
        return rep

    # optional numerics
    for c in NUMERIC_OPTIONAL:
        if c in df.columns:
            before = df[c].notna().sum()
            df[c] = pd.to_numeric(df[c], errors="coerce")
            lost = int(before - df[c].notna().sum())
            if lost:
                rep.warnings.append(f"{lost} non-numeric value(s) in '{c}' were set to missing.")
    for c in ["unit_price", "unit_cost", "views", "add_to_cart", "on_hand", "lead_time_days"]:
        if c in df.columns:
            neg = (df[c] < 0).sum()
            if neg:
                df.loc[df[c] < 0, c] = np.nan
                rep.warnings.append(f"{int(neg)} negative value(s) in '{c}' were set to missing.")
    if "discount_pct" in df.columns:
        bad = ((df["discount_pct"] < 0) | (df["discount_pct"] > 100)).sum()
        if bad:
            df.loc[(df["discount_pct"] < 0) | (df["discount_pct"] > 100), "discount_pct"] = np.nan
            rep.warnings.append(f"{int(bad)} discount value(s) outside 0-100 were set to missing.")
        if df["discount_pct"].notna().any() and df["discount_pct"].max() <= 1.0 and df["discount_pct"].max() > 0:
            rep.warnings.append("All discount values are <= 1: they are interpreted as PERCENT (0.2 = 0.2%), not fractions. "
                                "Multiply by 100 first if your file stores fractions.")
    if "rating" in df.columns:
        out = ((df["rating"] < 0) | (df["rating"] > 5)).sum()
        if out:
            df.loc[(df["rating"] < 0) | (df["rating"] > 5), "rating"] = np.nan
            rep.warnings.append(f"{int(out)} rating value(s) outside 0-5 were set to missing.")
    if "promotion" in df.columns:
        df["promotion"] = _to_bool01(df["promotion"])
    if "launch_date" in df.columns:
        df["launch_date"] = pd.to_datetime(df["launch_date"], errors="coerce", dayfirst=dayfirst)
    for c in ["product_name", "category"]:
        if c in df.columns:
            df[c] = df[c].astype("string").str.strip()

    # duplicates
    exact = int(df.duplicated().sum())
    if exact:
        df = df.drop_duplicates()
        rep.warnings.append(f"{exact} exact duplicate row(s) were removed.")
    key_dups = int(df.duplicated(["date", "product_id"], keep=False).sum())
    rep.info["exact_duplicates_removed"] = exact
    rep.info["rows_sharing_date_product_key"] = key_dups
    if key_dups:
        rep.warnings.append(f"{key_dups} row(s) share the same date + product_id; they will be aggregated to one daily row "
                            "(units summed; views/add-to-cart use the maximum to avoid double counting).")
    if (df["units_sold"] % 1 != 0).any():
        rep.warnings.append("Some units_sold values are fractional; they are kept as-is.")

    # structure checks
    span = (df["date"].max() - df["date"].min()).days + 1
    rep.info.update({"rows_clean": len(df), "n_products": int(df["product_id"].nunique()),
                     "date_min": df["date"].min(), "date_max": df["date"].max(), "date_span_days": int(span)})
    if "category" in df.columns:
        rep.info["n_categories"] = int(df["category"].nunique())
    if span < 60:
        rep.warnings.append(f"Only {span} days of history: forecasting models need roughly {120}+ days to train and evaluate.")
    if df["units_sold"].sum() == 0:
        rep.errors.append("All units_sold values are zero - nothing to forecast.")
        return rep
    miss = df.isna().sum()
    rep.missing_summary = pd.DataFrame({"missing": miss, "pct": (miss / len(df) * 100).round(2)}).query("missing > 0")
    rep.cleaned = df.reset_index(drop=True)
    rep.ok = True
    return rep


def validate_inventory(raw: pd.DataFrame, mapping: Optional[Dict[str, Optional[str]]] = None) -> ValidationReport:
    """Validate a current-inventory snapshot (one row per product)."""
    rep = ValidationReport()
    if raw is None or len(raw) == 0:
        rep.errors.append("The inventory file is empty.")
        return rep
    mapping = mapping or suggest_mapping(raw.columns, INVENTORY_FIELDS)
    miss = [f for f in INVENTORY_REQUIRED if not mapping.get(f) or mapping[f] not in raw.columns]
    if miss:
        rep.errors.extend(f"Required inventory field '{f}' is not mapped." for f in miss)
        return rep
    df = _select_mapped(raw, mapping, INVENTORY_FIELDS)
    df["product_id"] = df["product_id"].astype(str).str.strip()
    for c in [c for c in INVENTORY_FIELDS if c != "product_id" and c in df.columns]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
        neg = int((df[c] < 0).sum())
        if neg:
            df.loc[df[c] < 0, c] = np.nan
            rep.warnings.append(f"{neg} negative value(s) in '{c}' were set to missing.")
    nm = int(df["on_hand"].isna().sum())
    if nm:
        rep.warnings.append(f"{nm} product(s) have no valid on_hand value; no stock decision will be made for them.")
    dup = int(df.duplicated("product_id").sum())
    if dup:
        df = df.drop_duplicates("product_id", keep="last")
        rep.warnings.append(f"{dup} duplicate product_id row(s) removed (last one kept).")
    absent = [f for f in INVENTORY_OPTIONAL if f not in df.columns]
    if absent:
        rep.warnings.append("Optional inventory fields not provided (treated as unknown, not invented): " + ", ".join(absent))
    rep.info.update({"rows_clean": len(df), "optional_fields_absent": absent})
    rep.cleaned = df.reset_index(drop=True)
    rep.ok = True
    return rep
