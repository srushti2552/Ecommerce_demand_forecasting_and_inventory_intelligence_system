"""K-Means product clustering with data-driven profile labels."""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

import config

MIN_PRODUCTS = 8


def product_features(panel: pd.DataFrame, inventory: Optional[pd.DataFrame] = None, window: int = 90) -> pd.DataFrame:
    last = panel["date"].max()
    rec = panel[panel["date"] > last - pd.Timedelta(days=window)]
    g = rec.groupby("product_id")["units_sold"]
    f = pd.DataFrame({"avg_daily_units": g.mean(), "cv": g.std(ddof=0) / g.mean().replace(0, np.nan)})
    f["cv"] = f["cv"].fillna(0)
    last28 = panel[panel["date"] > last - pd.Timedelta(days=28)].groupby("product_id")["units_sold"].mean()
    prior28 = panel[(panel["date"] <= last - pd.Timedelta(days=28)) & (panel["date"] > last - pd.Timedelta(days=56))].groupby("product_id")["units_sold"].mean()
    f["growth_28d"] = ((last28 - prior28) / (prior28 + 1.0)).reindex(f.index)
    if panel["unit_price"].notna().any():
        net = rec["units_sold"] * rec["unit_price"] * (1 - rec["discount_pct"].fillna(0) / 100)
        f["revenue"] = net.groupby(rec["product_id"]).sum()
    if rec["views"].notna().any():
        v = rec.groupby("product_id")[["views", "units_sold"]].sum()
        f["conversion"] = (v["units_sold"] / v["views"].replace(0, np.nan)).fillna(0)
    if panel["on_hand"].notna().any():
        avg_oh = rec.groupby("product_id")["on_hand"].mean()
        f["turnover"] = (g.sum() / avg_oh.replace(0, np.nan)).fillna(0)
    return f.fillna(0).reset_index()


def choose_k(Xs: np.ndarray, k_range=range(2, 7), seed: int = config.RANDOM_SEED) -> Tuple[int, pd.DataFrame]:
    """Pick k by silhouette score (higher = better separated), only over k values the data can support."""
    rows = []
    n = len(Xs)
    for k in k_range:
        if k >= n:
            continue
        km = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(Xs)
        if len(set(km.labels_)) < 2:
            continue
        rows.append({"k": k, "silhouette": silhouette_score(Xs, km.labels_), "inertia": km.inertia_})
    tbl = pd.DataFrame(rows)
    if tbl.empty:
        return 2, tbl
    return int(tbl.sort_values("silhouette", ascending=False).iloc[0]["k"]), tbl


def label_clusters(prof: pd.DataFrame) -> dict:
    """Name clusters from their ACTUAL statistics (mean demand and variability), not fixed IDs."""
    labels, remaining = {}, set(prof.index)
    if len(remaining) >= 2:
        slow = prof.loc[list(remaining), "avg_daily_units"].idxmin()
        labels[slow] = "Slow-Moving Products"
        remaining.discard(slow)
    if remaining:
        hi = prof.loc[list(remaining), "avg_daily_units"].idxmax()
        labels[hi] = "High-Demand Products"
        remaining.discard(hi)
    if remaining:
        hv = prof.loc[list(remaining), "cv"].idxmax()
        if prof.loc[hv, "cv"] > prof["cv"].median():
            labels[hv] = "High-Variability Products"
            remaining.discard(hv)
    for c in remaining:
        labels[c] = "Stable-Demand Products"
    # disambiguate duplicates
    seen = {}
    for c in sorted(labels):
        seen.setdefault(labels[c], []).append(c)
    for name, cs in seen.items():
        if len(cs) > 1:
            for j, c in enumerate(cs, 1):
                labels[c] = f"{name} ({j})"
    return labels


def cluster_products(panel: pd.DataFrame, inventory: Optional[pd.DataFrame] = None, k: Optional[int] = None,
                     seed: int = config.RANDOM_SEED):
    """Return dict(products=df, summary=df, k_selection=df, k=int, message=str|None)."""
    feats = product_features(panel, inventory)
    if len(feats) < MIN_PRODUCTS:
        return {"products": None, "summary": None, "k_selection": None, "k": None,
                "message": f"Clustering needs at least {MIN_PRODUCTS} products (found {len(feats)})."}
    cols = [c for c in ["avg_daily_units", "cv", "revenue", "growth_28d", "turnover", "conversion"] if c in feats.columns]
    X = feats[cols].copy()
    for c in ("avg_daily_units", "revenue", "turnover"):
        if c in X.columns:
            X[c] = np.log1p(X[c].clip(lower=0))     # tame heavy right skew before scaling
    Xs = StandardScaler().fit_transform(X)
    k_sel, tbl = choose_k(Xs, seed=seed)
    k_use = int(k) if k else k_sel
    km = KMeans(n_clusters=k_use, n_init=10, random_state=seed).fit(Xs)
    feats["cluster"] = km.labels_
    prof = feats.groupby("cluster")[cols].mean()
    prof["n_products"] = feats.groupby("cluster").size()
    labels = label_clusters(prof)
    feats["profile"] = feats["cluster"].map(labels)
    names = panel.groupby("product_id")[["product_name", "category"]].last()
    feats = feats.merge(names, left_on="product_id", right_index=True, how="left")
    summary = prof.rename(index=labels).reset_index().rename(columns={"cluster": "profile"})
    summary.insert(1, "cluster_id", prof.index.values)
    return {"products": feats, "summary": summary, "k_selection": tbl, "k": k_use, "selected_k_by_silhouette": k_sel,
            "features_used": cols, "message": None}


POLICY_NOTES = {
    "High-Demand": "Review often, keep higher safety stock and a high service level; prioritise supplier reliability.",
    "Stable": "Standard periodic review with a lean statistical safety stock; good candidates for automation.",
    "High-Variability": "Larger safety stock or shorter review period; investigate promotion/seasonal drivers.",
    "Slow-Moving": "Order in small lots, avoid overstock, consider delisting or clearance when cover is very long.",
}


def policy_note(profile: str) -> str:
    for k, v in POLICY_NOTES.items():
        if profile.startswith(k):
            return v
    return ""
