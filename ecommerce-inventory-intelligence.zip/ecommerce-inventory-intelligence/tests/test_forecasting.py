import numpy as np
import pandas as pd
import pytest

import config
from src import forecasting as fc
from src import model_evaluation as me
from src.data_loader import generate_synthetic_data
from src.data_validation import validate_sales
from src.pipeline import build_context, forecast_products
from tests.helpers import small_bundle, small_ctx


def test_metrics_known_values():
    a, p = [10, 0, 20], [8, 1, 25]
    assert me.mae(a, p) == pytest.approx((2 + 1 + 5) / 3)
    assert me.rmse(a, p) == pytest.approx(np.sqrt((4 + 1 + 25) / 3))
    assert me.wape(a, p) == pytest.approx(8 / 30)
    assert np.isnan(me.wape([0, 0], [1, 1]))                    # no division by zero
    assert me.mape_safe([0, 10], [5, 5]) == pytest.approx(0.5)  # zero-actual rows excluded


def test_model_comparison_table_and_selection_rule():
    b = small_bundle()
    comp = b["comparison"]
    assert set(fc.MODEL_NAMES) == set(comp["model"])
    for c in ["MAE_val", "RMSE_val", "WAPE_val", "MAE_test", "RMSE_test", "WAPE_test", "selected"]:
        assert c in comp.columns
    assert comp["selected"].sum() == 1
    chosen = comp.loc[comp["selected"], "model"].iloc[0]
    assert chosen == comp.sort_values(["WAPE_val", "RMSE_val"]).iloc[0]["model"]      # chosen on VALIDATION, not test
    assert chosen == b["selected"]


def test_evaluation_windows_are_chronological_and_unseen_by_fitting():
    b = small_bundle()
    ctx = small_ctx()
    vs, ts = pd.Timestamp(b["split"]["val_start"]), pd.Timestamp(b["split"]["test_start"])
    v, t = b["val_predictions"], b["test_predictions"]
    assert v["date"].min() >= vs and v["date"].max() < ts
    assert t["date"].min() >= ts
    # training rows used for the validation-stage fit all end BEFORE the validation window
    s = me.choose_split(ctx.wide.n_days)
    train = ctx.wide.training_frame(ctx.spec, t_end=s["val_start"])
    assert train["date"].max() < vs and len(train) == b["split"]["n_train_rows"]
    # each origin forecast only predicts days at/after its own origin
    assert (v["date"] >= v["origin_date"]).all() and (t["date"] >= t["origin_date"]).all()


def test_forecast_is_finite_nonnegative_and_correct_length_for_every_model():
    b, ctx = small_bundle(), small_ctx()
    for name in fc.MODEL_NAMES:
        for h in (7, 30):
            f = forecast_products(ctx, b, name, h)
            assert len(f) == h * f["product_id"].nunique()
            assert np.isfinite(f["forecast"]).all() and (f["forecast"] >= 0).all()
            assert f["date"].min() == ctx.last_date + pd.Timedelta(days=1)
            assert f["lower_est"].isna().all() or (f["lower_est"] <= f["upper_est"]).all()


def test_future_actuals_never_influence_a_forecast():
    b, ctx = small_bundle(), small_ctx()
    w, spec = ctx.wide, ctx.spec
    model = b["models"][b["selected"]]
    o = w.n_days - 30
    p1, _ = fc.recursive_forecast(model, w, spec, o, 14)
    w2 = w.copy()
    w2.U[:, o:] = 123456.0
    w2.V[:, o:] = 999999.0
    p2, _ = fc.recursive_forecast(model, w2, spec, o, 14)
    np.testing.assert_array_equal(p1, p2)


def test_recursive_strategy_feeds_predictions_forward():
    """With a lag_1-driven model the day-2 forecast must depend on the day-1 prediction (recursion), not on actuals."""
    b, ctx = small_bundle(), small_ctx()
    spec = ctx.spec
    m = b["models"][fc.RIDGE]
    p, _ = fc.recursive_forecast(m, ctx.wide, spec, ctx.wide.n_days, 3)
    assert np.isfinite(p).any() and p.shape[1] == 3


def test_scenario_discount_changes_model_forecast_but_baseline_assumes_none():
    b, ctx = small_bundle(), small_ctx()
    pid = ctx.forecastable_products[0]
    w = ctx.wide.subset([pid])
    model = b["models"][fc.HGB]
    d0 = fc.recursive_forecast(model, w, ctx.spec, w.n_days, 7)[0]
    dates = pd.date_range(ctx.last_date + pd.Timedelta(days=1), periods=7)
    fk = pd.DataFrame({"product_id": pid, "date": dates, "discount_pct": 30.0, "promotion": 1.0})
    d1 = fc.recursive_forecast(model, w, ctx.spec, w.n_days, 7, fk)[0]
    assert not np.allclose(d0, d1)


def test_insufficient_data_is_handled_gracefully():
    sales, _ = generate_synthetic_data(seed=1, n_products=4, start="2024-01-01", end="2024-03-01")
    rep = validate_sales(sales)
    ctx = build_context(rep.cleaned, None, "tiny", "tiny", True, persist=False)
    with pytest.raises(ValueError):
        me.train_and_evaluate(ctx.panel, ctx.meta, "tiny")


def test_bundle_save_and_load_roundtrip(tmp_path=None):
    import tempfile
    from pathlib import Path
    b = small_bundle()
    old = config.MODELS_DIR
    with tempfile.TemporaryDirectory() as d:
        config.MODELS_DIR = Path(d)
        try:
            fc.save_bundle(b, "rt")
            loaded = fc.load_bundle("rt")
            assert loaded["selected"] == b["selected"]
            assert (Path(d) / "rt.json").exists()
            ctx = small_ctx()
            f1 = forecast_products(ctx, b, None, 7)
            f2 = forecast_products(ctx, loaded, None, 7)
            np.testing.assert_allclose(f1["forecast"], f2["forecast"])
        finally:
            config.MODELS_DIR = old


def test_seasonal_naive_equals_lag_7():
    X = pd.DataFrame({"lag_7": [3.0, 4.0]})
    assert list(fc.SeasonalNaive().fit(X).predict(X)) == [3.0, 4.0]
