"""Anomaly detection, clustering, customer analytics, EDA and database tests."""
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from src import database as db
from src import eda
from src.anomaly_detection import anomaly_features, detect_anomalies, inventory_impact
from src.customer_analytics import customer_metrics, engagement_by_product
from src.product_clustering import cluster_products
from src.inventory_engine import compute_recommendations, InventoryPolicy
from tests.helpers import small_ctx


def test_anomaly_features_use_only_past_reference():
    p = small_ctx().panel.copy()
    f1 = anomaly_features(p)
    p2 = p.copy()
    cut = p2["date"].max() - pd.Timedelta(days=10)
    p2.loc[p2["date"] > cut, "units_sold"] = 99999
    f2 = anomaly_features(p2)
    a, b = f1[f1["date"] <= cut], f2[f2["date"] <= cut]
    np.testing.assert_allclose(a["ref_mean_28"].fillna(-1), b["ref_mean_28"].fillna(-1))
    np.testing.assert_allclose(a["z_robust"].fillna(-1), b["z_robust"].fillna(-1))


def test_injected_spike_is_detected_and_explained_as_hypothesis():
    p = small_ctx().panel.copy()
    pid = p["product_id"].iloc[0]
    d = p[(p["product_id"] == pid)]["date"].iloc[300]
    idx = p[(p["product_id"] == pid) & (p["date"] == d)].index[0]
    base = p.loc[idx, "units_sold"]
    p.loc[idx, ["units_sold", "promotion", "discount_pct"]] = [max(base, 5) * 12, 0, 0]
    a = detect_anomalies(p)
    hit = a[(a["product_id"] == pid) & (a["date"] == d)]
    assert len(hit) == 1 and hit.iloc[0]["direction"] == "Spike"
    assert "hypotheses only" in hit.iloc[0]["hypotheses"]
    imp = inventory_impact(hit.iloc[0], on_hand=50, lead_time_days=7)
    assert imp["cover_days_at_observed_rate"] < imp["cover_days_at_reference"]


def test_clustering_labels_follow_cluster_statistics():
    res = cluster_products(small_ctx().panel)
    prod, summ = res["products"], res["summary"]
    assert prod is not None and prod["cluster"].nunique() == res["k"]
    slow = summ.loc[summ["profile"].str.startswith("Slow"), "avg_daily_units"]
    assert len(slow) == 1 and slow.iloc[0] == summ["avg_daily_units"].min()
    hi = summ.loc[summ["profile"].str.startswith("High-Demand"), "avg_daily_units"]
    assert hi.iloc[0] == summ["avg_daily_units"].max()


def test_clustering_refuses_too_few_products():
    p = small_ctx().panel
    res = cluster_products(p[p["product_id"].isin(p["product_id"].unique()[:3])])
    assert res["products"] is None and "at least" in res["message"]


def test_customer_analytics_adapts_to_missing_fields():
    p = small_ctx().panel
    assert engagement_by_product(p) is not None
    no_views = p.drop(columns=["views", "add_to_cart"]).assign(views=np.nan, add_to_cart=np.nan)
    assert engagement_by_product(no_views) is None
    r = customer_metrics(pd.DataFrame({"date": pd.to_datetime(["2024-01-01"]), "units_sold": [1]}))
    assert r["available"] is False                                     # no fabricated customer analytics
    tx = pd.DataFrame({"date": pd.to_datetime(["2024-01-01", "2024-01-05", "2024-01-02"]), "units_sold": [1, 2, 1],
                       "customer_id": ["a", "a", "b"]})
    m = customer_metrics(tx)
    assert m["available"] and m["repeat_rate"] == pytest.approx(0.5)


def test_eda_filters_change_the_data():
    p = small_ctx().panel
    cat = p["category"].iloc[0]
    sub = eda.filter_panel(p, categories=[cat])
    assert 0 < len(sub) < len(p) and set(sub["category"]) == {cat}
    k_all, k_sub = eda.kpis(p), eda.kpis(sub)
    assert k_sub["total_units"] < k_all["total_units"]
    assert eda.kpis(p.iloc[0:0])["total_units"] == 0                    # empty selection handled


def test_database_roundtrip_and_clear():
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "x.db"
        inv = pd.DataFrame({"product_id": ["A"], "on_hand": [5.0], "on_order": [1.0], "backorders": [0.0], "lead_time_days": [3.0],
                            "lead_time_std_days": [np.nan], "unit_cost": [2.0]})
        db.save_inventory("k", inv, path)
        out = db.load_inventory("k", path)
        assert out.iloc[0]["on_hand"] == 5.0 and pd.isna(out.iloc[0]["lead_time_std_days"])
        fc = pd.DataFrame({"product_id": "A", "date": pd.date_range("2025-01-01", periods=3), "forecast": 4.0})
        rec = compute_recommendations(fc, inv, InventoryPolicy(safety_method="units", safety_units=1))
        db.save_recommendations("k", rec, {"p": 1}, path)
        assert len(db.load_recommendations("k", path)) == 1
        db.set_anomaly_status("k", "A", "2025-01-01", "Investigating", "checking", path)
        assert db.load_anomaly_status("k", path).iloc[0]["status"] == "Investigating"
        db.clear_dataset("k", path)
        assert db.load_inventory("k", path).empty and db.load_recommendations("k", path).empty
