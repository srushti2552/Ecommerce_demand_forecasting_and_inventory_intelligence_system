import io

import numpy as np
import pandas as pd
import pytest

from src.data_loader import read_csv_flexible
from src.data_validation import suggest_mapping, validate_inventory, validate_sales, SALES_FIELDS
from src.preprocessing import aggregate_daily, build_panel
from src.feature_engineering import FeatureSpec


def _df(**over):
    d = pd.DataFrame({"date": pd.date_range("2024-01-01", periods=10), "product_id": "A", "units_sold": range(1, 11)})
    for k, v in over.items():
        d[k] = v
    return d


def test_suggest_mapping_recognises_aliases():
    m = suggest_mapping(["Order Date", "SKU", "Qty", "Price"], SALES_FIELDS)
    assert m["date"] == "Order Date" and m["product_id"] == "SKU" and m["units_sold"] == "Qty" and m["unit_price"] == "Price"
    assert m["views"] is None


def test_missing_required_field_gives_clear_error_and_no_data():
    rep = validate_sales(_df().drop(columns=["units_sold"]))
    assert not rep.ok and rep.cleaned is None
    assert any("units_sold" in e for e in rep.errors)


def test_empty_file_error():
    rep = validate_sales(pd.DataFrame())
    assert not rep.ok and rep.errors


def test_invalid_rows_removed_not_zero_filled():
    d = pd.DataFrame({"date": pd.date_range("2024-01-01", periods=50), "product_id": "A", "units_sold": range(1, 51)})
    d["date"] = d["date"].astype(str).astype(object)
    d.loc[0, "date"] = "not a date"
    d["units_sold"] = d["units_sold"].astype(object)
    d.loc[1, "units_sold"] = "abc"
    d.loc[2, "units_sold"] = -5
    d.loc[3, "product_id"] = ""
    rep = validate_sales(d, dayfirst=False)
    assert rep.ok
    assert len(rep.cleaned) == 46                     # 4 bad rows dropped, never invented
    assert rep.cleaned["units_sold"].min() >= 0
    assert len(rep.warnings) >= 3


def test_too_many_invalid_rows_is_error():
    d = _df()
    d["units_sold"] = ["x"] * 6 + [1, 2, 3, 4]
    rep = validate_sales(d.astype({"units_sold": object}))
    assert not rep.ok


def test_duplicates_detected_and_aggregated():
    d = pd.concat([_df(), _df().iloc[[0]]], ignore_index=True)          # exact duplicate
    rep = validate_sales(d)
    assert rep.info["exact_duplicates_removed"] == 1
    d2 = pd.concat([_df(), _df().iloc[[0]].assign(units_sold=99)], ignore_index=True)   # same key, different units
    rep2 = validate_sales(d2)
    assert rep2.info["rows_sharing_date_product_key"] == 2
    agg = aggregate_daily(rep2.cleaned)
    assert len(agg) == 10 and agg["units_sold"].iloc[0] == 1 + 99


def test_numeric_and_range_validation_of_optional_fields():
    d = _df(unit_price=[10, -3, "x"] + [5] * 7, discount_pct=[0, 150] + [10] * 8, rating=[4.5, 9] + [4] * 8)
    rep = validate_sales(d)
    c = rep.cleaned
    assert np.isnan(c.loc[1, "unit_price"]) and np.isnan(c.loc[2, "unit_price"])
    assert np.isnan(c.loc[1, "discount_pct"])
    assert np.isnan(c.loc[1, "rating"])


def test_csv_upload_with_custom_columns_and_semicolons():
    text = "Day;Item;Quantity;Price\n2024-01-01;X1;3;9.5\n2024-01-02;X1;4;9.5\n2024-01-03;X1;5;9.5\n"
    raw = read_csv_flexible(io.StringIO(text))
    m = suggest_mapping(raw.columns, SALES_FIELDS)
    rep = validate_sales(raw, m)
    assert rep.ok and len(rep.cleaned) == 3 and "unit_price" in rep.cleaned.columns
    assert "views" in rep.info["optional_fields_absent"]


def test_csv_with_unmapped_required_column_explains_limitation():
    raw = read_csv_flexible(io.StringIO("foo,bar\n1,2\n3,4\n"))
    rep = validate_sales(raw)
    assert not rep.ok and any("Map a column" in e for e in rep.errors)


def test_inventory_validation_missing_and_negative():
    rep = validate_inventory(pd.DataFrame({"product_id": ["a", "b", "b"], "on_hand": [5, -1, 7]}))
    assert rep.ok and len(rep.cleaned) == 2
    assert "on_order" not in rep.cleaned.columns                  # optional fields are NOT invented
    assert any("Optional inventory fields" in w for w in rep.warnings)
    bad = validate_inventory(pd.DataFrame({"product_id": ["a"], "stock_x": [1]}))
    assert not bad.ok


def test_missing_days_filled_and_reported_and_absent_optional_columns_disable_features():
    d = _df().drop(index=[3, 4])
    rep = validate_sales(d)
    panel, meta, notes = build_panel(aggregate_daily(rep.cleaned))
    assert len(panel) == 10 and any("filled with 0" in n for n in notes)
    spec = FeatureSpec.from_panel(panel)
    assert not spec.use_engagement and not spec.use_price and not spec.use_discount
