import numpy as np
import pandas as pd
import pytest

from src.inventory_engine import (CRITICAL, LOW, OVERSTOCK, SLOW, SUFFICIENT, UNKNOWN, InventoryPolicy, compute_product_inventory,
                                  compute_recommendations, coverage_days, demand_over, inventory_position, safety_stock,
                                  simplified_cover_horizon, z_value, RECOMMENDATION_EXPORT_COLUMNS)

FLAT = np.full(60, 35.0)
P_UNITS = InventoryPolicy(review_period_days=7, safety_method="units", safety_units=30)


def calc(on_hand=120, on_order=0, backorders=0, lead=3, daily=FLAT, policy=P_UNITS, **kw):
    return compute_product_inventory(daily, on_hand, on_order, backorders, lead, kw.pop("std", 0), policy, **kw)


def test_simplified_example_from_brief():
    r = simplified_cover_horizon(120, 245, 30)
    assert r["required_stock"] == 275 and r["additional_stock"] == 155


def test_demand_over_fractional_and_extrapolated():
    assert demand_over([10, 20, 30], 2.5) == (pytest.approx(10 + 20 + 15), False)
    total, extra = demand_over([10] * 7, 10)
    assert total == pytest.approx(100) and extra


def test_lead_time_demand_reorder_point_target_and_order_qty():
    r = calc()
    assert r["lead_time_demand"] == pytest.approx(105)          # 35 x 3
    assert r["review_period_demand"] == pytest.approx(245)      # 35 x 7
    assert r["safety_stock"] == pytest.approx(30)
    assert r["reorder_point"] == pytest.approx(135)             # LTD + SS
    assert r["inventory_position"] == pytest.approx(120)
    assert r["target_stock"] == pytest.approx(380)              # 105 + 245 + 30
    assert r["recommended_order_qty"] == 260                    # 380 - 120


def test_inventory_position_formula_and_backorders():
    assert inventory_position(100, 50, 20) == 130
    assert calc(on_hand=100, on_order=50, backorders=20)["inventory_position"] == 130


def test_order_quantity_is_never_negative():
    for oh in (0, 50, 500, 5000, 10 ** 6):
        assert calc(on_hand=oh)["recommended_order_qty"] >= 0
    assert calc(on_hand=10 ** 6)["recommended_order_qty"] == 0


def test_on_order_not_double_counted():
    a, b = calc(on_hand=50, on_order=0), calc(on_hand=50, on_order=100)
    assert b["inventory_position"] == a["inventory_position"] + 100
    assert a["recommended_order_qty"] - b["recommended_order_qty"] == pytest.approx(100)   # exactly once
    assert a["coverage_days_on_hand"] == b["coverage_days_on_hand"]                          # on-hand cover ignores on-order
    assert b["target_stock"] == a["target_stock"]


def test_missing_inventory_information_is_flagged_not_invented():
    r = calc(on_hand=None)
    assert r["risk_level"] == UNKNOWN and np.isnan(r["recommended_order_qty"])
    r2 = compute_product_inventory(FLAT, 100, None, None, None, None, P_UNITS)
    assert r2["lead_time_days"] == P_UNITS.default_lead_time_days
    assert r2["on_order"] == 0 and len(r2["assumptions"]) == 4


def test_safety_stock_statistical_formula():
    pol = InventoryPolicy(service_level=0.95, safety_method="statistical")
    ss, _ = safety_stock(pol, avg_daily=10, sigma_daily=5, lead_time=4, lead_time_std=0, review_period=6)
    assert z_value(0.95) == pytest.approx(1.6449, abs=1e-3)
    assert ss == pytest.approx(1.6449 * np.sqrt(10 * 25), rel=1e-3)
    ss2, _ = safety_stock(pol, 10, 5, 4, 2, 6)
    assert ss2 == pytest.approx(1.6449 * np.sqrt(10 * 25 + 100 * 4), rel=1e-3)     # lead-time variability adds risk
    ss3, _ = safety_stock(InventoryPolicy(service_level=0.99), 10, 5, 4, 0, 6)
    assert ss3 > ss                                                                 # higher service level -> more stock


def test_safety_stock_days_and_units_methods():
    assert safety_stock(InventoryPolicy(safety_method="days", safety_days=3), 10, None, 5, 0, 7)[0] == 30
    assert safety_stock(InventoryPolicy(safety_method="units", safety_units=42), 10, None, 5, 0, 7)[0] == 42
    s, note = safety_stock(InventoryPolicy(), 10, None, 5, 0, 7)       # statistical but no error stats -> labelled fallback
    assert s == 30 and "fell back" in note


def test_longer_lead_time_raises_reorder_point_and_order_quantity():
    a, b = calc(lead=3), calc(lead=10)
    assert b["lead_time_demand"] > a["lead_time_demand"] and b["reorder_point"] > a["reorder_point"]
    assert b["recommended_order_qty"] >= a["recommended_order_qty"]


def test_classification_rules():
    assert calc(on_hand=20, lead=3)["risk_level"] == CRITICAL                        # position < lead-time demand
    assert calc(on_hand=120, lead=3)["risk_level"] == LOW                            # 105 <= 120 < ROP 135
    assert calc(on_hand=300, lead=3)["risk_level"] == SUFFICIENT
    assert calc(on_hand=20000, lead=3)["risk_level"] == OVERSTOCK
    slow = compute_product_inventory(np.full(60, 0.5), 400, 0, 0, 5, 0, InventoryPolicy(safety_method="units", safety_units=2))
    assert slow["risk_level"] == SLOW


def test_not_overstock_just_because_stock_exceeds_next_week_demand():
    # stock = 2x next-week demand (490 vs 245) but supplier lead time is 14 days -> must not be called overstock
    r = calc(on_hand=490, lead=14)
    assert r["risk_level"] != OVERSTOCK


def test_coverage_days():
    assert coverage_days([10, 10, 10], 25) == pytest.approx(2.5)
    assert coverage_days([10, 10, 10], 0) == 0
    assert coverage_days([0, 0, 0], 50) == 365.0


def test_explanation_contains_the_figures_used():
    r = calc()
    for token in ("120", "105", "135", "380", "260"):
        assert token in r["explanation"]


def test_recommendations_table_sorted_by_risk_and_exportable():
    fcst = pd.concat([pd.DataFrame({"product_id": p, "date": pd.date_range("2025-01-01", periods=30), "forecast": 20.0}) for p in "ABC"])
    inv = pd.DataFrame({"product_id": list("ABC"), "on_hand": [10, 5000, 300], "on_order": [0, 0, 0], "lead_time_days": [5, 5, 5]})
    rec = compute_recommendations(fcst, inv, P_UNITS, names={"A": "Alpha"}, auto_slow_threshold=False)
    assert rec.iloc[0]["product_id"] == "A" and rec.iloc[0]["risk_level"] == CRITICAL
    assert set(RECOMMENDATION_EXPORT_COLUMNS).issubset(rec.columns)
    assert "product_id" in rec.to_csv(index=False)
