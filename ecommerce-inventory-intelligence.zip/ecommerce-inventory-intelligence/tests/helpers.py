"""Shared, cached test fixtures (plain functions so tests need no pytest plugins)."""
from functools import lru_cache

import config
from src.data_loader import generate_synthetic_data
from src.data_validation import validate_inventory, validate_sales
from src.model_evaluation import train_and_evaluate
from src.pipeline import build_context


@lru_cache(maxsize=1)
def small_raw():
    return generate_synthetic_data(seed=7, n_products=12, start="2024-01-01", end="2025-06-30")


@lru_cache(maxsize=1)
def small_ctx():
    sales, inv = small_raw()
    rep = validate_sales(sales)
    inv_rep = validate_inventory(inv)
    return build_context(rep.cleaned, inv_rep.cleaned, "test", "test data", True, rep.info, persist=False)


@lru_cache(maxsize=1)
def small_bundle():
    ctx = small_ctx()
    b = train_and_evaluate(ctx.panel, ctx.meta, "test")
    b["fingerprint"] = ctx.fingerprint
    return b
