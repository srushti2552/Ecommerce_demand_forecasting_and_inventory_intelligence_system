from dataclasses import replace

import numpy as np
import pytest

from src import forecasting as fc
from src.inventory_engine import InventoryPolicy, compute_product_inventory
from src.pipeline import hist_std_map, resid_std_map
from src.simulator import baseline_forecast, promo_support, run_scenario, scenario_from_inventory
from tests.helpers import small_bundle, small_ctx

POL = InventoryPolicy()


def setup():
    ctx, b = small_ctx(), small_bundle()
    pid = ctx.forecastable_products[0]
    orig = scenario_from_inventory(ctx, pid, POL)
    base = baseline_forecast(ctx, b, fc.HGB, pid)
    return ctx, b, pid, orig, base


def test_identical_scenario_gives_no_change():
    ctx, b, pid, orig, base = setup()
    r = run_scenario(ctx, b, fc.HGB, POL, orig, replace(orig), base)
    assert (r.diff["Change"].replace("-", 0).astype(float) == 0).all()
    np.testing.assert_allclose(r.baseline_daily, r.scenario_daily)


def test_longer_lead_time_recalculates_inventory_decision():
    ctx, b, pid, orig, base = setup()
    r = run_scenario(ctx, b, fc.HGB, POL, orig, replace(orig, lead_time_days=orig.lead_time_days + 7), base)
    assert r.revised["lead_time_demand"] > r.original["lead_time_demand"]
    assert r.revised["reorder_point"] > r.original["reorder_point"]
    assert r.revised["recommended_order_qty"] >= r.original["recommended_order_qty"]
    assert any("Lead time changed" in n for n in r.narrative)


def test_more_stock_reduces_order_quantity():
    ctx, b, pid, orig, base = setup()
    lo = run_scenario(ctx, b, fc.HGB, POL, orig, replace(orig, on_hand=0), base)
    hi = run_scenario(ctx, b, fc.HGB, POL, orig, replace(orig, on_hand=5000), base)
    assert lo.revised["recommended_order_qty"] > hi.revised["recommended_order_qty"] == 0


def test_simulator_uses_real_engine_not_hardcoded_values():
    ctx, b, pid, orig, base = setup()
    sc = replace(orig, lead_time_days=12, on_hand=77)
    r = run_scenario(ctx, b, fc.HGB, POL, orig, sc, base)
    direct = compute_product_inventory(base["forecast"].to_numpy(), 77, sc.on_order, sc.backorders, 12, sc.lead_time_std_days,
                                       replace(POL, review_period_days=sc.review_period_days), resid_std_map(b, fc.HGB).get(pid),
                                       hist_std_map(ctx.panel).get(pid), ctx.names[pid], ctx.last_date + __import__("pandas").Timedelta(days=1))
    assert r.revised["recommended_order_qty"] == direct["recommended_order_qty"]
    assert r.revised["reorder_point"] == pytest.approx(direct["reorder_point"])


def test_discount_scenario_uses_model_and_is_labelled():
    ctx, b, pid, orig, base = setup()
    assert promo_support(ctx, b, fc.HGB, pid)["supported"]
    r = run_scenario(ctx, b, fc.HGB, POL, orig, replace(orig, discount_pct=30, promo_days=7), base)
    assert not np.allclose(r.baseline_daily, r.scenario_daily)
    assert "model-predicted response" in r.forecast_source
    assert np.isfinite(r.scenario_daily).all() and (r.scenario_daily >= 0).all()


def test_unsupported_promotion_falls_back_with_clear_message():
    ctx, b, pid, orig, base = setup()
    assert not promo_support(ctx, b, fc.NAIVE, pid)["supported"]
    nb = baseline_forecast(ctx, b, fc.NAIVE, pid)
    r = run_scenario(ctx, b, fc.NAIVE, POL, orig, replace(orig, discount_pct=30), nb)
    np.testing.assert_allclose(r.baseline_daily, r.scenario_daily)          # NOT silently inflated
    assert any("NOT applied" in n for n in r.narrative)


def test_manual_adjustment_is_exact_and_labelled_as_assumption():
    ctx, b, pid, orig, base = setup()
    r = run_scenario(ctx, b, fc.HGB, POL, orig, replace(orig, demand_adjust_pct=25), base)
    np.testing.assert_allclose(r.scenario_daily, r.baseline_daily * 1.25)
    assert "USER ASSUMPTION" in r.forecast_source


def test_scenario_persistence(tmp_path=None):
    import tempfile
    from pathlib import Path
    from src import database as db
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.db"
        sid = db.save_scenario("k", "P1", "demo", {"lead": 10}, {"qty": 5}, db_path=p)
        df = db.list_scenarios("k", db_path=p)
        assert sid == 1 and df.iloc[0]["name"] == "demo"
