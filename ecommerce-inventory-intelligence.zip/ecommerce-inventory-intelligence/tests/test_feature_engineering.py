import numpy as np
import pandas as pd
import pytest

import config
from src.data_loader import generate_synthetic_data
from src.feature_engineering import WideData
from src.model_evaluation import choose_split, chronological_split
from tests.helpers import small_ctx


def test_lag_and_rolling_features_use_only_past_values():
    ctx = small_ctx()
    w, spec = ctx.wide, ctx.spec
    t = 200
    f = w.features_at(t, spec)
    i = int(np.where(np.isfinite(w.U[:, t - 28:t + 1]).all(axis=1))[0][0])
    assert f["lag_1"][i] == w.U[i, t - 1]
    assert f["lag_7"][i] == w.U[i, t - 7]
    assert f["lag_28"][i] == w.U[i, t - 28]
    assert f["roll_mean_7"][i] == pytest.approx(w.U[i, t - 7:t].mean())   # window ends at t-1, excludes today
    assert f["roll_std_14"][i] == pytest.approx(w.U[i, t - 14:t].std())


def test_features_do_not_change_when_today_or_future_sales_change():
    """Core leakage test: corrupt every sales/engagement value at or after t and the features for t must not move."""
    ctx = small_ctx()
    w = ctx.wide.copy()
    t = 300
    before = w.features_at(t, ctx.spec)
    w.U[:, t:] = 1e9
    w.V[:, t:] = 1e9
    w.C[:, t:] = 1e9
    after = w.features_at(t, ctx.spec)
    for k, v in before.items():
        if k == "category":
            continue
        np.testing.assert_array_equal(np.asarray(v, float), np.asarray(after[k], float), err_msg=k)


def test_target_is_never_a_feature():
    ctx = small_ctx()
    assert "units_sold" not in ctx.spec.all_columns()
    assert "on_hand" not in ctx.spec.all_columns()          # stock is censored by availability, so excluded


def test_training_frame_matches_online_feature_builder():
    ctx = small_ctx()
    tf = ctx.wide.training_frame(ctx.spec, t_start=250, t_end=260)
    t = int(tf["t_index"].iloc[0])
    online = ctx.wide.feature_frame_at(t, ctx.spec).set_index("product_id")
    row = tf[tf["t_index"] == t].set_index("product_id")
    common = row.index.intersection(online.index)
    for c in ["lag_1", "lag_7", "roll_mean_28", "growth_7_28", "views_mean_7"]:
        np.testing.assert_allclose(row.loc[common, c].astype(float), online.loc[common, c].astype(float))
    # target of the previous day equals this day's lag_1 for the same product
    prev = tf[tf["t_index"] == t - 1].set_index("product_id") if t - 1 in set(tf["t_index"]) else None
    if prev is not None:
        c2 = row.index.intersection(prev.index)
        np.testing.assert_allclose(row.loc[c2, "lag_1"].astype(float), prev.loc[c2, "units_sold"].astype(float))


def test_future_covariates_are_assumptions_not_actuals():
    ctx = small_ctx()
    w = ctx.wide
    o = w.n_days - 20
    fut = w.truncated_with_future(o, 10)
    assert np.isnan(fut.U[:, o:]).all()                       # actual sales after origin are physically removed
    assert (fut.disc[:, o:] == 0).all() and (fut.promo[:, o:] == 0).all()   # default assumption: no promotion


def test_chronological_split_has_no_overlap_and_no_shuffle():
    ctx = small_ctx()
    s = choose_split(ctx.wide.n_days)
    tf = ctx.wide.training_frame(ctx.spec)
    vs, ts = ctx.wide.dates[s["val_start"]], ctx.wide.dates[s["test_start"]]
    train, val, test = chronological_split(tf, vs, ts)
    assert train["date"].max() < val["date"].min() <= val["date"].max() < test["date"].min()
    assert len(train) + len(val) + len(test) == len(tf)
    assert tf["date"].is_monotonic_increasing                   # rows are in time order, never shuffled


def test_split_refuses_short_history():
    with pytest.raises(ValueError):
        choose_split(60)


def test_generator_is_reproducible_and_exposes_no_hidden_parameters():
    a, _ = generate_synthetic_data(seed=3, n_products=4, start="2024-01-01", end="2024-06-30")
    b, _ = generate_synthetic_data(seed=3, n_products=4, start="2024-01-01", end="2024-06-30")
    assert a.equals(b)
    hidden = {"base_demand", "growth", "beta", "elasticity", "season", "mu", "demand"}
    assert hidden.isdisjoint(a.columns)
