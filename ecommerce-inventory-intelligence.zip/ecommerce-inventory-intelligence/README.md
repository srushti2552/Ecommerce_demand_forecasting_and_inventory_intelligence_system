# E-Commerce Demand Forecasting & Inventory Intelligence

An end-to-end Data Science / Machine Learning application that forecasts product demand, detects inventory risk, recommends
replenishment quantities with a transparent explanation, flags unusual demand, groups products by sales behaviour and lets you
run what-if scenarios. Runs fully locally (pandas, scikit-learn, Plotly, Streamlit, SQLite) - no paid APIs, no internet needed.

> **Demo data notice.** The built-in dataset is *synthetic demonstration data*. Every metric shown on it describes how the
> methods behave on generated data, **not** real business performance. The UI labels it clearly.

## 1. Project overview
Raw sales (+ optional inventory) -> validation -> EDA -> leakage-safe feature engineering -> model comparison on chronological
splits -> recursive 7/30-day forecasts -> inventory engine (lead-time demand, safety stock, reorder point, order quantity, risk class)
-> explainable recommendations -> simulator, anomaly monitoring, clustering and engagement analytics in a 7-page dashboard.

## 2. Problem statement
Stock-outs lose sales; overstock ties up cash. Decisions need (a) a demand forecast, (b) a replenishment policy that accounts for
supplier lead time and stock already on order, and (c) an explanation a planner can verify.

## 3. Objectives
Answer: which products are rising/falling; 7- and 30-day demand; which may stock out before replenishment arrives; how much to order
and when; which are overstocked/slow; which show unusual demand; how promotions/price/seasonality relate to demand; which products
behave alike; how changes in stock, lead time and demand assumptions change the decision.

## 4. Unique contributions
1. **Explainable restocking**: every recommendation prints the figures and formulas behind it.
2. **Simulator on real code**: sliders call the real forecasting + inventory functions; model predictions, user assumptions and
   calculations are labelled separately.
3. **Anomaly detection** (Isolation Forest + robust z-score) with *hypotheses* and stock-impact analysis, plus an investigation workflow stored in SQLite.
4. **Data-driven clustering** (K-Means, k by silhouette, labels derived from cluster statistics) linked to inventory policy ideas.
5. **Leakage prevention by construction** and unit tests proving it.

## 5. Architecture
```
app.py / pages/*.py      Streamlit UI only (no business logic)
src/app_context.py       session state, caching, sidebar policy controls
src/pipeline.py          orchestration: dataset context -> bundle -> forecasts -> recommendations
src/data_loader.py       synthetic generator, CSV reading        src/data_validation.py  mapping + validation reports
src/preprocessing.py     daily panel, inventory snapshot         src/eda.py              EDA tables + interpretations
src/feature_engineering.py  WideData + FeatureSpec (leak-safe)   src/forecasting.py      models, recursive forecast, persistence
src/model_evaluation.py  metrics, splits, backtests, training    src/inventory_engine.py pure inventory maths + classification
src/anomaly_detection.py / product_clustering.py / customer_analytics.py
src/simulator.py         what-if engine                          src/database.py         SQLite persistence
src/visualizations.py    Plotly figures
```

## 6. Technology stack
Python, pandas, NumPy, scikit-learn, Plotly, Streamlit, SQLite (`sqlite3`), Joblib, pytest, matplotlib (installed, Plotly used for charts).

## 7. Dataset schema
Required: `date`, `product_id`, `units_sold`. Optional: `product_name, category, unit_price, discount_pct, promotion, rating, views,
add_to_cart, on_hand, lead_time_days, unit_cost, launch_date, customer_id`.
Inventory file (optional): `product_id, on_hand` required; `on_order, backorders, lead_time_days, lead_time_std_days, unit_cost` optional.
`unit_price` is the *list* price; net revenue = units x price x (1 - discount/100). Synthetic data: 40 products, 5 categories,
2023-10-01 to 2026-09-30, generated with seed 42; hidden generator parameters are never exposed.

## 8. Data preparation
Rows with invalid dates, missing product IDs, non-numeric or negative units are **removed and counted** (never zero-filled).
Exact duplicates are dropped; rows sharing (date, product) are aggregated (units summed; views/cart = max). Missing calendar days
between a product's first and last date are treated as **zero sales** (reported - assumption: no row = no sale). Products with no row
in the last 28 days are inactive and not forecast. Absent optional fields disable only the analytics that need them.

## 9. Feature engineering
Calendar (day-of-week, month, week-of-year, weekend), lags 1/7/14/28, rolling mean/std 7/14/28 (windows end at t-1), recent growth,
product age, list price & price ratio, discount, promotion flag, lagged engagement (7-day view mean, cart rate, conversion), category.
**Leakage rules:** history features read only columns `< t`; same-day views/cart are never used; on-hand stock is not a feature
(it is censored by availability). Training and forecasting use the *same* function, so they cannot drift.
Future price/discount/promotion are assumptions: price held, discount 0, promotion off, engagement held at its 7-day mean - unless
you supply planned values in the simulator.

## 10. ML models
1. Seasonal Naive (demand = same weekday last week) - baseline
2. Ridge Regression (scaled, one-hot calendar/category)
3. Random Forest Regressor
4. HistGradientBoostingRegressor
All are scikit-learn estimators/pipelines. Nothing assumes the complex models win - the table decides.

## 11. Evaluation methodology
Chronological **train / validation / test** (last 30 days = test, previous 56 = validation; shrunk automatically for short histories,
refused below 120 days). Every score is a **rolling-origin, recursive** evaluation: 7-day forecasts issued every 7 days using only
data before each origin. Models are fitted on train -> scored on validation -> **winner chosen on validation only** -> re-fitted on
train+validation -> scored once on the untouched test window (reported, never used to choose) -> finally re-fitted on all data for
deployment. Metrics: MAE, RMSE, WAPE (= total |error| / total actual), MAPE (only where actual >= 1). No shuffling anywhere.
Estimated ranges around forecasts come from past backtest residual quantiles and are labelled *estimates*, not confidence intervals.

## 12. Inventory formulas
```
Lead-Time Demand (LTD) = sum of forecast demand over lead time L
Safety Stock (statistical) = z(service level) * sqrt( P * sigma_d^2 + d_avg^2 * sigma_L^2 ),  P = L + R
   (or 'days of demand' / 'fixed units' - labelled policy assumptions)
Reorder Point = LTD + Safety Stock
Inventory Position = On-hand + On-order - Backorders
Target Stock = LTD + review-period demand (days L..L+R) + Safety Stock
Order Quantity = max(0, ceil(Target Stock - Inventory Position))
```
sigma_d is the per-day forecast-error std from backtests (fallback: historical std, labelled). On-order stock is counted once, inside
the position; its arrival dates are not modelled. Classes (first match): **Critical** (position < LTD, or on-hand cover < 3 days),
**Low** (position < ROP), **Slow-Moving** (forecast below a portfolio percentile *and* long cover), **Potential Overstock**
(position > 2x target *and* cover well beyond lead+review), else **Sufficient**. All thresholds are editable in the sidebar.
Overstock is never decided from "stock > next week's demand" alone. Missing on-hand -> "Unknown"; missing lead time -> policy default, flagged.

## 13. Anomaly detection
Point-in-time features (ratio to trailing 28-day mean, robust z-score vs trailing median/MAD, ratio to last week, 7/28-day volatility ratio)
-> Isolation Forest; a day is flagged only if the forest **and** the robust z-score agree (stricter threshold for spikes than drops).
Output includes reference level, score, promotion overlap, hypotheses and inventory impact. Scores are rankings, not probabilities.

## 14. Clustering
K-Means on scaled (log-transformed where skewed) average demand, variability, revenue, 28-day growth, turnover, conversion (when available).
k is chosen by silhouette (overridable). Profile names (High-Demand, Stable, High-Variability, Slow-Moving) come from cluster statistics.

## 15. Forecast simulator
Page 6. Inputs: stock, lead time (+variability), review period, safety stock method, planned discount/promotion + duration, manual demand
adjustment. A discount re-runs the **trained model** with the planned discount as a known input (only if the model can use it and the
product has >= 10 promotion days; otherwise a clear message and manual adjustment only). Manual % is always labelled a user assumption.

## 16. Installation
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
## 17. Running the application
```bash
streamlit run app.py
```
First launch generates the sample data and trains models (~30-60 s, progress bar). To pre-train:
`python scripts/generate_sample_data.py` then `python scripts/train_models.py`.

## 18. Uploading custom datasets
Page 7 -> *Upload CSV*: preview, auto/manual column mapping, validation messages, optional inventory file, then *Use this dataset*.
Or from the CLI: `python scripts/train_models.py --sales my_sales.csv --inventory my_stock.csv`.

## 19. Running tests
```bash
pytest -q
```
Covers validation, CSV upload, feature engineering, leakage, chronological splits, recursive forecasting, non-negativity, inventory
maths (LTD, ROP, position, safety stock, order quantity, on-order handling, missing data), simulator recalculation, anomalies,
clustering, customer analytics, EDA filters and SQLite persistence.

## 20. Persistence
SQLite `data/app.db`: datasets, products, inventory snapshots (editable on page 7), model runs & metrics, forecast runs, recommendations,
anomalies + investigation status, scenarios. Large sales tables stay as `data/*.csv.gz`; models in `models/*.joblib` (+ `.json` summary).
*Reset sample dataset* is on page 7.

## 21. Limitations
- Synthetic demo data is easier/cleaner than reality; real results will differ.
- Recursive 30-day forecasts accumulate error; the estimated range is empirical, not a formal prediction interval.
- Observed sales are censored by stock-outs (sales <= stock); the model forecasts *observed sales*, not true unconstrained demand.
- Safety stock treats daily errors as independent; recursive errors are positively correlated, so it can be optimistic.
- Open purchase-order arrival dates and supplier MOQ/pack sizes are not modelled; single-echelon, single-location stock.
- "Cart abandonment" and "purchase rate" are product-level proxies (units, not orders). Customer analytics need a real `customer_id`.
- Promotion effects are *associations learned from history*, not proven causal effects.
- No cross-product (substitution/cannibalisation) effects, no holiday calendar beyond what month/week features capture.

## 22. Future enhancements
Holiday/event calendars, hierarchical forecasting, quantile/probabilistic models, PO-level arrival schedules, MOQ/lot sizing and
cost-optimal service levels, stock-out-aware demand un-censoring, multi-location stock, automated retraining and drift monitoring.
