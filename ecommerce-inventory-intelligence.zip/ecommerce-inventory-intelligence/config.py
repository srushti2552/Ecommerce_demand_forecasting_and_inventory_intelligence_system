"""Central configuration for the E-Commerce Demand Forecasting & Inventory Intelligence project.

All paths are resolved relative to the project root (the folder that contains this file),
so the app works regardless of the directory it is launched from.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MODELS_DIR = ROOT / "models"
DB_PATH = DATA_DIR / "app.db"
SAMPLE_SALES_PATH = DATA_DIR / "sample_sales.csv.gz"
SAMPLE_INVENTORY_PATH = DATA_DIR / "sample_inventory.csv"

RANDOM_SEED = 42

# ---- Synthetic demonstration data -------------------------------------------------
SYNTH_START = "2023-10-01"
SYNTH_END = "2026-09-30"
SYNTH_N_PRODUCTS = 40
DEMO_LABEL = "SYNTHETIC DEMONSTRATION DATA - not real business results"

# ---- Feature engineering ----------------------------------------------------------
LAGS = (1, 7, 14, 28)
ROLLING_WINDOWS = (7, 14, 28)
MIN_HISTORY_DAYS = 28          # a product needs this many prior days to get lag/rolling features
INACTIVE_AFTER_DAYS = 28       # product with no row in the last N days is treated as inactive

# ---- Model training / evaluation --------------------------------------------------
TEST_DAYS = 30                 # final chronological hold-out (never used for selection)
VAL_DAYS = 56                  # chronological validation window (used for model selection)
BACKTEST_HORIZON = 7           # horizon of each rolling-origin forecast
BACKTEST_STEP = 7              # days between rolling origins
MIN_TOTAL_DAYS_TO_TRAIN = 120
FORECAST_HORIZONS = (7, 30)
MAX_FORECAST_HORIZON = 60

# ---- Inventory policy defaults ----------------------------------------------------
DEFAULT_LEAD_TIME_DAYS = 7
DEFAULT_REVIEW_PERIOD_DAYS = 7
DEFAULT_SERVICE_LEVEL = 0.95
DEFAULT_SAFETY_DAYS = 3.0
CRITICAL_COVER_DAYS = 3.0
OVERSTOCK_EXTRA_COVER_DAYS = 45.0
OVERSTOCK_TARGET_MULTIPLE = 2.0
SLOW_MOVING_PERCENTILE = 20

RISK_ORDER = ["Critical Stock Risk", "Low Stock", "Potential Overstock", "Slow-Moving", "Sufficient Inventory"]

# ---- Anomaly detection ------------------------------------------------------------
ANOMALY_CONTAMINATION = 0.02
ANOMALY_MIN_DAILY_REFERENCE = 3.0   # ignore tiny-volume noise when flagging
