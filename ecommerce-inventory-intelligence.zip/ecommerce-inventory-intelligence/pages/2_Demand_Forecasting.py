import pandas as pd
import streamlit as st

from src import app_context as ac
from src import forecasting as fc
from src import model_evaluation as me
from src import visualizations as viz

ctx, bundle, policy = ac.setup_page("Demand Forecasting", "Recursive multi-step forecasts from models compared on chronological validation")

names = ctx.names
options = ctx.forecastable_products
if not options:
    st.warning("No product has enough recent history to forecast.")
    st.stop()
default = [p for p in options if names.get(p) == "Wireless Earbuds"] or options[:1]
c1, c2, c3 = st.columns([3, 2, 1])
sel = c1.multiselect("Products", options, default=default, format_func=lambda p: f"{names.get(p, p)} ({p})")
model = c2.selectbox("Model", fc.MODEL_NAMES, index=fc.MODEL_NAMES.index(bundle["selected"]),
                     help="Default is the model with the best validation WAPE.")
horizon = c3.radio("Horizon", [7, 30], horizontal=True)
if not sel:
    st.info("Select at least one product.")
    st.stop()

fcst = ac.get_forecast(ctx, bundle, model, horizon, sel)
if fcst.empty:
    st.warning("The selected products have no forecast (inactive or too little history).")
    st.stop()
row = bundle["comparison"].set_index("model").loc[model]

tab1, tab2, tab3 = st.tabs(["Forecast", "Model comparison", "Held-out actual vs predicted"])
with tab1:
    rows = []
    for p in sel:
        f = fcst[fcst["product_id"] == p]
        if f.empty:
            continue
        h = ctx.panel[ctx.panel["product_id"] == p].sort_values("date")
        last7, prev7 = h["units_sold"].tail(7).sum(), h["units_sold"].iloc[-14:-7].sum()
        rows.append({"Product": names.get(p, p), "Forecast total": f["forecast"].sum(), "Avg per day": f["forecast"].mean(),
                     "Last 7 days actual": last7, "Recent trend (7d vs prior 7d)": (last7 / prev7 - 1) if prev7 > 0 else float("nan")})
    summ = pd.DataFrame(rows)
    m = st.columns(4)
    m[0].metric(f"Total forecast ({horizon} d, selected)", ac.fmt_num(fcst["forecast"].sum()))
    m[1].metric("Model", model.split(" (")[0])
    m[2].metric("Validation WAPE", f"{row['WAPE_val']:.1%}", help=me.METRIC_HELP["WAPE"])
    m[3].metric("Test WAPE (held-out)", f"{row['WAPE_test']:.1%}", help="Measured on a final window never used for fitting or selection.")
    show = summ.copy()
    show["Recent trend (7d vs prior 7d)"] = show["Recent trend (7d vs prior 7d)"].map(lambda v: "n/a" if pd.isna(v) else f"{v:+.0%}")
    ac.show_df(show.round(1))
    for p in sel:
        f = fcst[fcst["product_id"] == p]
        if f.empty:
            continue
        hist = ctx.panel[ctx.panel["product_id"] == p][["date", "units_sold"]]
        ac.show_plot(viz.forecast_chart(hist, f, f"{names.get(p, p)} - {horizon}-day forecast", 90), key=f"fc_{p}")
    if horizon == 30:
        st.caption("30-day forecasts compound errors through the recursion and are less reliable than 7-day forecasts.")
    st.caption("The shaded band is an **estimate** from the spread of past backtest errors for this product - not a guaranteed confidence interval.")
    with st.expander("Forecast assumptions"):
        for a in fc.ASSUMPTIONS:
            st.markdown(f"- {a}")
    st.download_button("Download forecast CSV", fcst.to_csv(index=False).encode(), "forecast.csv", "text/csv")

with tab2:
    comp = bundle["comparison"]
    ac.show_plot(viz.model_comparison_bar(comp))
    show = comp[["model", "MAE_val", "RMSE_val", "WAPE_val", "MAPE_val", "MAE_test", "RMSE_test", "WAPE_test", "selected"]].copy()
    show.columns = ["Model", "MAE (val)", "RMSE (val)", "WAPE (val)", "MAPE (val)", "MAE (test)", "RMSE (test)", "WAPE (test)", "Selected"]
    ac.show_df(show.round(3))
    sp = bundle["split"]
    st.caption(f"Selection used VALIDATION only ({sp['val_start']} to {sp['test_start']}). TEST window starts {sp['test_start']} and was "
               f"never used for choosing. Each score is the pooled error of {sp['backtest_horizon']}-day recursive forecasts issued every 7 days.")
    best, naive = comp[comp["selected"]].iloc[0], comp[comp["model"] == fc.NAIVE].iloc[0]
    st.markdown(f"On this dataset the selected model's validation WAPE is **{best['WAPE_val']:.1%}** versus **{naive['WAPE_val']:.1%}** "
                f"for the seasonal-naive baseline (measured, not assumed).")
    with st.expander("What do the metrics mean?"):
        for k, v in me.METRIC_HELP.items():
            st.markdown(f"**{k}** - {v}")
    for n in bundle.get("notes", []):
        st.info(n)

with tab3:
    st.caption("These are HISTORICAL predictions on the held-out test window (7-day forecasts issued at weekly origins). They are not future forecasts.")
    tp = bundle["test_predictions"]
    mm = st.selectbox("Model for held-out view", fc.MODEL_NAMES, index=fc.MODEL_NAMES.index(model), key="ho_model")
    pid = st.selectbox("Product", options, format_func=lambda p: names.get(p, p), key="ho_prod")
    d = tp[(tp["model"] == mm) & (tp["product_id"] == pid)]
    if d.empty:
        st.info("No held-out predictions for this product (it may have launched too recently).")
    else:
        ac.show_plot(viz.actual_vs_pred_chart(d, f"{names.get(pid, pid)} - actual vs {mm} on the test window"))
        st.caption(f"Product-level WAPE on test window: {me.wape(d['actual'], d['pred']):.1%} | MAE: {me.mae(d['actual'], d['pred']):.2f} units/day")
