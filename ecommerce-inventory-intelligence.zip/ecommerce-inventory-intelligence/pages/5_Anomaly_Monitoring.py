import pandas as pd
import streamlit as st

import config
from src import app_context as ac
from src import database as db
from src import visualizations as viz
from src.anomaly_detection import inventory_impact

ctx, bundle, policy = ac.setup_page("Anomaly Monitoring", "Unusual demand versus each product's own recent history", need_model=False)

c1, c2 = st.columns([2, 3])
cont = c1.slider("Sensitivity (expected share of unusual days)", 0.005, 0.05, config.ANOMALY_CONTAMINATION, 0.005, format="%.3f",
                 help="Isolation Forest contamination. Higher = more days flagged.")
an = ac.get_anomalies(ctx, cont)
if an.empty:
    st.info("No anomalies found (or not enough history: at least ~200 usable product-days are needed).")
    st.stop()

status = db.load_anomaly_status(ctx.key)
an = an.merge(status, on=["product_id", "date"], how="left")
an["status"] = an["status"].fillna("New")

f = st.columns(5)
cats = f[0].multiselect("Category", sorted(an["category"].unique()))
direction = f[1].multiselect("Type", ["Spike", "Drop"], default=["Spike", "Drop"])
excl = f[2].checkbox("Hide promotion-related", value=False, help="Spikes that coincide with a promotion/discount are often expected lift.")
stat_sel = f[3].multiselect("Status", ["New", "Investigating", "Resolved", "Dismissed"], default=["New", "Investigating"])
last_days = f[4].number_input("Only last N days (0 = all)", 0, 3000, 0)
v = an.copy()
if cats:
    v = v[v["category"].isin(cats)]
if direction:
    v = v[v["direction"].isin(direction)]
if excl and "promo_related" in v:
    v = v[~v["promo_related"]]
if stat_sel:
    v = v[v["status"].isin(stat_sel)]
if last_days:
    v = v[v["date"] > ctx.last_date - pd.Timedelta(days=int(last_days))]
if v.empty:
    st.info("No anomalies match the filters.")
    st.stop()

m = st.columns(3)
m[0].metric("Anomalies shown", len(v))
m[1].metric("Spikes / drops", f"{(v['direction'] == 'Spike').sum()} / {(v['direction'] == 'Drop').sum()}")
m[2].metric("Promotion-related", int(v["promo_related"].sum()) if "promo_related" in v else "n/a")
st.caption("Anomaly scores rank how unusual a day is; they are NOT probabilities and do not say demand will continue. "
           "Explanations are hypotheses to investigate.")
show = v[["product_name", "date", "direction", "units_sold", "reference_level", "z_robust", "anomaly_score", "promo_related", "status"]].copy()
show["date"] = show["date"].dt.date
ac.show_df(show.round(2))

st.subheader("Investigate")
labels = [f"{r.product_name} | {r.date:%Y-%m-%d} | {r.direction}" for r in v.itertuples()]
choice = st.selectbox("Anomaly", range(len(labels)), format_func=lambda i: labels[i])
row = v.iloc[choice]
pid = row["product_id"]
series = ctx.panel[ctx.panel["product_id"] == pid][["date", "units_sold"]]
win = series[series["date"] >= row["date"] - pd.Timedelta(days=120)]
win = win[win["date"] <= row["date"] + pd.Timedelta(days=60)]
ac.show_plot(viz.anomaly_chart(win, an[(an["product_id"] == pid) & an["date"].between(win["date"].min(), win["date"].max())],
                               f"{row['product_name']} - context around {row['date']:%d %b %Y}"))
inv = ctx.inventory[ctx.inventory["product_id"] == pid]
oh = float(inv["on_hand"].iloc[0]) if len(inv) and pd.notna(inv["on_hand"].iloc[0]) else None
lt = float(inv["lead_time_days"].iloc[0]) if len(inv) and pd.notna(inv["lead_time_days"].iloc[0]) else None
imp = inventory_impact(row, oh, lt)
a, b = st.columns(2)
with a:
    st.markdown(f"**Observed:** {row['units_sold']:.0f} units vs reference {row['reference_level']:.1f} (trailing 28-day mean)")
    st.markdown(f"**Possible explanations (hypotheses):** {row['hypotheses']}")
with b:
    st.markdown("**Potential inventory impact**")
    st.write(imp["note"])
    if oh is not None:
        st.caption(f"Current on-hand: {oh:.0f} units" + (f", lead time {lt:g} days" if lt else ""))

s1, s2, s3 = st.columns([2, 3, 1])
new_status = s1.selectbox("Investigation status", ["New", "Investigating", "Resolved", "Dismissed"],
                          index=["New", "Investigating", "Resolved", "Dismissed"].index(row["status"]))
note = s2.text_input("Note", value=row.get("note", "") if isinstance(row.get("note", ""), str) else "")
if s3.button("Save"):
    db.set_anomaly_status(ctx.key, pid, row["date"], new_status, note)
    st.success("Status saved.")
    st.rerun()
if st.button("Save all detected anomalies to database"):
    db.save_anomalies(ctx.key, an)
    st.success(f"{len(an)} anomalies stored in SQLite.")
