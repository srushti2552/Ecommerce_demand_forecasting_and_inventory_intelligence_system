import pandas as pd
import streamlit as st

from src import app_context as ac
from src import customer_analytics as ca
from src import eda
from src import visualizations as viz
from src.product_clustering import policy_note

ctx, bundle, policy = ac.setup_page("Product Analytics", "Exploration, pricing, clustering and engagement", need_model=False)
panel = ctx.panel

tabs = st.tabs(["EDA", "Top & slow products", "Pricing & promotions", "Clusters", "Customer engagement", "Data quality"])

with tabs[0]:
    f1, f2, f3 = st.columns(3)
    cats = f1.multiselect("Category", sorted(panel["category"].unique()))
    pool = panel[panel["category"].isin(cats)] if cats else panel
    names = ctx.names
    prods = f2.multiselect("Product", sorted(pool["product_id"].unique()), format_func=lambda p: names.get(p, p))
    dmin, dmax = panel["date"].min().date(), panel["date"].max().date()
    rng = f3.date_input("Date range", (dmin, dmax), min_value=dmin, max_value=dmax)
    dr = rng if isinstance(rng, (tuple, list)) and len(rng) == 2 else (dmin, dmax)
    sub = eda.filter_panel(panel, prods, cats, dr)
    if sub.empty:
        st.warning("No data for the selected filters.")
    else:
        k = eda.kpis(sub)
        m = st.columns(5)
        m[0].metric("Units sold", ac.fmt_num(k["total_units"]))
        m[1].metric("Revenue", ac.fmt_money(k["total_revenue"]) if k["total_revenue"] is not None else "n/a")
        m[2].metric("Products", k["n_products"])
        m[3].metric("Categories", k["n_categories"])
        m[4].metric("Avg units/day", ac.fmt_num(k["avg_daily_units"], 1))
        freq = st.radio("Trend granularity", ["Daily", "Weekly", "Monthly"], index=1, horizontal=True)
        tr = eda.trend(sub, {"Daily": "D", "Weekly": "W", "Monthly": "M"}[freq])
        ac.show_plot(viz.line_trend(tr, "date", "units", f"{freq} units sold"))
        a, b = st.columns(2)
        with a:
            dow = eda.dow_pattern(sub)
            ac.show_plot(viz.bar(dow, "day", "relative_demand", "Day-of-week demand (1.0 = weekly average)"))
            st.caption(eda.interpret_dow(dow))
        with b:
            seas = eda.monthly_seasonality(sub)
            if seas is None:
                st.info("Seasonality needs at least one year of data in the selected range.")
            else:
                ac.show_plot(viz.bar(seas, "month", "seasonal_index", "Monthly seasonal index (1.0 = average month)"))
                st.caption(eda.interpret_seasonality(seas))
        v = eda.variability_table(sub)
        ac.show_plot(viz.bar(v.head(15), "product_name", "cv", "Most variable products (coefficient of variation)", horizontal=True))
        st.caption(eda.interpret_variability(v))

with tabs[1]:
    n = st.slider("Number of products", 5, 20, 10)
    a, b = st.columns(2)
    top, slow = eda.top_products(panel, n), eda.slow_products(panel, n)
    with a:
        ac.show_plot(viz.bar(top, "product_name", "total_units", "Top-selling products (all history)", horizontal=True))
    with b:
        ac.show_plot(viz.bar(slow, "product_name", "recent_avg_daily", "Slowest products (avg units/day, last 90 days)", horizontal=True))
    ac.show_df(eda.category_sales(panel).round(0))

with tabs[2]:
    rel = eda.discount_relationship(panel)
    if rel is None:
        st.info("Discount analysis needs a discount_pct column with some variation.")
    else:
        ac.show_plot(viz.bar(rel, "discount_band", "avg_relative_demand", "Relative demand by discount band"))
        st.caption(eda.interpret_discount(rel))
    pp = eda.price_demand_points(panel)
    if pp is not None:
        import plotly.express as px
        fig = px.scatter(pp, x="avg_price", y="avg_daily_units", hover_name="product_name", log_x=True, log_y=True)
        fig.update_layout(height=380, template="plotly_white", title="Average price vs average daily units (log scales)")
        ac.show_plot(fig)
        st.caption("Across products, price mostly reflects product type, so this is not a price-elasticity estimate.")

with tabs[3]:
    kk = st.slider("Number of clusters (0 = choose automatically by silhouette)", 0, 6, 0)
    res = ac.get_clusters(ctx, kk)
    if res["products"] is None:
        st.info(res["message"])
    else:
        st.caption(f"k = {res['k']} (silhouette-optimal k = {res['selected_k_by_silhouette']}). Features (scaled): {', '.join(res['features_used'])}.")
        ac.show_plot(viz.cluster_scatter(res["products"]))
        summ = res["summary"].copy()
        summ["inventory policy suggestion"] = summ["profile"].map(policy_note)
        ac.show_df(summ.round(2))
        sel = st.selectbox("Show members of", summ["profile"].tolist())
        ac.show_df(res["products"][res["products"]["profile"] == sel][["product_id", "product_name", "category", "avg_daily_units", "cv", "growth_28d"]].round(2))
        with st.expander("How was k chosen?"):
            ac.show_df(res["k_selection"].round(3))
            st.caption("Higher silhouette = better separated clusters. With real data the best k can differ - it is not fixed.")

with tabs[4]:
    av = ca.engagement_available(panel)
    prod = ca.engagement_by_product(panel)
    if prod is None:
        st.info("Engagement analytics need a 'views' column (and 'add_to_cart' for the cart funnel). They are not available in this dataset, "
                "and nothing has been estimated in their place.")
    else:
        st.caption("Product-level funnel. 'Purchase rate' uses units sold as a proxy for purchases (units, not orders); "
                   "'cart abandonment' is a proxy (1 - units/add-to-cart), not individual customer behaviour.")
        cat = ca.engagement_by_category(panel)
        ac.show_df(cat.round(4))
        ac.show_plot(viz.bar(prod.sort_values("view_to_purchase_rate").head(15), "product_name", "view_to_purchase_rate",
                             "Lowest view-to-purchase rates", horizontal=True))
        ac.show_df(prod.round(4))
    cm = ca.customer_metrics(ctx.transactions)
    if not cm["available"]:
        st.info(cm["message"])
    else:
        c = st.columns(3)
        c[0].metric("Customers", cm["n_customers"])
        c[1].metric("Repeat purchase rate", f"{cm['repeat_rate']:.1%}")
        c[2].metric("Avg orders/customer", f"{cm['avg_orders_per_customer']:.2f}")
        if "segments" in cm:
            ac.show_df(cm["segments"])

with tabs[5]:
    ac.show_df(eda.quality_summary(panel, ctx.validation_info).astype(str))
    for n in ctx.notes:
        st.info(n)
