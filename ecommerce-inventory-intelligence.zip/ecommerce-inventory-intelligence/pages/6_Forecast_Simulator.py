from dataclasses import replace

import pandas as pd
import streamlit as st

from src import app_context as ac
from src import database as db
from src import forecasting as fc
from src import simulator as sim
from src import visualizations as viz

ctx, bundle, policy = ac.setup_page("Forecast Simulator", "Change assumptions and watch the inventory decision recalculate", policy_controls=True)

names = ctx.names
options = ctx.forecastable_products
default = next((i for i, p in enumerate(options) if names.get(p) == "Wireless Earbuds"), 0)
c1, c2 = st.columns([3, 2])
pid = c1.selectbox("Product", options, index=default, format_func=lambda p: f"{names.get(p, p)} ({p})")
model = c2.selectbox("Forecast model", fc.MODEL_NAMES, index=fc.MODEL_NAMES.index(bundle["selected"]))

orig = sim.scenario_from_inventory(ctx, pid, policy)
orig = replace(orig, review_period_days=policy.review_period_days, service_level=policy.service_level)
support = sim.promo_support(ctx, bundle, model, pid)
kp = f"_{pid}_{model}"

st.markdown(ac.tag("user", "blue-orange tags: user-entered assumption") + ac.tag("model", "model prediction") + ac.tag("calc", "calculated"),
            unsafe_allow_html=True)
left, right = st.columns([2, 3])
with left:
    st.subheader("Scenario inputs")
    on_hand = st.number_input("Current stock (units)", 0.0, 1e7, float(orig.on_hand), 10.0, key="sim_oh" + kp)
    lead = st.slider("Supplier lead time (days)", 1, 45, int(round(orig.lead_time_days)), key="sim_lt" + kp)
    lead_sd = st.number_input("Lead-time variability (std, days)", 0.0, 30.0, float(orig.lead_time_std_days), 0.5, key="sim_lsd" + kp)
    review = st.slider("Review period (days)", 0, 30, int(policy.review_period_days), key="sim_rev" + kp)
    st.markdown("**Safety stock allowance**")
    sm = st.radio("Method", ["Use policy setting", "Fixed units", "Days of demand"], horizontal=True, key="sim_sm" + kp)
    s_units = st.number_input("Units", 0.0, 1e6, 30.0, 5.0, key="sim_su" + kp, disabled=sm != "Fixed units")
    s_days = st.number_input("Days", 0.0, 60.0, 3.0, 0.5, key="sim_sd" + kp, disabled=sm != "Days of demand")
    st.markdown("**Demand scenario**")
    if support["supported"]:
        disc = st.slider("Planned discount (%)", 0, 50, 0, key="sim_disc" + kp,
                         help="Supplied to the trained model as a known future input.")
        promo = st.checkbox("Promotion flag on", value=False, key="sim_promo" + kp)
        pdays = st.slider("Promotion duration (days from tomorrow)", 1, 30, 7, key="sim_pd" + kp)
    else:
        disc, promo, pdays = 0, False, 7
        st.info("Model-based promotion scenarios are unavailable here: " + "; ".join(support["reasons"]) + ". Use the manual adjustment.")
    adj = st.slider("Manual demand adjustment (%)", -50, 100, 0, key="sim_adj" + kp,
                    help="Your own assumption applied on top of the forecast. It is NOT a model prediction.")

scen = replace(orig, on_hand=on_hand, lead_time_days=float(lead), lead_time_std_days=lead_sd, review_period_days=float(review),
               safety_method={"Use policy setting": None, "Fixed units": "units", "Days of demand": "days"}[sm],
               safety_units=s_units, safety_days=s_days, discount_pct=float(disc), promotion=bool(promo), promo_days=int(pdays),
               demand_adjust_pct=float(adj))


@st.cache_data(show_spinner=False)
def _baseline(fp, stamp, model_name, product, _ctx, _bundle):
    return sim.baseline_forecast(_ctx, _bundle, model_name, product)


base = _baseline(ctx.fingerprint, bundle["trained_at"], model, pid, ctx, bundle)
if base.empty:
    st.warning("This product cannot be forecast (inactive or too little history).")
    st.stop()
res = sim.run_scenario(ctx, bundle, model, policy, orig, scen, base)

with right:
    st.subheader("Results")
    o, r = res.original, res.revised
    m = st.columns(4)
    m[0].metric("Lead-time demand", f"{r['lead_time_demand']:.0f}", f"{r['lead_time_demand'] - o['lead_time_demand']:+.0f}", delta_color="off")
    m[1].metric("Reorder point", f"{r['reorder_point']:.0f}", f"{r['reorder_point'] - o['reorder_point']:+.0f}", delta_color="off")
    m[2].metric("Order quantity", f"{r['recommended_order_qty']:.0f}", f"{r['recommended_order_qty'] - o['recommended_order_qty']:+.0f}", delta_color="off")
    m[3].metric("Risk", r["risk_level"].split(" ")[0], "was " + o["risk_level"].split(" ")[0] if o["risk_level"] != r["risk_level"] else "unchanged", delta_color="off")
    st.markdown(f"**Forecast source:** {res.forecast_source}")
    ac.show_plot(viz.scenario_compare_chart(res.dates, res.baseline_daily, res.scenario_daily))
    ac.show_plot(viz.stock_projection_chart(res.dates, res.scenario_daily, scen.on_hand, scen.lead_time_days))
    for n in res.narrative:
        st.markdown(f"- {n}")

st.subheader("Original vs simulated decision")
d = res.diff.copy()
for c in ["Original", "Simulated", "Change"]:
    d[c] = d[c].map(lambda v: f"{v:,.1f}" if isinstance(v, (int, float)) and not isinstance(v, bool) else str(v))
ac.show_df(d)
with st.expander("Full explanation of the simulated recommendation"):
    st.markdown(res.revised["explanation"])
    st.markdown("**Original (current inventory & policy):**")
    st.markdown(res.original["explanation"])

n1, n2 = st.columns([3, 1])
nm = n1.text_input("Scenario name", value=f"{names.get(pid, pid)} what-if")
if n2.button("Save scenario"):
    db.save_scenario(ctx.key, pid, nm, {k: v for k, v in scen.__dict__.items()},
                     {"original_qty": res.original["recommended_order_qty"], "simulated_qty": res.revised["recommended_order_qty"],
                      "risk": res.revised["risk_level"], "source": res.forecast_source})
    st.success("Scenario saved.")
saved = db.list_scenarios(ctx.key)
if len(saved):
    with st.expander("Saved scenarios"):
        ac.show_df(saved[["scenario_id", "created_at", "product_id", "name", "result_json"]])
