import pandas as pd
import streamlit as st

import config
from src import app_context as ac
from src import data_loader as dl
from src import data_validation as dv
from src import database as db
from src import forecasting as fc
from src import model_evaluation as me
from src import pipeline as pl

ctx, bundle, policy = ac.setup_page("Data & Model Management", "Upload data, validate it, train and manage models", need_model=False)

tabs = st.tabs(["Dataset", "Upload CSV", "Inventory snapshot", "Models", "Storage & reset"])

with tabs[0]:
    c = st.columns(4)
    c[0].metric("Active dataset", "Synthetic demo" if ctx.is_synthetic else "Uploaded")
    c[1].metric("Rows (daily panel)", f"{len(ctx.panel):,}")
    c[2].metric("Products", ctx.panel["product_id"].nunique())
    c[3].metric("Days", int(ctx.panel["date"].nunique()))
    ac.show_df(ctx.panel.tail(200).sort_values("date", ascending=False).head(50).astype(str))
    for n in ctx.notes:
        st.info(n)
    if not ctx.is_synthetic and st.button("Switch back to the sample dataset"):
        ac.set_ctx(pl.load_sample_context())
        st.rerun()
    st.caption("Datasets registered in SQLite:")
    ac.show_df(db.list_datasets()[["dataset_key", "name", "source", "n_rows", "n_products", "date_min", "date_max"]])

with tabs[1]:
    st.markdown("Upload a CSV of historical sales. **Required:** date, product ID, units sold. Everything else is optional; "
                "missing optional fields simply disable the analytics that need them (nothing is invented).")
    up = st.file_uploader("Sales CSV", type=["csv", "txt"], key="sales_up")
    inv_up = st.file_uploader("Current inventory CSV (optional: product_id, on_hand, on_order, backorders, lead_time_days, ...)", type=["csv", "txt"], key="inv_up")
    if up is not None:
        try:
            raw = dl.read_csv_flexible(up)
        except ValueError as exc:
            st.error(str(exc))
            st.stop()
        st.markdown("**Preview of uploaded records**")
        ac.show_df(raw.head(20).astype(str))
        guess = dv.suggest_mapping(raw.columns, dv.SALES_FIELDS)
        st.markdown("**Column mapping**")
        mapping = {}
        cols = ["(none)"] + list(raw.columns)
        grid = st.columns(3)
        for i, f in enumerate(dv.SALES_FIELDS):
            default = cols.index(guess[f]) if guess[f] in cols else 0
            label = f + (" *" if f in dv.SALES_REQUIRED else "")
            sel = grid[i % 3].selectbox(label, cols, index=default, key=f"map_{f}")
            mapping[f] = None if sel == "(none)" else sel
        dayfirst = st.checkbox("Dates are day-first (e.g. 31/12/2024)", value=False)
        rep = dv.validate_sales(raw, mapping, dayfirst)
        for e in rep.errors:
            st.error(e)
        for w in rep.warnings:
            st.warning(w)
        if rep.ok:
            st.success(f"Valid: {rep.info['rows_clean']:,} rows, {rep.info['n_products']} products, "
                       f"{rep.info['date_min']:%d %b %Y} to {rep.info['date_max']:%d %b %Y}.")
            if rep.info["optional_fields_absent"]:
                st.info("Optional fields not provided -> related analytics disabled: " + ", ".join(rep.info["optional_fields_absent"]))
            if rep.missing_summary is not None and len(rep.missing_summary):
                st.markdown("**Missing-value summary**")
                ac.show_df(rep.missing_summary.reset_index().rename(columns={"index": "column"}))
            if rep.issue_rows is not None and len(rep.issue_rows):
                with st.expander("Rows removed as invalid (first 200)"):
                    ac.show_df(rep.issue_rows.astype(str))
            inv_clean = None
            if inv_up is not None:
                inv_raw = dl.read_csv_flexible(inv_up)
                irep = dv.validate_inventory(inv_raw)
                for e in irep.errors:
                    st.error(e)
                for w in irep.warnings:
                    st.warning(w)
                inv_clean = irep.cleaned if irep.ok else None
            name = st.text_input("Dataset name", value=up.name)
            if st.button("Use this dataset", type="primary"):
                key = "upload_" + "".join(ch for ch in name.lower() if ch.isalnum())[:24]
                config.DATA_DIR.mkdir(exist_ok=True)
                rep.cleaned.to_csv(config.DATA_DIR / f"{key}.csv.gz", index=False)
                db.clear_dataset(key)
                new = pl.build_context(rep.cleaned, inv_clean, key, name, False, rep.info)
                ac.set_ctx(new)
                st.success("Dataset loaded. Open any page; models will be trained for it (or train them in the Models tab).")
                st.rerun()

with tabs[2]:
    st.markdown("Current inventory used by recommendations. Edit values (e.g. add purchase orders) and save - they are stored in SQLite.")
    inv = ctx.inventory.copy()
    inv["product_name"] = inv["product_id"].map(ctx.names)
    try:
        edited = st.data_editor(inv, num_rows="fixed", key="inv_editor", disabled=["product_id", "product_name"])
    except Exception:  # noqa: BLE001
        edited = inv
        ac.show_df(inv)
    if st.button("Save inventory snapshot"):
        keep = edited.drop(columns=["product_name"])
        db.save_inventory(ctx.key, keep)
        ctx.inventory = keep
        st.cache_data.clear()
        st.success("Inventory saved; recommendations will recalculate.")
    missing = int(inv["on_hand"].isna().sum())
    if missing:
        st.warning(f"{missing} product(s) have no on-hand stock; they will show 'Unknown' rather than an invented number.")

with tabs[3]:
    b = ac.get_bundle(auto_train=False)
    if b is None:
        st.info("No trained models for this dataset yet.")
    else:
        sp = b["split"]
        st.markdown(f"**Selected model:** {b['selected']} | trained {b['trained_at']} | train rows {sp['n_train_rows']:,} | "
                    f"validation from {sp['val_start']} | test from {sp['test_start']}")
        show = b["comparison"][["model", "MAE_val", "RMSE_val", "WAPE_val", "MAE_test", "RMSE_test", "WAPE_test", "selected"]]
        ac.show_df(show.round(3))
        for n in b.get("notes", []):
            st.info(n)
        with st.expander("Per-product test error (selected model)"):
            ac.show_df(b["product_metrics"].round(3))
        with st.expander("Metric definitions"):
            for k, v in me.METRIC_HELP.items():
                st.markdown(f"**{k}** - {v}")
    if st.button("Train / retrain models now", type="primary"):
        res = ac.train_with_progress(force=True)
        if res:
            st.success(f"Training complete. Selected: {res['selected']}")
            st.rerun()
    hist = db.load_model_runs(ctx.key)
    if len(hist):
        with st.expander("Training history (SQLite)"):
            ac.show_df(hist.round(3))

with tabs[4]:
    st.markdown(f"""
**Where data lives**
- SQLite `{config.DB_PATH.relative_to(config.ROOT)}`: dataset metadata, products, inventory snapshots, model runs & metrics, forecast runs,
  recommendations, anomalies + status, scenarios.
- `data/*.csv.gz`: the large daily sales tables (not duplicated into SQLite).
- `models/*.joblib` (+ `.json` summary): trained model bundles.
""")
    if ctx.is_synthetic:
        if st.button("Reset sample dataset (regenerate data, delete its models and database records)"):
            db.clear_dataset("sample")
            p = fc.bundle_path("sample")
            for f in (p, p.with_suffix(".json")):
                if f.exists():
                    f.unlink()
            dl.ensure_sample_files(force=True)
            ac.set_ctx(pl.load_sample_context())
            st.success("Sample dataset regenerated.")
            st.rerun()
    else:
        st.info("Switch to the sample dataset (Dataset tab) to reset it.")
