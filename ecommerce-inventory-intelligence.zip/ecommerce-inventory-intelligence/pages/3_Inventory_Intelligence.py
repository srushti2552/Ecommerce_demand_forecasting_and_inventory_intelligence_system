import pandas as pd
import streamlit as st

from src import app_context as ac
from src import database as db
from src import visualizations as viz
from src.inventory_engine import RECOMMENDATION_EXPORT_COLUMNS, simplified_cover_horizon, RISK_RANK

ctx, bundle, policy = ac.setup_page("Inventory Intelligence", "Explainable restocking recommendations", policy_controls=True)

rec = ac.get_recommendations(ctx, bundle, policy)
if rec.empty:
    st.warning("No recommendations: no products have both a forecast and inventory data.")
    st.stop()
st.caption(f"Policy: review period {policy.review_period_days:g} d, safety stock = {policy.safety_method}"
           f"{' @ ' + format(policy.service_level, '.1%') if policy.safety_method == 'statistical' else ''}. Change it in the sidebar - results recalculate.")

f1, f2, f3 = st.columns([2, 2, 2])
cats = sorted(rec["category"].dropna().unique())
risks = [r for r in sorted(rec["risk_level"].unique(), key=lambda x: RISK_RANK.get(x, 9))]
cat_sel = f1.multiselect("Category", cats, default=[])
risk_sel = f2.multiselect("Risk level", risks, default=[])
text = f3.text_input("Search product")
view = rec.copy()
if cat_sel:
    view = view[view["category"].isin(cat_sel)]
if risk_sel:
    view = view[view["risk_level"].isin(risk_sel)]
if text:
    view = view[view["product_name"].str.contains(text, case=False, na=False)]
if view.empty:
    st.info("No products match the filters.")
    st.stop()

m = st.columns(4)
m[0].metric("Products shown", len(view))
m[1].metric("Critical / low", int(view["risk_level"].isin(["Critical Stock Risk", "Low Stock"]).sum()))
m[2].metric("Units to order", ac.fmt_num(view["recommended_order_qty"].sum()))
cost = (view["recommended_order_qty"] * view["unit_cost"]).sum(skipna=True)
m[3].metric("Est. purchase cost", ac.fmt_money(cost) if cost else "n/a", help="Only products with a unit cost.")

cols = ["product_name", "category", "risk_level", "on_hand", "on_order", "inventory_position", "forecast_7d", "forecast_30d", "lead_time_days",
        "lead_time_demand", "safety_stock", "reorder_point", "recommended_order_qty", "coverage_days_on_hand"]
ac.show_df(view[cols].round(1))
ac.show_plot(viz.stock_vs_reorder_chart(view.reset_index(drop=True)))

b1, b2 = st.columns(2)
export = view[[c for c in RECOMMENDATION_EXPORT_COLUMNS if c in view.columns]]
b1.download_button("Export recommendations (CSV)", export.to_csv(index=False).encode(), "inventory_recommendations.csv", "text/csv")
if b2.button("Save recommendations to database"):
    db.save_recommendations(ctx.key, rec, policy.__dict__)
    st.success("Saved to SQLite (table: recommendations).")

st.subheader("Why this recommendation?")
pid = st.selectbox("Product", view["product_id"].tolist(), format_func=lambda p: ctx.names.get(p, p))
r = rec[rec["product_id"] == pid].iloc[0].to_dict()
l, rgt = st.columns([3, 2])
with l:
    st.markdown(r["explanation"])
    st.markdown(ac.tag("calc", "calculated from model forecast + your policy"), unsafe_allow_html=True)
with rgt:
    if pd.notna(r["inventory_position"]):
        ac.show_plot(viz.inventory_waterfall(r), key="wf")
with st.expander("Formulas used"):
    st.markdown("""
- **Lead-time demand** = forecast demand summed over the supplier lead time
- **Safety stock** = z x sqrt(P x sigma_d^2 + d^2 x sigma_L^2), with P = lead time + review period (statistical method)
- **Reorder point** = lead-time demand + safety stock
- **Inventory position** = on-hand + on-order - backorders
- **Target stock** = lead-time demand + review-period demand + safety stock
- **Order quantity** = max(0, target stock - inventory position)
""")
with st.expander("Simplified 'cover the whole horizon' example"):
    h = st.radio("Horizon", [7, 30], horizontal=True, key="simp_h")
    fh = r["forecast_7d"] if h == 7 else r["forecast_30d"]
    sa = st.number_input("Illustrative safety allowance (units)", 0, 100000, 30, key="simp_sa")
    s = simplified_cover_horizon(r["on_hand"], fh, sa)
    st.markdown(f"Required stock = {fh:.0f} + {sa} = **{s['required_stock']:.0f}**; additional stock = max(0, {s['required_stock']:.0f} - "
                f"{r['on_hand']:.0f}) = **{s['additional_stock']:.0f}** units. This ignores supplier lead time and on-order stock, so it is "
                f"only a teaching simplification; the application recommends **{r['recommended_order_qty']:.0f}** units.")
