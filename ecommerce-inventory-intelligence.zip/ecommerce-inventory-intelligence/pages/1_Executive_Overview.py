import pandas as pd
import streamlit as st

from src import app_context as ac
from src import database as db
from src import eda
from src import visualizations as viz
from src.inventory_engine import CRITICAL, LOW, OVERSTOCK

ctx, bundle, policy = ac.setup_page("Executive Overview", "Portfolio health at a glance", policy_controls=True)

fcst = ac.get_forecast(ctx, bundle, None, 30)
rec = ac.get_recommendations(ctx, bundle, policy)
an = ac.get_anomalies(ctx)
k = eda.kpis(ctx.panel)

alerts = 0
if len(an):
    st_df = db.load_anomaly_status(ctx.key)
    recent = an[an["date"] > ctx.last_date - pd.Timedelta(days=14)]
    if len(st_df) and len(recent):
        recent = recent.merge(st_df, on=["product_id", "date"], how="left")
        recent = recent[~recent["status"].isin(["Resolved", "Dismissed"])]
    alerts = len(recent)

inv_units = ctx.inventory["on_hand"].sum(skipna=True)
c = st.columns(4)
c[0].metric("Products", k["n_products"])
c[1].metric("Units sold (all history)", ac.fmt_num(k["total_units"]))
c[2].metric("Revenue (net of discount)", ac.fmt_money(k["total_revenue"]) if k["total_revenue"] is not None else "n/a")
c[3].metric("Units on hand", ac.fmt_num(inv_units))
c = st.columns(4)
c[0].metric("Forecast demand, next 30 days", ac.fmt_num(fcst["forecast"].sum()))
n_crit_low = int(rec["risk_level"].isin([CRITICAL, LOW]).sum()) if len(rec) else 0
c[1].metric("Critical + low-stock products", n_crit_low, help="Critical Stock Risk and Low Stock under the current policy")
c[2].metric("Potential overstock", int((rec["risk_level"] == OVERSTOCK).sum()) if len(rec) else 0)
c[3].metric("Active anomaly alerts (last 14 days)", alerts)

left, right = st.columns([3, 2])
with left:
    hist = ctx.panel.groupby("date")["units_sold"].sum().reset_index().tail(120)
    f = fcst.groupby("date")["forecast"].sum().reset_index()
    ac.show_plot(viz.forecast_chart(hist, f, "Total daily units: last 120 days and 30-day forecast", 120, show_range=False))
    st.caption(f"Forecast by **{bundle['selected']}**, the model with the best validation WAPE on this dataset. "
               "Assumes no promotions in the forecast period.")
with right:
    if len(rec):
        ac.show_plot(viz.risk_bar(rec))
    cat = eda.category_sales(ctx.panel)
    ac.show_plot(viz.bar(cat, "category", "units", "Units sold by category"))

st.subheader("Prioritised inventory risks")
if len(rec):
    top = rec[rec["risk_level"].isin([CRITICAL, LOW])].head(10)
    if top.empty:
        st.success("No critical or low-stock products under the current policy.")
    else:
        ac.show_df(top[["product_name", "risk_level", "on_hand", "on_order", "lead_time_days", "reorder_point", "recommended_order_qty",
                        "coverage_days_on_hand"]].round(1))
        st.caption("Open **Inventory Intelligence** for the full explanation of each recommendation.")
else:
    st.info("No inventory recommendations available (check that on-hand stock data exists).")
